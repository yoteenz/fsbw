"""Blender structural/round-trip validation. Reports failures; never claims creative approval."""
import bpy,bmesh,struct,json,hashlib,math,os
from mathutils import Vector
SRC=os.path.dirname(os.path.abspath(__file__));ROOT=os.path.dirname(SRC);EXP=os.path.join(ROOT,'02_EXPORTS');DOC=os.path.join(ROOT,'05_DOCUMENTATION')
manifest=json.load(open(os.path.join(DOC,'module-manifest.json')));expected={m['name'] for m in manifest['modules']}
report={'blenderVersion':bpy.app.version_string,'formats':{},'checks':{},'targetApplications':{'unreal':'NOT TESTED — deferred by sprint','maya':'NOT TESTED — optional, not needed'},'productionModified':False}
def geometry():
    meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];issues=[];pts=[];triangles=0;signatures={};duplicates=[]
    for o in meshes:
        if o.name not in expected:continue
        ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh()
        mesh.calc_loop_triangles();triangles+=len(mesh.loop_triangles)
        bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6)
        badedges=sum(not e.is_manifold for e in bm.edges);degenerate=sum(f.calc_area()<1e-11 for f in bm.faces);vol=bm.calc_volume(signed=True)
        if badedges or degenerate or vol<=0:issues.append({'object':o.name,'nonManifoldEdges':badedges,'degenerateFaces':degenerate,'signedVolume':vol})
        bm.free();ev.to_mesh_clear()
        coordinates=[o.matrix_world@v.co for v in o.data.vertices];pts.extend(coordinates)
        assert all(math.isfinite(v) for p in coordinates for v in p)
        sig=hashlib.sha256(str(sorted(tuple(round(v,6) for v in p) for p in coordinates)).encode()).hexdigest()
        if sig in signatures:duplicates.append([signatures[sig],o.name])
        signatures[sig]=o.name
        assert len(o.data.materials)>0 and all(m is not None for m in o.data.materials)
    names={o.name for o in meshes if o.name in expected}
    return {'meshObjectCount':len(names),'expectedMeshObjectCount':len(expected),'triangles':triangles,'bounds':[list(min(p[i] for p in pts) for i in range(3)),list(max(p[i] for p in pts) for i in range(3))],'geometryIssues':issues,'exactDuplicateMeshes':duplicates,'missingNames':sorted(expected-names),'allExpectedNamesPresent':names==expected}
blend=os.path.join(SRC,'SITE00_Build_Object_V2.blend');bpy.ops.wm.open_mainfile(filepath=blend)
report['master']=geometry();report['checks']['masterOpens']=True
report['checks']['masterMaterialsPresent']=all(bpy.data.materials.get(n) for n in ['CLEAR_ARCHITECTURAL_GLASS','RED_TRANSLUCENT_ACRYLIC','WHITE_MARBLE','LIGHT_STONE','DARK_STONE','REFLECTIVE_METAL'])
report['checks']['requiredCamerasPresent']=all(bpy.data.objects.get(n) for n in ['CAM_REFERENCE_MATCH','CAM_HERO','CAM_FRONT','CAM_REAR','CAM_LEFT','CAM_RIGHT','CAM_ELEVATED'])
report['checks']['textureResourcesPacked']=all(im.packed_file is not None for im in bpy.data.images if im.name not in ['Render Result','Viewer Node'])
report['checks']['redGlassFoundationIndependent']=all(bpy.data.objects.get(n) for n in ['RED_CORE_PRIMARY','GLASS_PRIMARY_01','FOUNDATION_MARBLE_CONTINUOUS'])
for filename in ['SITE00_Build_Object_V2_High.glb','SITE00_Build_Object_V2_Web.glb']:
    path=os.path.join(EXP,filename);data=open(path,'rb').read();magic,version,size=struct.unpack_from('<4sII',data)
    assert magic==b'glTF' and version==2 and size==len(data)
    jlen,jkind=struct.unpack_from('<II',data,12);assert jkind==0x4e4f534a
    g=json.loads(data[20:20+jlen]);blen,bkind=struct.unpack_from('<II',data,20+jlen);assert bkind==0x004e4942
    binary=data[28+jlen:28+jlen+blen]
    for bv in g['bufferViews']:assert bv.get('byteOffset',0)+bv['byteLength']<=len(binary)
    for a in g['accessors']:
        if 'bufferView' not in a:continue
        n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];sz={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}[a['componentType']];bv=g['bufferViews'][a['bufferView']];stride=bv.get('byteStride',n*sz)
        assert a.get('byteOffset',0)+max(0,a['count']-1)*stride+n*sz<=bv['byteLength']
        if a['componentType']==5126:
            for i in range(a['count']):assert all(math.isfinite(v) for v in struct.unpack_from('<'+'f'*n,binary,bv.get('byteOffset',0)+a.get('byteOffset',0)+i*stride))
    for mesh in g['meshes']:
        for p in mesh['primitives']:
            assert p.get('mode',4)==4
            a=g['accessors'][p['indices']];bv=g['bufferViews'][a['bufferView']];fmt,sz={5121:('B',1),5123:('H',2),5125:('I',4)}[a['componentType']];count=g['accessors'][p['attributes']['POSITION']]['count'];off=bv.get('byteOffset',0)+a.get('byteOffset',0)
            assert all(struct.unpack_from('<'+fmt,binary,off+i*sz)[0]<count for i in range(a['count']))
            assert 'NORMAL' in p['attributes']
            if g['materials'][p['material']].get('pbrMetallicRoughness',{}).get('baseColorTexture'):assert 'TEXCOORD_0' in p['attributes']
    assert all('uri' not in im for im in g.get('images',[]));assert all('uri' not in b for b in g['buffers'])
    names=[n.get('name') for n in g['nodes']];assert len(names)==len(set(names));assert expected.issubset(set(names))
    assert not g.get('cameras') and not any('REVIEW_' in str(n) or 'CAM_' in str(n) for n in names)
    mats={m['name']:m for m in g['materials']};assert len(mats)==6
    for name in ['CLEAR_ARCHITECTURAL_GLASS','RED_TRANSLUCENT_ACRYLIC']:assert mats[name]['extensions']['KHR_materials_transmission']['transmissionFactor']>.8
    image_report=[]
    for im in g.get('images',[]):
        bv=g['bufferViews'][im['bufferView']];bytes_=binary[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]
        dims=struct.unpack_from('>II',bytes_,16) if bytes_.startswith(b'\x89PNG') else None
        image_report.append({'name':im.get('name'),'dimensions':dims,'bytes':len(bytes_)})
    bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=path)
    result=geometry();result.update({'fileBytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'extensionsUsed':g.get('extensionsUsed',[]),'embeddedImages':image_report,'materials':list(mats),'nodeCount':len(g['nodes'])});report['formats'][filename]=result
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=os.path.join(EXP,'SITE00_Build_Object_V2_DCC.fbx'))
report['formats']['SITE00_Build_Object_V2_DCC.fbx']=geometry()
failures=[]
for label,result in [('master',report['master'])]+list(report['formats'].items()):
    if result['geometryIssues'] or result['exactDuplicateMeshes'] or result['missingNames']:failures.append(label)
report['checks']['embeddedGlbResources']=True;report['checks']['indicesAndBuffersValid']=True;report['checks']['namesSurviveExport']=True;report['checks']['glbAndFbxBlenderReimport']=True
report['status']='PASS' if not failures and all(report['checks'].values()) else 'FAIL';report['failedGeometryTargets']=failures
report['limitations']=['Structural validation is not Khronos conformance certification.','Reference fidelity is evaluated separately; hidden geometry is inferred.','Maya/Unreal not opened for import validation.','Three.js Builder contract missing locally; integration unverified.']
with open(os.path.join(DOC,'export-validation-report.json'),'w') as f:json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
