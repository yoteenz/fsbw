"""Local reference-driven V2. Blender --background --python fabricate_v2.py -- A|B|C|D|E
Stages rebuild deterministically and emit reference-camera evidence. E exports and saves master.
No paid generation, repository edits, or application imports outside Blender.
"""
import bpy,math,json,os,sys
from mathutils import Vector
SRC=os.path.dirname(os.path.abspath(__file__));ROOT=os.path.dirname(SRC)
DOC=os.path.join(ROOT,'05_DOCUMENTATION');REN=os.path.join(ROOT,'03_RENDERS');EXP=os.path.join(ROOT,'02_EXPORTS')
STAGE=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'E'
LEVEL='ABCDE'.index(STAGE);FINAL=STAGE=='E'
P={'width':10.,'depth':7.5,'foundationHeight':.65,'glassThickness':.014,'coreThickness':.024,
   'frameThickness':.022,'edgeBevel':.003}
pf=os.path.join(SRC,'fabrication-parameters.json')
if os.path.exists(pf):
    with open(pf) as f:P.update(json.load(f))
P.pop('coreHeight',None) # Superseded prototype hypothesis; visible heights come from reference geometry.
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.cycles.samples=20 if not FINAL else 64;scene.cycles.use_denoising=True
scene.cycles.use_preview_denoising=True;scene.cycles.preview_samples=48
scene.cycles.max_bounces=20;scene.cycles.transmission_bounces=16;scene.cycles.transparent_max_bounces=16
# Installed OptiX driver failed to compile Blender 5.2's kernel in the access check.
# CPU is the verified rendering path; do not change machine drivers/preferences.
scene.cycles.device='CPU'
scene.render.resolution_x=1200 if FINAL else 1000;scene.render.resolution_y=round(scene.render.resolution_x*941/1672);scene.render.resolution_percentage=100
scene.view_settings.view_transform='Standard' if FINAL else 'AgX';scene.view_settings.exposure=-.4 if FINAL else 0;scene.render.image_settings.file_format='PNG'
asset=bpy.data.collections.new('BUILD_OBJECT_ROOT');scene.collection.children.link(asset)
studio=bpy.data.collections.new('REVIEW_STUDIO_EXCLUDED');scene.collection.children.link(studio)
root=bpy.data.objects.new('BUILD_OBJECT_ROOT',None);asset.objects.link(root)
root['version']='V2';root['authority']='46D454FE-F932-455E-B74E-4BFA5AB18D90.jpg';root['scaleStatus']='Relative artistic scale; physical dimensions not recovered'
groups={};collections={}
for name in ['FOUNDATION','RED_THRESHOLD','PRIMARY_GLASS','SECONDARY_GLASS','INTERIOR','STRUCTURAL_FRAMES','OPTIONAL_MODULES']:
    col=bpy.data.collections.new(name);asset.children.link(col);collections[name]=col
    o=bpy.data.objects.new(name,None);col.objects.link(o);o.parent=root;groups[name]=o
def mat(name,col,rough=.1,metal=0,trans=0,ior=1.5):
    m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes['Principled BSDF']
    for key,val in [('Base Color',(*col,1)),('Roughness',rough),('Metallic',metal),('Transmission Weight',trans),('IOR',ior)]:b.inputs[key].default_value=val
    m.diffuse_color=(*col,1);return m
glass=mat('CLEAR_ARCHITECTURAL_GLASS',(.97,.985,1),.035,trans=1,ior=1.46)
red=mat('RED_TRANSLUCENT_ACRYLIC',(.72,.001,.004),.055,trans=.90,ior=1.49)
red.node_tree.nodes['Principled BSDF'].inputs['Specular IOR Level'].default_value=.18
marble=mat('WHITE_MARBLE',(.86,.865,.86),.22)
stone=mat('LIGHT_STONE',(.84,.845,.83),.31)
dark=mat('DARK_STONE',(.23,.235,.235),.29)
metal=mat('REFLECTIVE_METAL',(.075,.085,.09),.20,metal=.92)
materials=[glass,red,marble,stone,dark,metal]
# Cycles absorption gives red surfaces real depth. GLB gets an explicit volume contract.
nt=red.node_tree;absorb=nt.nodes.new('ShaderNodeVolumeAbsorption');absorb.inputs['Color'].default_value=(.8,.012,.025,1);absorb.inputs['Density'].default_value=18.0
nt.links.new(absorb.outputs['Volume'],nt.nodes['Material Output'].inputs['Volume'])
if LEVEL==0:
    red.node_tree.nodes['Principled BSDF'].inputs['Transmission Weight'].default_value=.4
    glass.node_tree.nodes['Principled BSDF'].inputs['Transmission Weight'].default_value=.8
objects=[];manifest=[]
base=P['foundationHeight'];gt=P['glassThickness'];rt=P['coreThickness'];top=base+.036
def box(name,loc,size,m,group,bevel=None,role='',dependency=None,tier=1):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.data.name=name+'_MESH';o.dimensions=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    for c in list(o.users_collection):c.objects.unlink(o)
    collections[group].objects.link(o);o.parent=groups[group];o.data.materials.append(m)
    o['stableId']=name;o['module']=group;o['visibilityTier']=tier;o['function']=role or name
    b=P['edgeBevel'] if bevel is None else bevel
    if b:
        mod=o.modifiers.new('Fine fabricated edge','BEVEL');mod.width=min(b,min(size)*.2);mod.segments=2
        mod=o.modifiers.new('Consistent corner normals','WEIGHTED_NORMAL');mod.keep_sharp=True
    objects.append(o);manifest.append({'name':name,'function':role or name,'material':m.name,'parent':group,'visibilityDependencies':dependency or [group],'visibilityTier':tier,
      'interaction':'Pending integration: transform/visibility/material control through existing Builder contract; no new canonical fields.'})
    return o
def wall(name,axis,pos,span,height,m,group,z0=top,tier=1):
    if axis=='X':return box(name,(pos[0],pos[1],z0+height/2),(span,gt if m==glass else rt,height),m,group,tier=tier)
    return box(name,(pos[0],pos[1],z0+height/2),(gt if m==glass else rt,span,height),m,group,tier=tier)
def edge(name,a,b,group='STRUCTURAL_FRAMES',m=metal,width=None,tier=1):
    a=Vector(a);b=Vector(b);v=b-a;width=width or P['frameThickness']
    o=box(name,(a+b)/2,(width,width,v.length),m,group,bevel=.001,tier=tier)
    o.rotation_euler=v.to_track_quat('Z','Y').to_euler();return o
def glass_chamber(tag,bounds,height,group,sides=('front','right','rear'),roof=True,z0=top,tier=1,frame=False):
    x0,x1,y0,y1=bounds
    for side in sides:
        if side in ['front','rear']:o=wall(tag+'_'+side.upper(),'X',((x0+x1)/2,y0 if side=='front' else y1),x1-x0,height,glass,group,z0,tier)
        else:o=wall(tag+'_'+side.upper(),'Y',(x0 if side=='left' else x1,(y0+y1)/2),y1-y0,height,glass,group,z0,tier)
    if roof:box(tag+'_ROOF_PLANE',((x0+x1)/2,(y0+y1)/2,z0+height),(x1-x0,y1-y0,gt),glass,group,tier=tier)
    # Trim outlines are deliberately restrained, avoiding repeated window grids.
    if frame:
        for j,(a,b) in enumerate([((x0,y0,z0+height),(x1,y0,z0+height)),((x1,y0,z0+height),(x1,y1,z0+height)),((x1,y1,z0+height),(x0,y1,z0+height)),((x0,y1,z0+height),(x0,y0,z0+height)),((x0,y0,z0),(x0,y0,z0+height)),((x1,y0,z0),(x1,y0,z0+height)),((x1,y1,z0),(x1,y1,z0+height))]):edge(tag+f'_FRAME_{j:02d}',a,b,tier=tier)

# Reference-constrained vertical planes: ray/plane intersections generate real solids.
# This is geometric reconstruction; no reference pixels are used as surface textures.
from bpy_extras.object_utils import world_to_camera_view
cd=json.load(open(os.path.join(SRC,'camera-match.json')))
camdata=bpy.data.cameras.new('CALIBRATION_TEMP');temp=bpy.data.objects.new('CALIBRATION_TEMP',camdata);scene.collection.objects.link(temp)
temp.location=cd['location'];temp.rotation_euler=cd['rotationEuler'];camdata.lens=cd['lens'];camdata.sensor_width=36;camdata.sensor_fit='HORIZONTAL';camdata.shift_x=cd['shiftX'];camdata.shift_y=cd['shiftY']
bpy.context.view_layer.update();proj=temp.calc_matrix_camera(bpy.context.evaluated_depsgraph_get(),x=1672,y=941);inv=(proj@temp.matrix_world.inverted()).inverted()
def raypoint(px,py,axis,value):
    p=inv@Vector((px/1672*2-1,1-py/941*2,-1,1));p=p/p.w
    d=p.to_3d()-temp.location;index={'X':0,'Y':1,'Z':2}[axis]
    t=(value-temp.location[index])/d[index]
    return temp.location+d*t
def reference_panel(name,px,axis,value,m,group,tier=1):
    # Adjust inferred depth along camera rays to keep the real solid over the plinth.
    # Projected image landmarks are retained; depth is not measured by the photograph.
    index={'X':0,'Y':1}[axis];cam=temp.location.copy()
    dirs=[raypoint(x,y,axis,cam[index]+1)-cam for x,y in px]
    lower=-1e20;upper=1e20
    for direction in dirs:
        for j,limit in [(0,P['width']/2-.06),(1,P['depth']/2-.06)]:
            if abs(direction[j])<1e-9:continue
            aa=(-limit-cam[j])/direction[j];bb=(limit-cam[j])/direction[j]
            lower=max(lower,min(aa,bb));upper=min(upper,max(aa,bb))
    if lower<=upper:value=cam[index]+max(lower,min(upper,value-cam[index]))
    points=[raypoint(x,y,axis,value) for x,y in px]
    for point in points:point.z=max(point.z,top)
    normal=Vector((1,0,0) if axis=='X' else (0,1,0));thick=rt if m==red else .08 if m in [dark,stone] else gt
    center=sum(points,Vector())/len(points);n=len(points)
    verts=[tuple(p-center-normal*thick/2) for p in points]+[tuple(p-center+normal*thick/2) for p in points]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    mesh=bpy.data.meshes.new(name+'_MESH');mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new(name,mesh);collections[group].objects.link(o);o.location=center;o.parent=groups[group];mesh.materials.append(m)
    import bmesh
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
    if P['edgeBevel']:
        mod=o.modifiers.new('Fine fabricated edge','BEVEL');mod.width=min(.002,thick*.15);mod.segments=2
        mod=o.modifiers.new('Corner normals','WEIGHTED_NORMAL');mod.keep_sharp=True
    o['stableId']=name;o['module']=group;o['visibilityTier']=tier;o['referencePixels']=json.dumps(px);o['reconstructionPlane']=axis+'='+str(value)
    objects.append(o);manifest.append({'name':name,'function':'Reference-constrained architectural plane','material':m.name,'parent':group,'visibilityDependencies':[group],'visibilityTier':tier,'interaction':'Pending integration: module visibility/transforms/material control','referencePixels':px,'inference':'Depth plane and non-orthogonal quadrilateral inferred from single-view projection'})
    return o,points
def outline(tag,points,m=metal,width=.009,group='STRUCTURAL_FRAMES'):
    for i,p in enumerate(points):edge(tag+f'_{i:02d}',p,points[(i+1)%len(points)],group,m,width)
foundation=box('FOUNDATION_MARBLE_CONTINUOUS',(0,0,base/2),(P['width'],P['depth'],base),marble,'FOUNDATION',.007,role='Continuous veined marble pedestal')
box('FOUNDATION_CLEAR_TOP_PLATE',(0,0,base+.019),(9.75,7.25,.026),glass,'FOUNDATION',.004)
red_primary,redpts=reference_panel('RED_CORE_PRIMARY',[(930,141),(1067,78),(1067,688),(930,678)],'X',4.47,red,'RED_THRESHOLD')
red_secondary,redpts2=reference_panel('RED_CORE_SECONDARY',[(819,186),(930,141),(930,678),(819,665)],'Y',-3.13,red,'RED_THRESHOLD')
if LEVEL>=1:
    outline('RED_CORE_FRAME_PRIMARY',redpts,red,.010,'RED_THRESHOLD');outline('RED_CORE_FRAME_SECONDARY',redpts2,red,.010,'RED_THRESHOLD')
    reference_panel('RED_CORE_INTERIOR_01',[(820,232),(971,289),(971,653),(820,637)],'X',4.10,red,'RED_THRESHOLD',2)
    reference_panel('RED_CORE_INTERIOR_02',[(881,346),(1008,394),(1008,663),(881,653)],'X',4.31,red,'RED_THRESHOLD',3)
    reference_panel('RED_CORE_INTERIOR_03',[(852,480),(941,434),(941,658),(852,640)],'Y',-2.76,red,'RED_THRESHOLD',3)
    # Deliberate horizontal interior planes create layered transmitted red depth.
    for j,(y,z,length) in enumerate([(-2.62,.73,.98),(-2.4,1.50,1.18),(-2.15,2.40,1.1),(-2.23,3.18,.9)]):
        box(f'RED_CORE_HORIZONTAL_{j:02d}',(4.15,y,z),(.62,length,rt),red,'RED_THRESHOLD',tier=2)
    box('RED_CORE_LOWER_THRESHOLD',(4.22,-2.86,.706),(.57,1.35,.025),red,'RED_THRESHOLD',.002)
primary1,p1=reference_panel('GLASS_PRIMARY_01',[(519,320),(819,186),(819,660),(519,691)],'Y',-2.98,glass,'PRIMARY_GLASS')
primary2,p2=reference_panel('GLASS_PRIMARY_02',[(1067,201),(1210,298),(1210,715),(1067,688)],'X',4.49,glass,'PRIMARY_GLASS')
primary3,p3=reference_panel('GLASS_PRIMARY_03',[(1067,78),(1283,215),(1283,728),(1067,688)],'X',4.45,glass,'PRIMARY_GLASS')
outline('PRIMARY_FRAME_LEFT',p1,width=.012);outline('PRIMARY_FRAME_RIGHT',p2,width=.012)
reference_panel('GLASS_SECONDARY_01',[(243,428),(312,398),(312,709),(243,721)],'Y',-3.04,glass,'SECONDARY_GLASS')
reference_panel('GLASS_SECONDARY_02',[(1210,390),(1457,477),(1457,733),(1210,715)],'X',4.37,glass,'SECONDARY_GLASS')
leftstone,lp=reference_panel('INTERIOR_DARK_MARBLE_BLADE',[(367,323),(479,268),(479,696),(367,710)],'Y',-3.04,dark,'INTERIOR')
reference_panel('INTERIOR_LIGHT_STONE_BLADE',[(312,398),(367,419),(367,710),(312,709)],'X',.32,stone,'INTERIOR')
if LEVEL>=2:
    # Varied partial chambers follow individual visible surfaces, not repeated cubicles.
    for name,px,axis,value,group,tier in [
      ('GLASS_PARTITION_01',[(479,268),(574,309),(574,686),(479,695)],'X',1.82,'INTERIOR',2),
      ('GLASS_PARTITION_02',[(574,309),(655,329),(655,682),(574,686)],'Y',-2.38,'INTERIOR',2),
      ('GLASS_PARTITION_03',[(655,329),(709,352),(709,676),(655,682)],'X',3.17,'INTERIOR',2),
      ('GLASS_CHAMBER_01',[(709,301),(817,252),(817,453),(709,476)],'Y',-2.02,'SECONDARY_GLASS',2),
      ('GLASS_CHAMBER_02',[(646,449),(712,419),(712,678),(646,686)],'Y',-2.48,'SECONDARY_GLASS',2),
      ('GLASS_CHAMBER_03',[(646,449),(786,488),(786,672),(646,686)],'X',3.10,'SECONDARY_GLASS',3),
      ('GLASS_PARTITION_04',[(1097,385),(1165,416),(1165,695),(1097,687)],'X',4.01,'INTERIOR',3),
      ('GLASS_PARTITION_05',[(1283,374),(1350,405),(1350,728),(1283,728)],'X',4.42,'INTERIOR',2),
      ('GLASS_PARTITION_06',[(1350,405),(1400,447),(1400,729),(1350,728)],'X',4.36,'INTERIOR',3),
      ('GLASS_PARTITION_07',[(1119,569),(1300,612),(1300,721),(1119,697)],'X',4.0,'INTERIOR',3),
      ('GLASS_PRIMARY_REAR',[(819,145),(1067,249),(1067,680),(819,666)],'X',3.86,'PRIMARY_GLASS',2)]:reference_panel(name,px,axis,value,glass,group,tier)
    # Transparent roofs use the actual upper boundary vertices of adjacent planes.
    # They remain partial rather than covering the entire sculpture.
    box('GLASS_ROOF_PLANE_01',(3.30,-2.20,3.12),(1.35,1.02,gt),glass,'PRIMARY_GLASS',tier=2)
    box('GLASS_ROOF_PLANE_02',(4.07,-.75,3.96),(.78,1.02,gt),glass,'PRIMARY_GLASS',tier=2)
    box('GLASS_INTERIOR_LEDGE_01',(2.83,-2.27,1.92),(1.1,1.16,gt),glass,'INTERIOR',tier=3)
    reference_panel('INTERIOR_STONE_UPPER_PARTITION',[(709,301),(755,330),(755,463),(709,476)],'X',3.06,dark,'INTERIOR',2)
if LEVEL>=3:
    # A restrained white arch sequence visible through the left/interior glazing.
    for i,(xx,yy) in enumerate([(1.53,-2.37),(2.40,-2.10),(3.20,-1.88)]):
        wallo=box(f'INTERIOR_ARCH_PANEL_{i+1:02d}',(xx,yy,1.43),(.67,.048,1.54),stone,'INTERIOR',.002,tier=3)
        for typ in ['RECT','CIRCLE']:
            if typ=='RECT':
                bpy.ops.mesh.primitive_cube_add(size=1,location=(xx,yy,1.06));cut=bpy.context.object;cut.dimensions=(.36,.30,.83);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
            else:
                bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.18,depth=.30,location=(xx,yy,1.45),rotation=(math.pi/2,0,0));cut=bpy.context.object
            bpy.context.view_layer.objects.active=wallo;mod=wallo.modifiers.new('Arched circulation void','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cut;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cut,do_unlink=True)
    box('INTERIOR_LIGHT_PLATFORM',(2.32,-2.2,.69),(2.38,1.12,.022),stone,'INTERIOR',.002,tier=3)
    for i,(xx,yy,hh) in enumerate([(2.57,-2.45,.36),(2.17,-2.12,.33),(1.37,-2.2,.30),(4.03,.6,.34)]):
        parts=[]
        for loc,size in [((xx,yy,.70+hh*.5),(.064,.050,hh*.46)),((xx-.016,yy,.70+hh*.17),(.019,.022,hh*.34)),((xx+.016,yy,.70+hh*.17),(.019,.022,hh*.34)),((xx-.037,yy,.70+hh*.47),(.018,.019,hh*.37)),((xx+.037,yy,.70+hh*.47),(.018,.019,hh*.37))]:
            bpy.ops.mesh.primitive_uv_sphere_add(segments=10,ring_count=6,radius=1,location=loc);o=bpy.context.object;o.scale=tuple(v/2 for v in size);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);parts.append(o)
        bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=hh*.064,location=(xx,yy,.70+hh*.78));parts.append(bpy.context.object)
        bpy.ops.object.select_all(action='DESELECT')
        for o in parts:o.select_set(True)
        bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=bpy.context.object;o.name=f'OPTIONAL_SCALE_SILHOUETTE_{i+1:02d}';o.data.name=o.name+'_MESH'
        for c in list(o.users_collection):c.objects.unlink(o)
        collections['OPTIONAL_MODULES'].objects.link(o);o.parent=groups['OPTIONAL_MODULES'];o.data.materials.append(metal)
        for f in o.data.polygons:f.use_smooth=True
        objects.append(o);manifest.append({'name':o.name,'function':'Small optional reference scale cue','material':metal.name,'parent':'OPTIONAL_MODULES','visibilityDependencies':['OPTIONAL_MODULES'],'visibilityTier':3,'interaction':'Optional visibility, pending integration'})
    # Restrained inferred rear surfaces provide spatial depth during rotation.
    wall('GLASS_INFERRED_REAR_01','X',(2.0,.3),3.3,2.0,glass,'INTERIOR',tier=3)
    wall('GLASS_INFERRED_REAR_02','Y',(3.35,-.3),2.1,2.45,glass,'INTERIOR',tier=3)
    glass_chamber('GLASS_INFERRED_REAR_CHAMBER',(-1.65,2.05,-.38,2.30),2.48,'PRIMARY_GLASS',sides=('rear','left'),roof=False,tier=3)
    box('GLASS_INFERRED_REAR_ROOF',(.42,1.08,3.17),(2.8,1.92,gt),glass,'PRIMARY_GLASS',tier=3)
bpy.data.objects.remove(temp,do_unlink=True);bpy.data.cameras.remove(camdata)
for material_object in objects:
    fallback=next((m for m in material_object.data.materials if m),metal if material_object.name.startswith('OPTIONAL_') else stone)
    if material_object.name.startswith('OPTIONAL_'):
        material_object.data.materials.clear();material_object.data.materials.append(metal)
        for polygon in material_object.data.polygons:polygon.material_index=0
    elif not material_object.data.materials:material_object.data.materials.append(fallback)
    else:
        for slot_index,slot_material in enumerate(material_object.data.materials):
            if slot_material is None:material_object.data.materials[slot_index]=fallback

def marble_nodes(m,darker=False):
    nt=m.node_tree;n=nt.nodes;l=nt.links;b=n['Principled BSDF'];tex=n.new('ShaderNodeTexCoord');mapping=n.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(.28,.28,.28);l.new(tex.outputs['Object'],mapping.inputs[0])
    noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=2.1;noise.inputs['Detail'].default_value=3;noise.inputs['Roughness'].default_value=.55;l.new(mapping.outputs[0],noise.inputs['Vector'])
    distort=n.new('ShaderNodeVectorMath');distort.operation='SCALE';distort.inputs[3].default_value=.43;l.new(noise.outputs['Color'],distort.inputs[0])
    add=n.new('ShaderNodeVectorMath');add.operation='ADD';l.new(mapping.outputs[0],add.inputs[0]);l.new(distort.outputs[0],add.inputs[1])
    vein=n.new('ShaderNodeTexNoise');vein.inputs['Scale'].default_value=2.2;vein.inputs['Detail'].default_value=4;vein.inputs['Roughness'].default_value=.62;l.new(add.outputs[0],vein.inputs['Vector'])
    ramp=n.new('ShaderNodeValToRGB');r=ramp.color_ramp
    marks=[(0,(.19,.21,.23,1) if darker else (.82,.825,.82,1)),(.465,(.22,.24,.26,1) if darker else (.85,.85,.84,1)),(.476,(.015,.018,.022,1)),(.482,(.06,.07,.08,1)),(.495,(.25,.27,.29,1) if darker else (.86,.86,.85,1)),(1,(.30,.32,.33,1) if darker else (.87,.87,.86,1))]
    r.elements.remove(r.elements[1]);r.elements[0].position=marks[0][0];r.elements[0].color=marks[0][1]
    for pos,color in marks[1:]:e=r.elements.new(pos);e.color=color
    l.new(vein.outputs['Fac'],ramp.inputs[0])
    cloud=n.new('ShaderNodeValToRGB');cloud.color_ramp.elements[0].color=(.72,.73,.74,1);cloud.color_ramp.elements[1].color=(1,1,1,1);l.new(noise.outputs['Fac'],cloud.inputs[0])
    mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;l.new(ramp.outputs['Color'],mix.inputs[1]);l.new(cloud.outputs['Color'],mix.inputs[2]);l.new(mix.outputs[0],b.inputs['Base Color'])
    fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=120;fine.inputs['Detail'].default_value=2;l.new(tex.outputs['Generated'],fine.inputs['Vector'])
    bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.075;bump.inputs['Distance'].default_value=.008;l.new(fine.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],b.inputs['Normal'])
    return ramp
if LEVEL>=3:
    marble_nodes(marble);marble_nodes(dark,True)
    # Continuous world-space generated pattern; unique slab bake avoids repeated tiles.

def studio_object(o):
    for c in list(o.users_collection):c.objects.unlink(o)
    studio.objects.link(o)
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
backdrop=mat('REVIEW_BACKDROP',(.86,.865,.87),.5)
bpy.ops.mesh.primitive_plane_add(size=200);ground=bpy.context.object;ground.name='REVIEW_GROUND';studio_object(ground);ground.location.z=-.005;ground.data.materials.append(backdrop)
for name,loc,power,size in [('KEY',(-7,-10,14),2400,9),('FILL',(10,-3,9),1600,7),('RIM',(-1,8,11),2700,6)]:
    bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name='REVIEW_LIGHT_'+name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(0,0,2.8));studio_object(o)
scene.world=bpy.data.worlds.new('Luminous neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.9,.92,.95,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=1.4 if FINAL else .6
camera_data=json.load(open(os.path.join(SRC,'camera-match.json')))
cameras={}
for name,loc,target in [('CAM_REFERENCE_MATCH',camera_data['location'],(0,0,camera_data['location'][2])),('CAM_FRONT',(0,-20,4),(0,0,3.1)),('CAM_REAR',(0,20,4),(0,0,3.1)),('CAM_LEFT',(-20,0,4),(0,0,3.1)),('CAM_RIGHT',(20,0,4),(0,0,3.1)),('CAM_ELEVATED',(13,-17,16),(0,0,2.4)),('CAM_HERO',(12,-17,8),(0,0,3))]:
    bpy.ops.object.camera_add(location=loc);o=bpy.context.object;o.name=name;aim(o,target);studio_object(o);cameras[name]=o
    if name=='CAM_REFERENCE_MATCH':
        o.rotation_euler=camera_data['rotationEuler'];o.data.lens=camera_data['lens'];o.data.shift_x=camera_data['shiftX'];o.data.shift_y=camera_data['shiftY'];o.data.sensor_width=36;o.data.sensor_fit='HORIZONTAL'
    else:o.data.type='ORTHO';o.data.ortho_scale=14 if name in ['CAM_HERO','CAM_ELEVATED'] else 12.2
scene.camera=cameras['CAM_REFERENCE_MATCH']
bpy.ops.object.select_all(action='DESELECT');root.select_set(True);bpy.context.view_layer.objects.active=root
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.overlay.show_overlays=False
            area.spaces.active.shading.type='SOLID';area.spaces.active.shading.color_type='MATERIAL'
            area.spaces.active.region_3d.view_distance=17;area.spaces.active.region_3d.view_location=(0,0,3)
if not FINAL:
    fn=os.path.join(ROOT,'03_RENDERS','iteration_'+STAGE+'_reference.png')
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'01_SOURCE',f'SITE00_Build_Object_V2_Pass_{STAGE}.blend'))
    scene.render.filepath=fn;bpy.ops.render.render(write_still=True)
    print('PASS_COMPLETE',STAGE,len(objects));sys.exit()

# Bake the two stone families to per-object UV atlases for portable GLB/FBX.
for uv_object in objects:
    if not uv_object.data.uv_layers:
        bpy.ops.object.select_all(action='DESELECT');uv_object.select_set(True);bpy.context.view_layer.objects.active=uv_object
        bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
def bake_stone(obj,m,size,filename):
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.025);bpy.ops.object.mode_set(mode='OBJECT')
    im=bpy.data.images.new(filename,width=size,height=size,alpha=False);im.filepath_raw=os.path.join(SRC,'materials',filename+'.png');im.file_format='PNG'
    node=m.node_tree.nodes.new('ShaderNodeTexImage');node.name='EXPORT_BAKED_BASECOLOR';node.image=im;m.node_tree.nodes.active=node
    scene.render.bake.use_pass_direct=False;scene.render.bake.use_pass_indirect=False;scene.render.bake.use_pass_color=True;scene.render.bake.margin=16
    saved_samples=scene.cycles.samples;scene.cycles.samples=1
    bpy.ops.object.bake(type='DIFFUSE');scene.cycles.samples=saved_samples
    im.save();im.pack();return im
stone_images={marble.name:bake_stone(foundation,marble,2048,'white-marble-atlas'),dark.name:bake_stone(leftstone,dark,1024,'gray-marble-atlas')}
# Preserve the Cycles source graph; exports switch temporarily to explicit image PBR materials.
text=bpy.data.texts.new('V2_REFERENCE_AND_REVIEW_NOTES');text.write('Authority: supplied architectural photograph. Single-view inferred reconstruction, founder approval pending. See 05_DOCUMENTATION. V1 unchanged. Master uses Cycles; GLB portable materials are separate export approximations. No production integration.')
bpy.ops.object.select_all(action='DESELECT');root.select_set(True);bpy.context.view_layer.objects.active=root
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(SRC,'SITE00_Build_Object_V2.blend'))
material_report=[]
for m in materials:
    bs=m.node_tree.nodes['Principled BSDF'];material_report.append({'name':m.name,'baseColor':list(bs.inputs['Base Color'].default_value),'roughness':bs.inputs['Roughness'].default_value,'metallic':bs.inputs['Metallic'].default_value,'transmission':bs.inputs['Transmission Weight'].default_value,'ior':bs.inputs['IOR'].default_value,'blenderProcedural':m.name in stone_images,'webOverride':('Set thickness/attenuation via manifest; glTF PBR approximation' if m in [glass,red] else 'UV atlas PBR base colour' if m.name in stone_images else 'Standard PBR')})
with open(os.path.join(DOC,'material-manifest.json'),'w') as f:json.dump(material_report,f,indent=2)
with open(os.path.join(DOC,'module-manifest.json'),'w') as f:json.dump({'root':'BUILD_OBJECT_ROOT','modules':manifest,'builderContractVerified':False,'canonicalFields':['layer_count_hint','structural_complexity','work_modules']},f,indent=2)
with open(pf,'w') as f:json.dump(P,f,indent=2)
original={}
for m in [marble,dark]:
    bs=m.node_tree.nodes['Principled BSDF'];original[m.name]=[(l.from_socket,l.to_socket) for l in list(m.node_tree.links) if l.to_node==bs]
    for l in list(m.node_tree.links):
        if l.to_node==bs:m.node_tree.links.remove(l)
    im=stone_images[m.name];tex=m.node_tree.nodes['EXPORT_BAKED_BASECOLOR'];m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
def select_asset():
    bpy.ops.object.select_all(action='DESELECT')
    for o in asset.all_objects:o.select_set(True)
    bpy.context.view_layer.objects.active=foundation
select_asset()
def export_glb(filename):
    bpy.ops.export_scene.gltf(filepath=os.path.join(EXP,filename),export_format='GLB',use_selection=True,export_apply=True,export_extras=True,export_yup=True,export_cameras=False,export_lights=False)
export_glb('SITE00_Build_Object_V2_High.glb')
for m in [marble,dark]:
    tex=m.node_tree.nodes['EXPORT_BAKED_BASECOLOR'];im=tex.image.copy()
    if im.packed_file:im.unpack(method='REMOVE')
    im.scale(1024 if m==marble else 512,1024 if m==marble else 512);im.filepath_raw=os.path.join(SRC,'materials',m.name.lower()+'-web.png');im.save();im.pack();tex.image=im
for o in objects:
    for mod in o.modifiers:
        if mod.type=='BEVEL':mod.segments=1
export_glb('SITE00_Build_Object_V2_Web.glb')
for m in [marble,dark]:m.node_tree.nodes['EXPORT_BAKED_BASECOLOR'].image=stone_images[m.name]
for o in objects:
    for mod in o.modifiers:
        if mod.type=='BEVEL':mod.segments=2
bpy.ops.export_scene.fbx(filepath=os.path.join(EXP,'SITE00_Build_Object_V2_DCC.fbx'),use_selection=True,object_types={'MESH','EMPTY'},use_mesh_modifiers=True,add_leaf_bones=False,axis_forward='-Z',axis_up='Y',apply_unit_scale=True,path_mode='COPY',embed_textures=True)
for m in [marble,dark]:
    bs=m.node_tree.nodes['Principled BSDF']
    for l in list(m.node_tree.links):
        if l.to_node==bs:m.node_tree.links.remove(l)
    for a,b in original[m.name]:m.node_tree.links.new(a,b)
if os.environ.get('V2_EXPORT_ONLY')=='1':
    print('V2_EXPORTS_COMPLETE',len(objects));sys.exit()
# First final image is always the matched reference view, before other angles.
scene.camera=cameras['CAM_REFERENCE_MATCH'];scene.render.filepath=os.path.join(REN,'SITE00_V2_Reference_Match.png');bpy.ops.render.render(write_still=True)
scene.cycles.samples=32;scene.render.resolution_x=1100;scene.render.resolution_y=800
for name in ['CAM_HERO','CAM_FRONT','CAM_REAR','CAM_LEFT','CAM_RIGHT','CAM_ELEVATED']:
    scene.camera=cameras[name];scene.render.filepath=os.path.join(REN,'SITE00_V2_'+name[4:].title()+'.png');bpy.ops.render.render(write_still=True)
print('V2_COMPLETE',len(objects),'MATERIALS',len(materials))
