# Known limitations and review gates

1. A single supplied image cannot establish real measurements, hidden topology, complete plan, panel joints, material specifications, or camera metadata. The model is a genuine multi-object 3D reconstruction with inferred depth, not a recovered measured building.
2. The reference-facing major planes were reconstructed by intersecting image-landmark camera rays with inferred vertical planes. Some faces retain slightly non-orthogonal quadrilateral boundaries suggested by the image. Inferred plane depths are constrained to the foundation footprint and floor contact; this changes some lower projected edges. This is not proof that the photographed/image-generated architecture has those exact junctions.
3. Overall silhouette, red placement, and open glass/stone arrangement are much closer than V1, but exact reference fidelity is **PARTIAL**. Glass reflection/edge density, internal scale, the red's material response, and the marble veining pattern remain visibly different. See the actual side-by-side comparison.
4. Rear and upper hidden surfaces are restrained inferred planes. They do not claim to recover unseen architecture. Review all seven camera renders before approving the model.
5. Optional scale silhouettes are simplified geometric cues, not replicas of specific people.
6. Web PBR is an approximation of Cycles. Stone bump is master-only; glass/acrylic attenuation is separately documented. Web GLB loads in the supplied local Three.js viewer, but mobile performance and production Builder behavior were not benchmarked.
7. The requested Builder contract is absent locally. All parameter mapping is tentative; no state/parameter logic was changed.
8. Maya and Unreal were not used to import or present the asset, as their work is optional/deferred for this sprint. FBX was verified by Blender reimport only.
9. The local GPU/OptiX kernel failed to compile with the installed driver. CPU Cycles produced the final renders; no drivers or machine settings were changed.
10. Founder approval is pending. No production release, merge, deployment, feature flag, or Three.js Builder replacement was performed. No paid generation service or AI generation credits were used.
