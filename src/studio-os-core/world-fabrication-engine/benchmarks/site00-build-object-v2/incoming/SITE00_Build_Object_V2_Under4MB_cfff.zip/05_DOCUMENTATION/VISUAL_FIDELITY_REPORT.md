# Visual fidelity evaluation — PARTIAL MATCH

Reference: supplied `46D454FE-F932-455E-B74E-4BFA5AB18D90.jpg`.
Evidence: `04_COMPARISONS/SITE00_V2_Reference_Comparison.png`, the genuine matched render, and six rotating inspection views. No numerical overall fidelity score is assigned.

| Feature | Result | Observation |
|---|---|---|
| Overall architectural silhouette | PARTIAL MATCH | Tall centre-right red planes, stepped side glass, left stone blade, and continuous low foundation follow the reference. Fine upper silhouette and overlapping planes remain less complex. |
| Red height and projected placement | MATCH | Dominant outer-plane image landmarks were used directly, with inferred depth corrected to stay over the pedestal. Tallest visible red tip and centre-right footprint are preserved closely. This is projected similarity, not measured geometry. |
| Red width / interlocking geometry | PARTIAL MATCH | Two main vertical surfaces and three internal red partitions with horizontal layering replace V1's doorway. Their depth and junctions are inferred; the reference has finer edge divisions and stronger local translucency contrast. |
| Glass volume count and density | PARTIAL MATCH | Major transparent planes, secondary chambers, roof sheets, and partitions are separate. The reference shows more visible seams, reflection edges, and compact layered detail; equivalent visual density is not yet achieved. |
| Glass transparency | MATCH | Thin closed glass solids transmit the interior rather than using painted opaque windows. Final edge/reflection appearance remains renderer dependent. |
| Interior visibility | PARTIAL MATCH | Open sightlines, partial chambers, thin stone panels, three arched interior panels, and optional small silhouettes remain visible. Their scale and full arrangement cannot be recovered exactly from one view. |
| Marble foundation geometry | MATCH | One continuous low rectangular plinth remains selectable. Relative camera/base framing is close; texture appearance is a separate gate. |
| Marble appearance | PARTIAL MATCH | Baked/procedural gray veins are organic and non-tiled across the slab. Their distribution, grain, and contrast differ from the approved marble, whose material source is unavailable. |
| Roof openness | MATCH | Opaque white roof slabs are removed. Partial transparent roof sheets and open-top assemblies expose the interior. |
| Relative proportions | PARTIAL MATCH | Major reference-facing proportions were constrained by image landmarks. Some quadrilateral boundaries and depth relationships are inferred to reconcile a single view. |
| Structural complexity | PARTIAL MATCH | Layered panels, interior blades, arches, roof sheets, and fine frame outlines form an asymmetrical sculpture. The reference still has richer micro-structure and optical detail. |
| Depth / rotation | PARTIAL MATCH | All views show actual solids, interior layers, rear returns, and one cohesive base. Unseen rear plan and junctions are plausible additions, not recovered facts. |
| Hidden geometry / physical dimensions | UNVERIFIABLE FROM REFERENCE | No complete plan, true scale, or camera metadata was supplied. |

## Iteration evidence

* A: broad silhouette. An initial dimension-based attempt cropped the top; rejected. The retained A render uses image-constrained major planes and the fitted low camera.
* B: red-plane enclosure and internal layering. A conventional door frame is not retained.
* C: individual glass chambers/partitions. A coplanar overlap produced a black strip and was corrected before the final pass.
* D: stone and interior architecture. Initial veining was too fine-grained; material scale was revised.
* E: material/lighting comparisons. The first Standard render was overexposed; the AgX revision was too gray/pale. The final camera-matched render uses adjusted exposure, a red absorption shader, revised marble contrast, and a neutral studio.
* F: front/rear/left/right/elevated/hero inspection. Some inferred panes extended outside the pedestal; their inferred depth was constrained along camera rays and low vertices were brought above the foundation. The final validated asset stays within the 10 × 7.5 model-unit footprint. Structural geometry checks were rerun after that correction.

The matched render was generated before the other final camera views. The comparison uses the same normalized architectural crop on both sides and proportional resampling; no colour correction, perspective distortion, or pasted reference architecture is used on the render side.

## Camera evidence boundary

Six manually picked base corners were fitted to an assumed rectangular foundation by a reproducible least-squares procedure. The input landmarks and residual pixel offsets are recorded in `01_SOURCE/camera-match.json`; one corner retains a larger residual. This camera fit supports a consistent comparison view. It is not a numerical visual-fidelity score or a claim of recovered camera metadata.

## Decision

**PARTIAL MATCH — founder review pending.** V2 corrects the main V1 architecture errors and provides a reviewable modular reconstruction. It should not be called an exact copy or a production-approved asset. The next decision is founder architectural review; no Unreal presentation, Maya refinement, or Builder production integration is authorized by this completion.
