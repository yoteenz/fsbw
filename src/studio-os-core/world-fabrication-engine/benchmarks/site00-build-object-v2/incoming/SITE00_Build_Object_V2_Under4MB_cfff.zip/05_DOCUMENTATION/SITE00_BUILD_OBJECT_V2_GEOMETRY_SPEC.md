# V2 pre-fabrication architectural reconstruction specification

Authority: `46D454FE-F932-455E-B74E-4BFA5AB18D90.jpg`, 1672 × 941 px. The original Rodin mesh is supplemental; V1 geometry is superseded, while its fabrication/export/validation functions are reused. No V1 file will be overwritten.

1. **Silhouette:** asymmetrical stepped transparent architecture; tallest red plane near the centre-right, low side chambers, taller glass behind. No conventional solid roofed pavilion.
2. **Base proportions:** one broad rectangular foundation, covering approximately image x=180–1490. The nearest corner projects near x=890. The visible marble faces are deep enough to carry conspicuous veins, but remain low relative to the core. The perspective makes the closest face taller on screen. A 10 × 7.5 × 0.65 unit model is an initial relative-scale convention, not measured metres.
3. **Primary glass:** an approximately five-unit-high open framed chamber across the middle; tall clear rear-right enclosure adjacent to the red core. Large planes, few continuous thin edges, no generic window grid.
4. **Secondary glass:** low front-left enclosure and lower right wing; partial elevated internal chamber. Each consists of independent thin closed panels with visible edges and deliberate open sides.
5. **Foundation:** continuous white polished marble slab, fine edge bevel, organic branching dark-gray veins. No separate scattered platforms. Clear upper foundation plate is a thin transparent surface.
6. **Red centerpiece:** several full-height intersecting red acrylic planes forming a narrow, deep threshold enclosure. Highest visible edge near image (1067,77); left red edge near (819,185). Interior red partitions and horizontal ledges remain visible through the outer planes. This is not a conventional door frame and has no thick lintel.
7. **Interior:** tall left gray marble panel near image x=367–480; adjacent shorter stone panel; central suspended-looking partial chamber, layered glass partitions, restrained white arched interior panels and small optional scale silhouettes grounded in the image.
8. **Frames:** very thin dark reflective profiles trace the primary chamber and select corners. Thin clear/white seam edges trace other panels. Avoid thick white columns.
9. **Roof:** glass sheets over selected chambers; some open tops and uninterrupted views into the interior. No large white opaque overhead slabs.
10. **Heights/offsets:** initial core height 6.3; rear clear enclosure 6.1; main chamber 4.9; left stone panel 4.5; intermediate chamber 4.0; low wings 3.1–3.4; plinth 0.65. Refine after reference-facing renders.
11. **Overlap:** glass wings intersect in projection; chamber bounds and interior passages overlap spatially, without duplicate coplanar faces. Red partitions form the dominant layered internal enclosure.
12. **Camera:** low three-quarter architectural view with vertical convergence largely restrained and substantial near/far perspective. Match the front plinth corner near the image centre, red core above it, low side chambers, and wide framing. Use a perspective camera and record its parameters; calibration is inferred rather than recovered metadata.
13. **Material behavior:** low-iron clear glass with sharp specular edges; saturated transmitting red acrylic with darker intersections; white/gray veined marble; restrained metallic frame; white interior panels. Master uses Cycles. GLB uses baked stone maps plus glTF transmission/IOR/volume where supported, with separately documented differences.
14. **Uncertainty:** unseen rear walls, exact depth, panel junctions, thickness, full circulation, true scale, camera metadata, and image-generation inconsistencies cannot be proven from this single image. Rear reconstruction stays within the visible rectilinear language.

## Iteration and evidence

Produce and inspect A silhouette, B red-core, C glass/partition, D stone/interior, and E material/lighting renders in that order. The final matched render precedes hero/orthogonal/elevated views. Compare the genuine 3D render beside an architectural crop of the reference. Record feature-by-feature MATCH / PARTIAL MATCH / FAIL / UNVERIFIABLE observations rather than an invented score.

## Modular integration boundary

Root `BUILD_OBJECT_ROOT` with `FOUNDATION`, `RED_THRESHOLD`, `PRIMARY_GLASS`, `SECONDARY_GLASS`, `INTERIOR`, `STRUCTURAL_FRAMES`, and `OPTIONAL_MODULES`. Stable object identifiers are exported as node names and extras. The only Builder fields considered are `layer_count_hint`, `structural_complexity`, and `work_modules`; mapping remains pending because the requested repository contract is absent locally. Fabrication dimensions are internal reconstruction controls, not new canonical Builder fields.

## Post-iteration resolution

The height assumptions in item 10 were rejected by the first matched render. Final principal surfaces use visible pixel landmarks intersected with inferred vertical depth planes through the calibrated camera. The finished model's maximum height is approximately 4.374 model units, not the initial 6.3-unit hypothesis. Some quadrilaterals preserve the projected shape instead of asserting perfectly rectangular measured walls. Hidden rear planes stay in the same thin rectilinear language. Inferred depths were constrained to the pedestal footprint after rotational inspection, and any lower vertices below its upper plate were raised to sensible contact. This preserves a genuine 3D asset while acknowledging the ambiguity of a single reference view.
