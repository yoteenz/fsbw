# SITE 00 Build Object V2 — founder architectural review

Sprint: `P0.SITE00.BUILDER.BUILD-OBJECT.V2-REFERENCE-FIDELITY-ARCHITECTURAL-RECONSTRUCTION1`.

This package replaces V1's unrelated doorway and opaque roofed pavilion with a reference-driven sculpture of layered thin glass planes, a tall multi-plane red acrylic enclosure, a continuous marble plinth, stone blades, and restrained interior architecture. V1 and the original Rodin GLB remain unchanged.

**Review status: PARTIAL visual match; founder approval pending.** Export/geometry checks and creative fidelity are different gates. Read `05_DOCUMENTATION/VISUAL_FIDELITY_REPORT.md` and view the side-by-side comparison before deciding APPROVED / APPROVED WITH CORRECTIONS / REVISE / REJECTED.

## Package

* `01_SOURCE/`: editable V2 Blender master, fabrication/validation/comparison scripts, camera calibration data, authoring parameters, and packed/exported material resources.
* `02_EXPORTS/`: high GLB, web GLB, FBX, and local Three.js review viewer.
* `03_RENDERS/`: matched camera, hero, front, rear, left, right, elevated, and controlled A–E iteration evidence. These are actual Blender renders.
* `04_COMPARISONS/`: original approved reference, architectural crop, genuine reference-versus-render comparison, and reproducible crop/alignment method.
* `05_DOCUMENTATION/`: pre-fabrication specification, module/material manifests, structural export validation, visual evaluation, limitations, target-app preparation, integration notes, and lineage/version manifest.

Open `01_SOURCE/SITE00_Build_Object_V2.blend` in Blender 5.2.2. The reference-matched camera is active. Switch to rendered shading to inspect physical materials; the final review renders are included for a clean view without viewport noise. The master retains individual objects, collections, modifiers, Cycles materials, seven cameras, and studio lighting. The studio is excluded from every asset export.

To reproduce: run Blender in background mode with `--python 01_SOURCE/fabricate_v2.py -- E`. Stages A/B/C/D produce staged matched-camera geometry evidence; E bakes portable stone maps, saves the master, exports both GLBs and FBX, renders the matched camera first, then the other views. `V2_EXPORT_ONLY=1` skips rendering after fabrication/export. The scripts write only within this package. CPU is the verified rendering path.

Run Blender with `--python 01_SOURCE/validate_v2.py` to reproduce structural and round-trip checks. Run `01_SOURCE/create_comparison.py` with Python + Pillow after final rendering to rebuild the comparison. The comparison uses proportional cropping/resizing only; reference pixels are never pasted onto the Blender model or into its rendered panel.

The viewer requires localhost HTTP serving and public pinned Three.js JavaScript modules. Run `node 01_SOURCE/serve-viewer.cjs` from the extracted package to serve it at `http://127.0.0.1:4183`. It does not upload the GLB. This sprint tested a local viewer; it did not integrate into the real Builder or benchmark mobile devices.

All scale values are artistic conventions; no physical dimensions were recovered. The requested Builder contract was absent in local repositories. Proposed mappings to `layer_count_hint`, `structural_complexity`, and `work_modules` remain unverified. No new canonical fields were created.

Unreal and Maya imports are NOT TESTED and no scenes were created there. FBX material conversion requires target-specific work after founder approval. No production changes or paid generation were performed.
