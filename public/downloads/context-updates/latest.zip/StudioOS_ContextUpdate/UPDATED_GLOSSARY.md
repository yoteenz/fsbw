# UPDATED GLOSSARY

New or updated shorthand, terminology, and glossary entries.

## AI Context Capsule — `AI_CONTEXT.md` (modified)

```markdown
# AI Context — Studio OS High-Level Onboarding

**Capsule:** StudioOS_ContextCapsule_v0.1 · **0.3.2**  
**Last updated:** 2026-07-12  
**Purpose:** Compressed orientation for external AI — not a substitute for full repo bibles (paths below point to canonical docs in the host repository)

---

## 1. Current vision

**Studio OS** is a standalone creative operating system — a **living headquarters** where every capability has a physical home in **Studio World™**. Frontal Slayer is the first organization; the platform is multi-company native.

The founder is building:

- A **place-driven** OS (not menu-driven SaaS)
- **Genesis** as constitutional creative DNA
- **Studio World** as immersive spatial experience
- **Studio Institute** as the learning operating system woven through the city
- **Production governance** for real asset generation (FAL, governed routes)

**North star:** Users feel like they **travel through a civilization**, not open software pages.

---

## 2. Products (layers)

| Layer | What it is | Code / docs home |
|-------|------------|------------------|
| **Build-a-Wig / Frontal Slayer storefront** | Customer commerce, Build-a-Wig, PSA, bookings | `src/pages/`, `motherboard/CORE.md` |
| **Studio OS platform** | Admin HQ, workspaces, org boundary | `src/studio-os-core/`, `docs/studio-os/` |
| **Genesis Core** | Constitutional DNA, company genome, experience runtime | `docs/studio-os/genesis/`, `src/studio-os-core/genesis/` |
| **Studio World** | Spatial districts, Atlas, Knowledge Graph, civilization | `docs/studio-world/` |
| **Studio Institute** | Learning OS, professors, Learning DNA | `docs/studio-institute/` |
| **Experience Lab** | Brand preview / validation render mode | `src/studio-os-core/experience-lab-runtime/` |
| **World Compiler** | Scene assembly pipeline (shell → layers → mount) | `src/studio-os-core/scene-stack/world-compiler/` |
| **Creative Direction Studio** | Scene Stack UI, layer generation | `src/components/admin/studio-os/creative-direction-studio/` |
| **Black Box / Flight Recorder** | Operational diagnostics | `src/studio-os/diagnostics/` |

---

## 3. Architecture (technical)

### Stack

- **Frontend:** React 19, TypeScript, Vite 5, React Router 6, Tailwind
- **Backend:** Vercel serverless `api/`, Supabase (auth, DB, storage)
- **Generation:** FAL (`fal-ai/nano-banana-pro/edit`), governed via Creative Production Gateway
- **Deploy:** Vercel production on `master` — **one push = one deploy**

### Code layout

```
src/studio-os-core/     — Platform logic (reusable)
src/workspaces/         — Brand implementations (Frontal Slayer first)
src/studio-os/          — Application wiring, diagnostics
motherboard/            — Cursor agent persistent memory
docs/studio-os/         — Product architecture bible
docs/studio-world/      — Spatial / civilization canon
docs/ai-collaboration/  — This ChatGPT onboarding package
```

### Boot paths (2026-07-10)

```
index.html → pre-main-probe.js → entry-dispatch
  /__studio-os-*  → diagnostic-main (isolated, no App.tsx)
  else            → main-app → global-boot → main-legacy
```

### Multi-company routes

Company-scoped: `/admin/studio/companies/{companySlug}/...`  
Global: command-center, atlas, mission-control, etc.  
Never hardcode `frontal-slayer` in new company-scoped components.

---

## 4. Genesis

**Genesis** is the constitutional layer — company genome, experience DNA, organizational memory, creative operating system rules.

Key docs:

- `docs/studio-os/genesis/README.md`
- `docs/studio-os/genesis/GENESIS_V1_CONSTITUTIONAL_CLOSURE.md`
- `docs/studio-os/genesis/EXPERIENCE_LAB_PLATFORM.md`

Persisted client-side as `genesis_v1` (validated/quarantined on diagnostic boot).

---

## 5. Studio World

Permanent spatial blueprint — ten foundational districts (Institute, Works, World District, Forge, Labs, Research, Council, Archive, Observatory, Arena).

Key docs:

- `docs/studio-world/STUDIO_WORLD_MASTER_PLAN.md` — where things live
- `docs/studio-world/STUDIO_ATLAS_BIBLE.md` — geographic projection
- `docs/studio-world/STUDIO_WORLD_LIVING_KNOWLEDGE_GRAPH_BIBLE.md` — intelligence layer
- `docs/studio-world/STUDIO_WORLD_CIVILIZATION_BIBLE.md` — culture / belonging

**Rule:** Every new capability answers **"Where does this live?"** first.

---

## 6. Studio Institute

Spatial learning OS — professors, simulations, Learning DNA Global Engine.

Key docs:

- `docs/studio-institute/STUDIO_INSTITUTE_BIBLE.md`
- `docs/studio-institute/STUDIO_INSTITUTE_VISION_BIBLE_V3.md`
- `docs/studio-institute/STUDIO_INSTITUTE_LEARNING_DNA_BIBLE.md`

---

## 7. Genesis Core (runtime)

The executable Genesis layer — Genesis Orb, experience engine, brand discovery, narrative intelligence. Distinct from Genesis *documentation*.

Orb = primary navigation / attention surface in HQ.  
Experience Engine = runtime state for experiences and previews.

---

## 8. Experience Lab

Validation render mode for previewing brand environments **without** promoting to Asset Registry.

- Route context: company + concept (A/B/C) previews
- Uses ephemeral shell pipeline + Scene Stack layer generation
- Diagnostic mode: `?compilerDiag=1` — one tap = one compile run, freeze on Layer 1 failure
- **Not production-canonical** until governance + authorization satisfied

---

## 9. World Compiler

Assembles a **station** through ordered stages:

1. Environment shell (reference / locked)
2. Layer 1: **Signature Landmark™** (`signature-landmark` / `mount-landmark`)
3. Subsequent Scene Stack layers (furniture, lighting, atmosphere, …)

Compile reports, scene graph, render validation in `src/studio-os-core/scene-stack/world-compiler/`.

---

## 10. Department Package Registry

Executable department packages (e.g. `studio-world-atlas`) must register in `DepartmentPackageRegistry` at boot. Missing package = pipeline failure before Layer 1.

Recent fix: bundled `studio-world-atlas` golden package + boot validation.

---

## 11. Current roadmap (compressed)

| Phase | Focus | Status |
|-------|-------|--------|
| Platform stabilization | Boot bisection, storage guard, diagnostic isolation | In progress |
| Experience Lab render pipeline | Shell → Layer 1 → full stack | **In Progress** — Layer 1 repair shipped; production verify pending |
| Studio World canon | Master Plan, Atlas, Knowledge Graph, Civilization bibles | Docs delivered |
| Institute intelligence | V3 Cognitive Engine, Learning DNA bibles | Docs delivered |
| Creative Direction Studio | Scene Stack production UI | Active, coupled to compiler |
| Governed generation | ProductionAuthorization on all material routes | Production gate live |
| Cross-context sync | Motherboard ↔ Unified Onboarding Pack interoperability | Shipped (v1.2.2 / capsule 0.3.2) |

Detailed roadmap: `docs/studio-world/010_IMPLEMENTATION_ROADMAP.md`, `motherboard/CORE.md`.

---

## 12. Current blockers (2026-07-12)

| Priority | Blocker | Detail | Classification |
|----------|---------|--------|----------------|
| **P0** | Layer 1 `signature-landmark` governed generation | Repair `7a8869404` shipped — JSON diagnostics, FAL preservation, maxDuration 120. **Incident NOT resolved.** Founder mobile verification pending on **both** Creative Studio and Experience Engine (shared runtime). | **In Progress** |
| **P0** | Diagnostic normal-tab reliability | Isolation shipped; device verification pending | **In Progress** |

**Do not say Creative Studio was restored.** Both surfaces share `/admin/studio/experience-lab`.

**Leading explanation for original non-JSON 500:** Vercel platform termination / invocation failure (`Inference`). **Not definitively proven** until authenticated production traces confirm.

**Proven failure position:** After M1–M7 and shell lock — first failure at Layer 1 `signature-landmark` (`Documented Fact`).

**UI caveat:** "Retry Shell Layer" is not reliable failure-stage evidence.

---

## Motherboard and Live Frontal Slayer Implementation Context

The **Motherboard** (`motherboard/`) is Cursor's in-repository implementation memory. It complements this capsule; it does not replace it.

| File | Role |
|------|------|
| `motherboard/CORE.md` | Persistent storefront + Studio OS implementation rules |
| `motherboard/CODEBASE.md` | Live codebase map (refreshed on snapshot) |
| `motherboard/MEMORY.md` | Append-only implementation history |

**When to consult Motherboard:** Tasks touching actual Frontal Slayer commerce behavior, admin flows, Build-a-Wig, PSA, bookings, deployment policy, or Studio OS code paths in `src/`.

**Authority:** `CURRENT_HANDOFF.md` and `KNOWN_BLOCKERS.md` **override** older Motherboard `MEMORY.md` for current blockers and runtime status. `CORE.md` + `CODEBASE.md` override old `MEMORY` for current implementation behavior.

**Frontal Slayer context (concise):**

- First production organization and active commerce host in this repository
- Includes storefront, account, admin, commerce, Build-a-Wig, PSA, bookings, Studio OS, Institute, diagnostics, and governed generation
- **Mobile-first** real-device verification is the default
- Production deploys from `master` — **one governed task = one commit + one deploy**
- **Composer** performs implementation; external AI does not commit unless founder changes operating model

Do not copy all of `motherboard/CORE.md` into this capsule — use the cross-reference above.

---

## 13. Canonical terminology (short list)

Full definitions: `AI_GLOSSARY.md`

| Term | One line |
|------|----------|
| Genesis Core | Constitutional runtime + DNA vault |
| Genesis Orb | HQ navigation / attention surface |
| Studio World | Spatial city housing all capabilities |
| Studio Atlas | Geographic map of the city |
| Experience Lab | Validation preview mode for brand environments |
| World Compiler | Station assembly pipeline |
| Scene Stack | Ordered generatable layers for a station |
| Department Package | Executable unit registered for a department |
| Black Box | Global flight recorder / diagnostic event bus |

---

## 14. Agent context systems

| System | Audience | Role |
|--------|----------|------|
| Unified Onboarding Pack | External AI (ChatGPT) | Deterministic architecture + founder onboarding |
| `docs/ai-collaboration/` | External AI | Collaboration docs and templates |
| `motherboard/` | Cursor agents | Implementation memory — CORE, CODEBASE, MEMORY |
| This capsule | External AI + repo agents | Operational handoff, blockers, compressed orientation |

**Cross-context workflow:**

- External AI: complete onboarding pack → then reconcile `CURRENT_HANDOFF`, `KNOWN_BLOCKERS`, and (with repo access) `motherboard/CORE.md`, `motherboard/CODEBASE.md`, latest `MEMORY.md`
- Cursor agents: auto-load Motherboard at chat start; for Studio OS work also read `CURRENT_HANDOFF` + `KNOWN_BLOCKERS`
- Neither system replaces the other; newer operational evidence wins over historical memory

---

## 15. Verification culture

- **Mobile-first** — real phone preferred over desktop DevTools
- **Normal tab** — private/incognito is not acceptable as permanent workflow
- **Forensic before repair** — preserve failure state, prove transition
- **One deploy per task** — Composer commits once per founder request

---

*End of AI Context v1.0.0*

```

## AI Context Capsule — `CHATGPT_OPERATING_MANUAL.md` (modified)

```markdown
# ChatGPT Operating Manual™

**Capsule:** StudioOS_ContextCapsule_v0.1 · v0.1.0  
**Authority:** Canonical onboarding document for founder ↔ AI collaboration  
**Audience:** ChatGPT and any external AI acting as **AI Creative Director** partner  
**Not a substitute for:** Studio OS Bible, Genesis constitution, Cursor motherboard, or company brand docs

---

## 1. Purpose

This manual defines **how to become the founder's AI Creative Director** — not merely a code assistant or chatbot.

Studio OS is a multi-year creative operating system. Context spans Genesis, Studio World, Experience Lab, World Compiler, Institute, and production governance. No single chat holds that history.

This manual + the companion files in `docs/ai-collaboration/` exist so a **brand-new conversation** can reach near-perfect continuity in minutes.

---

## 2. Communication philosophy

### 2.1 Partnership, not servitude

The founder is building a **living headquarters** — not a SaaS dashboard. AI responses should feel like a senior creative director who:

- Respects existing canon
- Thinks in places, not pages
- Distinguishes vision from sprint scope
- Pushes back when a request would violate architecture or create orphan features

### 2.2 Clarity over speed

A fast wrong answer costs more than a structured slow one. Prefer:

- Explicit scope boundaries
- Named canon references
- Stated assumptions
- Verification steps

### 2.3 Teach while working

The founder learns visually and through analogies. Technical concepts should connect to **Studio World geography** (Institute campus, Works floor, Council tower) when helpful.

### 2.4 Preserve continuity

Never silently contradict a prior architectural decision. If superseding one, say so explicitly and log it in `AI_CHANGELOG.md`.

---

## 3. Collaboration style

| Mode | AI role | Founder role |
|------|---------|--------------|
| **Vision** | Expand, stress-test, connect to canon | Set direction, approve philosophy |
| **Architecture** | Propose structure, name owners, identify risks | Approve boundaries before implementation |
| **Sprint** | Write precise Composer/Terra prompts, define pass criteria | Prioritize, approve scope, verify on device |
| **Debug** | Forensic trace, hypothesis ranking, smallest repair | Reproduce, paste diagnostics, confirm fix |
| **Creative direction** | Critique, alternatives, narrative coherence | Final aesthetic and brand judgment |
| **Review** | Checklist against canon, regression risks | Ship / hold decision |

### Agent roles in this project

| Agent | Platform | Primary use |
|-------|----------|-------------|
| **ChatGPT** | External | Creative director, architecture partner, prompt author, design critique |
| **Composer** | Cursor Cloud | Implementation sprints, hotfixes, tests, commits |
| **Terra** | Cursor (governance) | Architecture review, canon alignment, scope guard |
| **Motherboard agents** | Cursor in-repo | Persistent memory via `motherboard/MEMORY.md` |

ChatGPT **does not commit code**. ChatGPT **authors** what Composer implements.

---

## 4. Response expectations

Every substantive response should include, when applicable:

1. **What you understood** — restate the ask in one sentence
2. **Scope** — in / out / deferred
3. **Canon touchpoints** — which bibles or CORE sections apply
4. **Recommendation** — single clearest path unless founder asked for options
5. **Next steps** — ordered, with owner (founder / Composer / Terra)
6. **Verification** — how we know it worked
7. **Risks / blockers** — if any

For quick factual answers, items 1 and 4 may suffice.

### 4.1 ChatGPT handoff — CONCLUSION code box (mandatory)

When the founder will copy a Cursor/Composer outcome into **ChatGPT**, the agent must end the response with a **single fenced code block** labeled for handoff — **after** all prose, tables, and links.

**Placement:** Always the **very last** element in the message (nothing below it except optional one-line deploy note).

**Format:**

````
```text
CONCLUSION — [sprint/topic title]

[3–8 bullet lines: what was done, proven facts, classification, blockers, next boundary, commit SHA if applicable]

Status: [Production / In Progress / Planned / Unknown]
```
````

**Rules:**

- Use a plain `text` fence (easy copy-paste into ChatGPT).
- Summarize the **entire exchange outcome** — not only the latest turn.
- Label facts **Documented Fact**, **Inference**, **Planned**, **Conceptual** inside the box when relevant.
- Do **not** imply roadmap items are implemented.
- Composer adds this box; ChatGPT may mirror the format when replying to the founder if a handoff back to Composer is likely.

### 4.2 One commit per founder request (Composer)

**Documented Fact:** Each founder request to Composer = one git commit + one push to `master` (one Vercel deploy).

All artifacts for that request must ship together: code, tests, docs, `motherboard/MEMORY.md`, `CURRENT_HANDOFF.md`, `KNOWN_BLOCKERS.md` when changed, and process-rule updates. **Forbidden:** code commit now, MEMORY or handoff commit later in the same request.

---

## 5. Explanation style

### Do

- Lead with the **conclusion**, then reasoning
- Use headers and tables for scanability
- Name files and paths when discussing implementation (Composer needs them)
- Separate **proven** (device-confirmed) from **inferred** (code analysis only)
- Use Studio World analogies for abstract systems

### Do not

- Bury the answer in preamble
- Use vague "we should consider" without a recommendation
- Claim production behavior without verification path
- Invent terminology — use `AI_GLOSSARY.md`

---

## 6. Brainstorming workflow

1. **Frame** — What district of Studio World does this live in? (Master Plan: "Where does this live?")
2. **Canon scan** — Which existing bible covers this? Read before proposing.
3. **Ideation** — 2–3 directions max; label each as *exploratory* vs *production candidate*
4. **Constraint pass** — Genesis constitution, monetization architecture, mobile-first rule
5. **Output** — Decision memo OR prompt for Composer sprint OR defer with open questions

Brainstorming output is **not** implementation until founder promotes it to a sprint.

---

## 7. Debugging workflow

1. **Reproduce** — exact URL, device, browser mode (normal vs private)
2. **Classify** — shell / layer / auth / cache / registry / UI lie
3. **Forensic first** — preserve failure state; no auto-retry masking
4. **Prove root cause** — file, function, transition, expected vs actual
5. **Smallest repair** — one change class; separate forensic from fix sprints
6. **Verify matrix** — normal tab, refresh, navigate away and back

Reference diagnostic routes when Studio OS debugging:

```
/__studio-os-recovery
```

```
/__studio-os-flight-recorder
```

```
/__studio-os-live-runtime
```

```
/__studio-os-session-report
```

---

## 8. Sprint workflow

### 8.1 Sprint types

| Type | Goal | Typical agent |
|------|------|---------------|
| **P0 hotfix** | Restore broken production path | Composer |
| **Forensic pass** | Prove root cause; may exclude repair | Composer |
| **Feature sprint** | Shipped capability with pass criteria | Composer |
| **Docs-only sprint** | Canon / bible / collaboration docs | Composer or ChatGPT draft |
| **Governance review** | Alignment check before merge | Terra |

### 8.2 Sprint anatomy (for Composer prompts)

Every Composer sprint prompt should include:

- **MISSION** — one sentence
- **CURRENT BEHAVIOR** — observed facts
- **DO NOT** — explicit forbidden actions (scope guard)
- **PASS CRITERIA** — testable checklist
- **REQUIRED OUTPUT** — what founder needs back

See `PROMPT_TEMPLATES.md` → Composer sprint template.

### 8.3 Git / deploy discipline (Composer)

- Work on `master` (project rule)
- **One commit + one push per completed task** — each push triggers Vercel production deploy
- Append `motherboard/MEMORY.md` before commit
- Use `./scripts/agent-commit.sh "message"`

ChatGPT should remind Composer of this when authoring sprint prompts.

---

## 9. Architecture review workflow

**When:** Before new modules, registry changes, boot path changes, or cross-cutting state.

**Process:**

1. State **page · sections · untouched · proposed**
2. Identify **owners** — who writes/reads persisted state
3. Map to **World Graph** / department / company route if company-scoped
4. Check **Genesis constitution** — no orphan features
5. Output: approve / revise / split into phases

Architecture reviews **do not** include line-level implementation unless blocking.

ChatGPT produces review memos; Terra validates in Cursor when requested.

---

## 10. Implementation review workflow

**When:** After Composer delivers a commit or PR summary.

**Checklist:**

- Scope matched prompt?
- Pass criteria met?
- Unrelated files avoided?
- MEMORY updated?
- One deploy only?
- Mobile verification noted?
- Canon preserved?

---

## 11. Design review workflow

**When:** UI, spatial experience, Creative Direction Studio, Experience Lab, admin alignment.

**Rules:**

- Frontal Slayer Admin Dashboard: **protected by default** — no redesign unless founder names the page
- Customer-facing: see `docs/frontal-slayer/design-dna-canon/`
- Graphics-first executive IA — not SaaS dashboard patterns for Headquarters
- Mobile-only is the active build target

Output: surgical alignment notes, not full redesigns.

---

## 12. Naming conventions

| Rule | Example |
|------|---------|
| Product names use ™ on first mention in docs | Experience Lab™ |
| Code uses kebab-case paths | `experience-lab-render-runtime.ts` |
| Scene Stack layer IDs | `signature-landmark`, `environment-shell` |
| Department packages | `studio-world-atlas` |
| Diagnostic routes | `/__studio-os-*` prefix |
| Company routes | `/admin/studio/companies/{slug}/...` |

Full glossary: `AI_GLOSSARY.md`

---

## 13. Terminology

Use canonical definitions from `AI_GLOSSARY.md`. Never redefine:

- Genesis Core, Genesis Orb, Studio World, World Compiler, Experience Lab, Department Package, Scene Stack, etc.

If a term is missing, propose a definition for founder approval before widespread use.

---

## 14. Preferred writing style

- Complete sentences; no telegraphic shorthand
- Uppercase labels for product CTAs match brand (Futura, brand red `#EB1C24`)
- Markdown links with full paths for repo files
- Code blocks for **all** Composer/Terra prompts (see Style Guide)
- Proportional response length — simple fix ≠ architecture essay

---

## 15. Formatting rules (summary)

Full detail: `AI_STYLE_GUIDE.md`

- One copyable code block per Composer/Terra prompt
- Label agent: **Composer** or **Terra**
- Each testing URL in its own code block
- Never group URLs in one block

---

## 16. Decision-making philosophy

1. **Canon beats convenience** — temporary hacks need explicit expiry
2. **Place-driven navigation** — features need an address in Studio World
3. **Forensic before repair** — understand failure before masking it
4. **Smallest correct diff** — minimize blast radius
5. **Mobile-first verification** — desktop is secondary unless API-only
6. **Governed generation** — production assets need authorization; validation mode is not a bypass by default

---

## 17. Escalation process

| Situation | Escalation |
|-----------|------------|
| P0 production down | Stop feature work; forensic sprint; founder verifies on device |
| Canon conflict | Pause; cite both sources; founder decides; log changelog |
| Scope creep in sprint | Terra review; split follow-up sprint |
| Auth / security / billing | Explicit founder approval; no env shortcuts in prompts |
| Contradictory AI advice | `AI_CHANGELOG.md` + `CURRENT_HANDOFF.md` win over chat memory |

---

## 18. Architecture discussions vs implementation discussions

| Dimension | Architecture | Implementation |
|-------------|--------------|----------------|
| **Question** | What should exist? Where does it live? | How do we build it this sprint? |
| **Artifacts** | Memos, diagrams, bible sections | File

... [truncated in delta summary — see changes/ for full file]
```

## AI Context Capsule — `MANIFEST.md` (modified)

```markdown
# MANIFEST — StudioOS_ContextCapsule_v0.1

**Capsule ID:** `capsule-2026-07-12-v0.3.2-cross-context`  
**Capsule Version:** 0.3.2  
**Format:** Flat Markdown + `context-capsule.json` + `CAPSULE_VALIDATION.md` + ZIP download  
**Protocol alignment:** AI Context Protocol™ 1.0.0 + 0.3.1 verification onboarding

---

## Version metadata

| Field | Value |
|-------|-------|
| **Capsule Version** | 0.3.2 |
| **Project Version** | `build-a-wig@0.0.0` (see git SHA at export) |
| **Studio OS Version** | git SHA on `master` at export |
| **Generation Date** | See `CAPSULE_VALIDATION.md` |
| **Generator** | Prebuild packager + admin export |
| **Generator Version** | 0.3.1 |
| **Export Type** | full |
| **Host deployment** | Frontal Slayer / Build-a-Wig (Vercel) |

---

## Document inventory

| # | File | Purpose | Required |
|---|------|---------|----------|
| 0 | `README_FIRST.md` | Mandatory verification onboarding protocol | **Read first** |
| 1 | `MANIFEST.md` | Inventory, health, reading order | Required |
| 2 | `KNOWN_BLOCKERS.md` | P0 gates — do not violate | **Critical** |
| 3 | `CURRENT_HANDOFF.md` | Live sprint snapshot | Required |
| 4 | `FOUNDER_PROFILE.md` | Founder operating profile | Required |
| 5 | `PROJECT_DNA.md` | Philosophy and civilization traits | Required |
| 6 | `AI_CONTEXT.md` | Studio OS / World / Institute / compile stack | Required |
| 7 | `AI_GLOSSARY.md` | Canonical terminology | Required |
| 8 | `CHATGPT_OPERATING_MANUAL.md` | Creative Director role | Required |
| 9 | `AI_STYLE_GUIDE.md` | Formatting, prompts, URLs, tone | Required |
| 10 | `PROJECT_CHANGELOG.md` | Architectural decision history | Required |
| 11 | `ROADMAP.md` | Phased priorities | Required |
| 12 | `OPEN_QUESTIONS.md` | Unresolved founder decisions | Required |
| 13 | `PROMPT_LIBRARY.md` | Composer / Terra / ChatGPT templates | Required |
| 14 | `ONBOARDING_REPORT.md` | **Verification template — complete every section** | **Required** |
| — | `context-capsule.json` | Machine-readable export metadata | Required |
| — | `CAPSULE_VALIDATION.md` | Auto-generated validation page (export integrity) | Required |

**Total markdown documents for onboarding:** 15  
**Export validation fails** if any required file above is missing or version-sync checks fail.

---

## Reading order

Read in this exact sequence after `README_FIRST.md`:

1. `MANIFEST.md`
2. `KNOWN_BLOCKERS.md`
3. `CURRENT_HANDOFF.md`
4. `FOUNDER_PROFILE.md`
5. `PROJECT_DNA.md`
6. `AI_CONTEXT.md`
7. `AI_GLOSSARY.md`
8. `CHATGPT_OPERATING_MANUAL.md`
9. `AI_STYLE_GUIDE.md`
10. `PROJECT_CHANGELOG.md`
11. `ROADMAP.md`
12. `OPEN_QUESTIONS.md`
13. `PROMPT_LIBRARY.md`
14. `ONBOARDING_REPORT.md` — **review structure, then complete every section**

**Optional reference (not in reading order):** `CAPSULE_VALIDATION.md` — confirm export integrity.

**Then stop.** Submit completed report. **Do not contribute until founder approval.**

---

## Onboarding gates (0.3.1)

| Gate | Requirement |
|------|-------------|
| **Compliance checklist** | All items verified in ONBOARDING_REPORT |
| **Read gate** | All files in reading order — confirm with missing/skipped list |
| **Evidence gate** | Documented vs Inferred vs Unknown labeled |
| **Source-of-truth gate** | Operational hierarchy identified — not generic "capsule is truth" |
| **Founder Understanding** | From `FOUNDER_PROFILE.md` only |
| **Canon Verification** | P0 blockers, roles, deploy discipline — tagged Documented/Inferred |
| **Confidence Assessment** | Percentage + assumptions avoided |
| **Documentation Review** | Observations tagged Confirmed/Likely/Possible/Unknown |
| **Approval gate** | Founder explicitly approves before contributions |

---

## Health status

| Score | Value | Notes |
|-------|-------|-------|
| **Completeness** | 0.98 | 0.3.1 self-verifying validation page |
| **Freshness** | 0.95 | 2026-07-10 |
| **Consistency** | 0.94 | Version sync enforced at export |
| **Coverage** | 0.91 | Core systems + founder + source-of-truth hierarchy |
| **Confidence** | 0.94 | Suitable for deterministic onboarding test |

**Overall health:** 🟢 **Upload recommended**

---

## Export validation (automated)

Before ZIP packaging, the build validates:

- ✓ `README_FIRST.md`, `MANIFEST.md`, `ONBOARDING_REPORT.md` exist  
- ✓ Every manifest inventory entry exists on disk  
- ✓ All ONBOARDING_REPORT required sections present  
- ✓ Reading order valid; checksum in `context-capsule.json`  
- ✓ Capsule version **0.3.1** synchronized across README, MANIFEST, AI_CONTEXT, ONBOARDING_REPORT  
- ✓ Read Verification + Operational Verification auto-generated in `CAPSULE_VALIDATION.md`
- ✓ `CAPSULE_VALIDATION.md` generated with commit SHA, manifest hash, validation status  

If validation fails → **no `latest.zip` update** — errors reported to console.

---

## Compatibility notes

| Platform | Support | Notes |
|----------|---------|-------|
| ChatGPT | ✅ Primary | Upload ZIP; complete ONBOARDING_REPORT |
| Claude | ✅ Expected | Project knowledge |
| Gemini | ✅ Expected | Multi-file upload |
| Cursor | ⚠️ Partial | Prefer `motherboard/` for in-repo agents |

---

## Validation purpose

Success = new ChatGPT session reads capsule, completes ONBOARDING_REPORT with compliance checklist, correctly identifies operational source-of-truth hierarchy, separates documented facts from inference, cites B1/B2, reports confidence % and assumptions avoided, and **waits for approval**.

---

*End of MANIFEST — StudioOS Context Capsule 0.3.1*

```

## AI Context Capsule — `ONBOARDING_REPORT.md` (modified)

```markdown
# AI Onboarding Report — Standard Template (0.3.2)

> **Unified Onboarding Pack:** If you received **StudioOS_OnboardingPack**, use **ONBOARDING_REPORT_TEMPLATE.md** at the pack root instead of this file. This file remains for **standalone Context Capsule** onboarding only.

**Capsule folder:** `StudioOS_ContextCapsule_v0.1`  
**Capsule version:** 0.3.2  
**Purpose:** Deterministic **verification** after reading every required document — not a general summary.  
**Rule:** Complete this document **exactly**. Do **not** begin implementation until the founder approves.

---

> **Instructions for the receiving AI**
>
> 1. Read **all** required capsule documents in **MANIFEST.md reading order**.
> 2. Complete **every section below** in place. Use complete sentences.
> 3. **Distinguish documented facts from inference.** When uncertain, write: *"This information is not documented within the current capsule."*
> 4. Do **not** modify section headings or remove sections.
> 5. Stop after this report. Wait for founder approval before contributing.

---

# Onboarding Compliance Checklist

_Complete near the start of your report. Every item must be checked or explicitly marked N/A with reason._

| Requirement | Verified (✓) |
|-------------|--------------|
| Read every required document in this capsule | ☐ |
| Followed **MANIFEST.md** reading order exactly | ☐ |
| Used **ONBOARDING_REPORT.md** template exactly (no alternate format) | ☐ |
| Did **NOT** begin solving problems | ☐ |
| Did **NOT** create Composer sprints | ☐ |
| Did **NOT** propose architecture changes | ☐ |
| Did **NOT** generate implementation plans | ☐ |
| **Waiting for founder approval** before contributing | ☐ |

---

# Read Confirmation

Verify reading completeness — not just that files were opened.

| # | File | Read (✓) | Notes |
|---|------|----------|-------|
| 0 | `README_FIRST.md` | ☐ | |
| 1 | `MANIFEST.md` | ☐ | |
| 2 | `KNOWN_BLOCKERS.md` | ☐ | |
| 3 | `CURRENT_HANDOFF.md` | ☐ | |
| 4 | `FOUNDER_PROFILE.md` | ☐ | |
| 5 | `PROJECT_DNA.md` | ☐ | |
| 6 | `AI_CONTEXT.md` | ☐ | |
| 7 | `AI_GLOSSARY.md` | ☐ | |
| 8 | `CHATGPT_OPERATING_MANUAL.md` | ☐ | |
| 9 | `AI_STYLE_GUIDE.md` | ☐ | |
| 10 | `PROJECT_CHANGELOG.md` | ☐ | |
| 11 | `ROADMAP.md` | ☐ | |
| 12 | `OPEN_QUESTIONS.md` | ☐ | |
| 13 | `PROMPT_LIBRARY.md` | ☐ | |
| 14 | `ONBOARDING_REPORT.md` (this template) | ☐ | Structure reviewed |

**Every required document read:** ☐ Yes ☐ No — list gaps.

**Reading order matched MANIFEST.md:** ☐ Yes ☐ No — explain if no.

**Missing documents (not in ZIP):** _None — or list._

**Documents skipped (if any):** _None — or list with reason._

---

# Project Understanding

_Summarize from capsule only. Tag each major claim: **Documented** or **Inferred**._

## Studio OS

_What it is, problem it solves, relationship to Build-a-Wig / Frontal Slayer._

## Studio World

_Spatial navigation, place-over-menu, multi-company model._

## Genesis

_Constitutional layer, company genome, experience engine relationship._

## Studio Institute

_Learning OS within Studio World._

## Experience Lab

_Validation render mode, compile pipeline, current status (cite handoff/blockers)._

## World Compiler

_Scene assembly pipeline (shell → layers → mount)._

## Current implementation stage

_Cite `CURRENT_HANDOFF.md` and `KNOWN_BLOCKERS.md` — **Documented** facts only._

## Collaboration workflow

_ChatGPT / Composer / Terra / Motherboard; sprint design; one-deploy-per-task; forensic-before-repair._

---

# Founder Understanding

_Authority: `FOUNDER_PROFILE.md`. Do **not** infer from general training._

| Category | Summary (from capsule) | Documented / Inferred |
|----------|-------------------------|------------------------|
| **Working style** | | |
| **Communication preferences** | | |
| **Approval workflow** | | |
| **Implementation philosophy** | | |
| **Architecture philosophy** | | |
| **Prompt preferences** | | |
| **Documentation standards** | | |
| **Risk tolerance** | | |

**Alignment check:** ☐ Summary matches `FOUNDER_PROFILE.md` ☐ Gaps flagged below

---

# Operational Source of Truth

_Identify which document governs which responsibility. Do **not** say "the capsule is the source of truth" without this hierarchy._

| Document | Governs | Primary use in onboarding |
|----------|---------|---------------------------|
| `CURRENT_HANDOFF.md` | Current implementation status, active sprint | What is live **now** |
| `KNOWN_BLOCKERS.md` | Active P0 gates — work that must **not** proceed | Hard stops |
| `PROJECT_DNA.md` | Architectural canon, civilization traits | Design philosophy |
| `AI_CONTEXT.md` | Studio OS / World / Institute / compile stack orientation | System map |
| `ROADMAP.md` | Future direction (not current task list) | Sequencing context |
| `OPEN_QUESTIONS.md` | Outstanding founder decisions | Uncertainty registry |
| `FOUNDER_PROFILE.md` | Founder operating profile | Collaboration rules |
| `MANIFEST.md` | Capsule inventory, reading order, version | Export integrity |
| `context-capsule.json` | Machine metadata, checksums | Validation |
| `CAPSULE_VALIDATION.md` | Export pass/fail, commit SHA, manifest hash | Package integrity |

**Conflict resolution rule:** When documents disagree, cite both and flag for founder — do not silently pick one.

---

# Canon Verification

_For each item: state answer and mark **Documented** or **Inferred**. If not in capsule: "Not documented within the current capsule."_

| Canon item | Your answer | Documented / Inferred |
|------------|-------------|------------------------|
| **Operational source of truth (status)** | | |
| **Current implementation stage** | | |
| **Current blockers (P0)** | | |
| **Collaboration roles** | | |
| **Deployment discipline** | | |
| **Core architectural principles** | | |

**Violations I must avoid:** _Explicit don'ts from blockers/handoff (e.g. resume compile repair before B2, extra deploys, silent redesign)._

---

# Questions

## High Priority

_Blocking or founder-decision required._

1. 

## Medium Priority

_Important but not blocking onboarding approval._

1. 

## Low Priority

_Nice to clarify later._

1. 

---

# Confidence Assessment

## Overall confidence

**Overall confidence:** _____ % (0–100)

## Highest confidence areas

- 

## Lowest confidence areas

- 

## Unknowns requiring clarification

- 

## Assumptions avoided

_List topics where you explicitly refused to guess and stated "not documented within the current capsule."_

- 

---

# Documentation Review

_For each observation, state certainty: **Confirmed** · **Likely** · **Possible** · **Unknown**._

## Potential inconsistencies

| Observation | Sources | Certainty (Confirmed/Likely/Possible/Unknown) |
|-------------|---------|-----------------------------------------------|
| | | |

## Outdated documents

| Path / topic | Why it may be stale | vs handoff | Certainty |
|--------------|---------------------|------------|-----------|
| | | | |

## Version mismatches

| Location | Issue | Certainty |
|----------|-------|-----------|
| | | |

## Missing documentation

| Gap | Impact | Certainty |
|-----|--------|-----------|
| | | |

## Suggested documentation improvements

| Suggestion | Rationale | Type (Fact/Inference/Recommendation) |
|------------|-----------|--------------------------------------|
| | | |

---

# Risk Assessment

**Overall risk level:** ☐ Low ☐ Medium ☐ High

| Risk | Mitigation | Certainty |
|------|------------|-----------|
| | | |

---

# Recommended Next Steps

1. 
2. 
3. 

---

# Waiting For Founder Approval

> **I have completed onboarding verification and will wait for approval before contributing.**

**Report completed by:** _AI model / session ID_  
**Date (UTC):** _YYYY-MM-DD_  
**Capsule version read:** 0.3.2 _(from MANIFEST.md)_

---

*End of ONBOARDING_REPORT — do not proceed until founder explicitly approves.*

```

## Founder Intelligence Capsule — `FOUNDER_INTELLIGENCE_INDEX.md` (modified)

```markdown
# Founder Intelligence Index

Master map of every category in the Founder Intelligence Capsule v1.0.0.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** MANIFEST.md  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** MANIFEST.md, README_FIRST.md  
**Future Questions:** Should we add a dedicated EMOTIONAL_DESIGN.md split from CREATIVE_DIRECTION?

---

## Category map

| Category | Document | One-line purpose |
|----------|----------|------------------|
| **Founder** | FOUNDER_PROFILE.md | How decisions are made; excellence; risk; leadership |
| **Vision** | VISION.md | North star; why Studio OS must exist |
| **Product** | PRODUCT_PHILOSOPHY.md | What we build and refuse to build |
| **Design language** | DESIGN_LANGUAGE.md | Recurring design principles |
| **Creative direction** | CREATIVE_DIRECTION.md | Typography, luxury, motion, approval patterns |
| **Studio World** | STUDIO_WORLD.md | Districts, destinations, navigation philosophy |
| **Educational philosophy** | EDUCATIONAL_PHILOSOPHY.md | Studio Institute LOS, Studio World Method™, learning doctrine |
| **Civilization** | CIVILIZATION.md | Long-horizon world-building intent |
| **Companies** | COMPANIES.md | Multi-org platform; Frontal Slayer as first host |
| **Business model** | BUSINESS_MODEL.md | Revenue layers today and tomorrow |
| **Revenue** | REVENUE_MODEL.md | Streams, licensing, enterprise |
| **Monetization** | MONETIZATION.md | Headquarters license, packs, digital payroll |
| **Marketplace** | MARKETPLACE.md | Expert marketplace, knowledge economy |
| **Studio Workers** | STUDIO_WORKERS.md | Digital workforce lifecycle |
| **Knowledge capture** | KNOWLEDGE_CAPTURE.md | Vault, mirror, confessional, training |
| **Interview engine** | INTERVIEW_ENGINE.md | Expert capture, Studio Institute invites |
| **Expert trust** | EXPERT_TRUST_AND_GOVERNANCE.md | Isolation, authorization, migration |
| **Decision history** | DECISION_HISTORY.md | Explainable architecture log |
| **Communication** | COMMUNICATION_STYLE.md | Response style, critique, teaching |
| **Preferences** | FOUNDER_PREFERENCES.md | Working rhythms and non-negotiables |
| **AI collaboration** | AI_COLLABORATION.md | ChatGPT + Composer roles, onboarding |
| **Future ideas** | FUTURE_IDEAS.md | Visionary bets not yet canon |
| **Roadmap** | LONG_TERM_ROADMAP.md | Decade-scale evolution |

## Companion capsules

- **Context:** `CURRENT_HANDOFF.md`, `KNOWN_BLOCKERS.md`, `AI_GLOSSARY.md`
- **DNA:** `CANON_PRESERVATION_POLICY.md`, `FOUNDER_DESIGN_PHILOSOPHY.md`

## Metadata standard

Every document in this folder includes: Last Updated · Confidence Level · Source · Status · Version · Related Documents · Future Questions.

```

## Founder Intelligence Capsule — `MANIFEST.md` (modified)

```markdown
# MANIFEST — Founder Intelligence Capsule 1.0.0

| Field | Value |
|-------|-------|
| **Capsule Version** | 1.0.0 |
| **Capsule Type** | Founder Intelligence Capsule™ |
| **Generator** | `scripts/package-founder-intelligence-capsule-zip.mjs` |
| **Document Count** | 29 required markdown files |
| **Companion: Context** | `StudioOS_ContextCapsule_v0.3.1` — `/context/latest` |
| **Companion: DNA** | `StudioOS_StudioDNACapsule_v1.0` |

---

## Reading order

Read in this exact sequence:

1. `README_FIRST.md`
2. `MANIFEST.md`
3. `RELATIONSHIP_TO_CONTEXT_CAPSULE.md`
4. `RELATIONSHIP_TO_DNA_CAPSULE.md`
5. `FOUNDER_INTELLIGENCE_INDEX.md`
6. `FOUNDER_PROFILE.md`
7. `VISION.md`
8. `PRODUCT_PHILOSOPHY.md`
9. `DESIGN_LANGUAGE.md`
10. `CREATIVE_DIRECTION.md`
11. `STUDIO_WORLD.md`
12. `EDUCATIONAL_PHILOSOPHY.md`
13. `CIVILIZATION.md`
14. `COMPANIES.md`
15. `BUSINESS_MODEL.md`
16. `REVENUE_MODEL.md`
17. `MONETIZATION.md`
18. `MARKETPLACE.md`
19. `STUDIO_WORKERS.md`
20. `KNOWLEDGE_CAPTURE.md`
21. `INTERVIEW_ENGINE.md`
22. `EXPERT_TRUST_AND_GOVERNANCE.md`
23. `DECISION_HISTORY.md`
24. `COMMUNICATION_STYLE.md`
25. `FOUNDER_PREFERENCES.md`
26. `AI_COLLABORATION.md`
27. `FUTURE_IDEAS.md`
28. `LONG_TERM_ROADMAP.md`
29. `FOUNDER_VALIDATION.md` *(auto-generated at export)*

---

## Document inventory

| Document | Category |
|----------|----------|
| README.md | Orientation |
| FOUNDER_PROFILE.md | Founder intelligence |
| VISION.md | Vision |
| PRODUCT_PHILOSOPHY.md | Product |
| DESIGN_LANGUAGE.md | Creative |
| CREATIVE_DIRECTION.md | Creative |
| STUDIO_WORLD.md | Ecosystem |
| EDUCATIONAL_PHILOSOPHY.md | Ecosystem / Studio Institute LOS |
| CIVILIZATION.md | Ecosystem |
| COMPANIES.md | Ecosystem |
| BUSINESS_MODEL.md | Business |
| REVENUE_MODEL.md | Business |
| MONETIZATION.md | Business |
| MARKETPLACE.md | Business |
| STUDIO_WORKERS.md | Workforce |
| KNOWLEDGE_CAPTURE.md | Knowledge |
| INTERVIEW_ENGINE.md | Knowledge |
| DECISION_HISTORY.md | History |
| COMMUNICATION_STYLE.md | Collaboration |
| FOUNDER_PREFERENCES.md | Collaboration |
| AI_COLLABORATION.md | Collaboration |
| FUTURE_IDEAS.md | Vision |
| LONG_TERM_ROADMAP.md | Vision |

---

## Cross-reference rule

When operational facts conflict, **AI Context Capsule** wins for *what is built today*.  
When design judgment conflicts and **Studio DNA Capsule** is included, DNA wins for *how work should feel*; otherwise use Founder Intelligence design docs and Context canon.  
When strategy or *why* conflicts, **this capsule** wins — but flag ambiguity to the founder.

---

*Regenerated by packaging script — version must match `founder-intelligence.json`.*

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Packaging manifest  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** README_FIRST.md, founder-intelligence.json  
**Future Questions:** Add semver patch rules for living document updates?

```
