# UPDATED CANON

Tracks maturity promotions, deprecations, and supersessions detected in this delta.

## Promoted to Canon / Approved

- AI Context Capsule / PROJECT_CHANGELOG.md (modified)

## Still Working

- None

## Still Experimental

- None

## Deprecated / Superseded

- AI Context Capsule / KNOWN_BLOCKERS.md

## Changed files with canon relevance

- modified: `KNOWN_BLOCKERS.md`
- modified: `PROJECT_CHANGELOG.md`
