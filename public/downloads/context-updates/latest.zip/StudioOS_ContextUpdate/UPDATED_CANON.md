# UPDATED CANON

Tracks maturity promotions, deprecations, and supersessions detected in this delta.

## Promoted to Canon / Approved

- AI Context Capsule / AI_CONTEXT.md (modified)
- AI Context Capsule / CHATGPT_OPERATING_MANUAL.md (modified)
- AI Context Capsule / MANIFEST.md (modified)
- AI Context Capsule / README_FIRST.md (modified)
- Founder Intelligence Capsule / EDUCATIONAL_PHILOSOPHY.md (added)
- Founder Intelligence Capsule / FOUNDER_INTELLIGENCE_INDEX.md (modified)
- Founder Intelligence Capsule / MANIFEST.md (modified)
- Founder Intelligence Capsule / STUDIO_WORLD.md (modified)

## Still Working

- AI Context Capsule / ONBOARDING_REPORT.md

## Still Experimental

- None

## Deprecated / Superseded

- None

## Changed files with canon relevance

- modified: `AI_CONTEXT.md`
- modified: `CHATGPT_OPERATING_MANUAL.md`
- modified: `MANIFEST.md`
- modified: `README_FIRST.md`
- added: `EDUCATIONAL_PHILOSOPHY.md`
- modified: `FOUNDER_INTELLIGENCE_INDEX.md`
- modified: `MANIFEST.md`
- modified: `STUDIO_WORLD.md`
