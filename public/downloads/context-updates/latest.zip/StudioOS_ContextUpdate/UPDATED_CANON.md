# UPDATED CANON

Tracks maturity promotions, deprecations, and supersessions detected in this delta.

## Promoted to Canon / Approved

- Collaboration Intelligence Capsule / AI_LESSONS.md (added)
- Collaboration Intelligence Capsule / COLLABORATION_GLOSSARY.md (added)
- Collaboration Intelligence Capsule / COLLABORATION_INTELLIGENCE_INDEX.md (added)
- Collaboration Intelligence Capsule / COLLABORATION_PATTERNS.md (added)
- Collaboration Intelligence Capsule / DECISION_HISTORY.md (added)
- Collaboration Intelligence Capsule / EVOLUTION_TIMELINE.md (added)
- Collaboration Intelligence Capsule / FOUNDER_PREFERENCES.md (added)
- Collaboration Intelligence Capsule / GOOSEBUMP_MOMENTS.md (added)
- Collaboration Intelligence Capsule / HISTORICAL_CONTEXT.md (added)
- Collaboration Intelligence Capsule / IMPORTANT_CONVERSATIONS.md (added)
- Collaboration Intelligence Capsule / README_FIRST.md (added)
- Collaboration Intelligence Capsule / README.md (added)
- Collaboration Intelligence Capsule / RELATIONSHIP_MEMORY.md (added)
- Collaboration Intelligence Capsule / RELATIONSHIP_TO_CONTEXT_CAPSULE.md (added)
- Collaboration Intelligence Capsule / RELATIONSHIP_TO_DNA_CAPSULE.md (added)
- Collaboration Intelligence Capsule / RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md (added)
- Collaboration Intelligence Capsule / SEARCH_INDEX.md (added)

## Still Working

- None

## Still Experimental

- None

## Deprecated / Superseded

- Collaboration Intelligence Capsule / MANIFEST.md
- Collaboration Intelligence Capsule / MEMORY_MATURITY.md

## Changed files with canon relevance

- added: `AI_LESSONS.md`
- added: `COLLABORATION_GLOSSARY.md`
- added: `COLLABORATION_INTELLIGENCE_INDEX.md`
- added: `COLLABORATION_PATTERNS.md`
- added: `DECISION_HISTORY.md`
- added: `EVOLUTION_TIMELINE.md`
- added: `FOUNDER_PREFERENCES.md`
- added: `GOOSEBUMP_MOMENTS.md`
- added: `HISTORICAL_CONTEXT.md`
- added: `IMPORTANT_CONVERSATIONS.md`
- added: `MANIFEST.md`
- added: `MEMORY_MATURITY.md`
- added: `README_FIRST.md`
- added: `README.md`
- added: `RELATIONSHIP_MEMORY.md`
- added: `RELATIONSHIP_TO_CONTEXT_CAPSULE.md`
- added: `RELATIONSHIP_TO_DNA_CAPSULE.md`
- added: `RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md`
- added: `SEARCH_INDEX.md`
