# UPDATED FOUNDER PREFERENCES

Founder preference changes discovered through collaboration.

## Collaboration Intelligence Capsule — `AI_LESSONS.md` (added)

```markdown
# AI Lessons

Mistakes that must **never repeat**. Maturity: **Canonical**.

---

## Planning vs implementation

| Lesson | Detail |
|--------|--------|
| **Do not assume planned = implemented** | Roadmap, Genesis, and MEMORY describe intent; verify in code before claiming shipped |
| **Do not confuse capsule with codebase** | Onboarding docs may ahead of or behind production |

---

## Prompt and sprint discipline

| Lesson | Detail |
|--------|--------|
| **Do not split Composer sprints** | One user request → one complete implementation pass |
| **Do not forget code blocks** | Founder Composer specs belong in fenced blocks |
| **Do not summarize founder prompts** | Read full sprint text; every section may be binding |

---

## Architecture and canon

| Lesson | Detail |
|--------|--------|
| **Do not replace architecture** | Repair blockers surgically; no redesign during forensic sprints |
| **Do not remove approved terminology** | Goosebump terms, Studio OS naming, trademark forms are intentional |
| **Do not create dashboards casually** | Spatial review question 8: "Does this create another dashboard?" |
| **Do not bypass governance** | No `CREATIVE_PRODUCTION_ALLOW_LEGACY_COMPAT` as default production fix |

---

## Memory and context

| Lesson | Detail |
|--------|--------|
| **Do not lose long-term context** | Read motherboard at chat start; append MEMORY after tasks |
| **Do not treat motherboard as missing** | It is `motherboard/` folder, not `MOTHERBOARD.md` at root |
| **Do not double-deploy** | One push per task; no amend+force-push repair loops |

---

## Authorization and security

| Lesson | Detail |
|--------|--------|
| **Do not hardcode production auth IDs** | Server-issued ephemeral auth for validation only |
| **Do not put FAL keys in browser** | Governed generation stays server-side |
| **Do not block pipeline on broken new endpoints** | Prefer lazy issuance on proven paths when standalone API fails |

---

## Collaboration UX

| Lesson | Detail |
|--------|--------|
| **Do not trust local-only password hash** | Invite Manager must verify server when local cache stale |
| **Do not declare B1 fixed without Layer 1 evidence** | AUTH_REQUIRED vs FAL vs browser require distinct proof |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, DECISION_HISTORY.md  
**Future Questions:** AI_LESSONS linked to incident IDs in MEMORY?

```

## Collaboration Intelligence Capsule — `COLLABORATION_GLOSSARY.md` (added)

```markdown
# Collaboration Glossary

Founder ↔ AI shorthand. **Not** a technical API glossary — see AI Context `AI_GLOSSARY.md` for implementation terms.

Each entry: **Meaning · Origin · Purpose · Maturity**

---

## Black Box

| Field | Value |
|-------|-------|
| **Meaning** | World Compiler Investigation Recorder — forensic lifecycle logging for Experience Lab compiles |
| **Origin** | Experience Lab compiler diagnostics (`?compilerDiag=1`, Layer 1 freeze, stall evidence) |
| **Purpose** | Records compiler lifecycle, browser differences, pipeline failures, async boundaries |
| **Maturity** | Approved |

---

## The Mansion

| Field | Value |
|-------|-------|
| **Meaning** | Immersive Studio World interface — spatial HQ, departments, stations |
| **Origin** | Studio World / spatial computing philosophy |
| **Purpose** | Distinguishes founder-facing world navigation from flat admin dashboards |
| **Maturity** | Canonical |

---

## Motherboard

| Field | Value |
|-------|-------|
| **Meaning** | Repository institutional memory folder (`motherboard/`) — CORE, CODEBASE, MEMORY |
| **Origin** | Build-a-Wig agent continuity system |
| **Purpose** | Cross-chat memory; auto-append after tasks; not a single file at repo root |
| **Maturity** | Canonical |

---

## Goosebump Moment

| Field | Value |
|-------|-------|
| **Meaning** | Strategic breakthrough where Founder believes Studio OS evolved beyond conventional software |
| **Origin** | Founder language during civilization / marketplace / knowledge capture arcs |
| **Purpose** | Marks concepts worth canonizing — see `GOOSEBUMP_MOMENTS.md` |
| **Maturity** | Approved |

---

## Composer Sprint

| Field | Value |
|-------|-------|
| **Meaning** | One comprehensive, production-ready implementation specification — never fragmented |
| **Origin** | Founder prompt protocol for Cursor Composer agents |
| **Purpose** | Full context in one code block; complete deliverable per sprint |
| **Maturity** | Canonical |

---

## Terra

| Field | Value |
|-------|-------|
| **Meaning** | Governance reviewer (GPT-5.6 Terra) — constitutional architecture, not implementation |
| **Origin** | Constitution First Principle™; Spatial Architecture Review |
| **Purpose** | Reviews ownership, gates dashboards, approves world placement before code |
| **Maturity** | Canonical |

---

## B1 / B2 (Experience Lab)

| Field | Value |
|-------|-------|
| **Meaning** | B1 = compiler authorization blocker (governed FAL); B2 = normal-tab load verification |
| **Origin** | Experience Lab repair sprints 2026-07 |
| **Purpose** | Sequenced repair gates — do not declare complete until both verified |
| **Maturity** | Working |

---

## Ephemeral productionAuthorizationId

| Field | Value |
|-------|-------|
| **Meaning** | Server-issued, compile-scoped auth for Experience Lab validation — not production canon |
| **Origin** | B1 repair; founder-approved policy |
| **Purpose** | Allows governed FAL without permanent elevation or Asset Registry promotion |
| **Maturity** | Approved |

---

## One deploy per task

| Field | Value |
|-------|-------|
| **Meaning** | Each completed agent task = one commit + one push to `master` (incl. MEMORY.md) |
| **Origin** | Vercel production deploy cost / stability |
| **Purpose** | Prevents double deploys, amend+force-push loops, Motherboard follow-up commits |
| **Maturity** | Canonical |

---

## Place over menu

| Field | Value |
|-------|-------|
| **Meaning** | Spatial placement principle — features belong in world departments, not floating menus |
| **Origin** | Studio OS spatial architecture canon |
| **Purpose** | Reject orphan pages, generic dashboards, settings dumping grounds |
| **Maturity** | Canonical |

---

## Studio Workers

| Field | Value |
|-------|-------|
| **Meaning** | AI profession brains employed via Digital Payroll — not generic chatbots |
| **Origin** | Marketplace + civilization economy arc |
| **Purpose** | Expert knowledge → trainable workers → marketplace assets |
| **Maturity** | Approved |

---

## Living Knowledge Mirror

| Field | Value |
|-------|-------|
| **Meaning** | Expert knowledge reflected back for validation before vault promotion |
| **Origin** | Knowledge Capture / Expert Capture system |
| **Purpose** | Human-in-the-loop before canon |
| **Maturity** | Approved |

---

## Spatial Architecture Review

| Field | Value |
|-------|-------|
| **Meaning** | Mandatory 10-question gate before Studio OS product implementation |
| **Origin** | `STUDIO_OS_BIBLE/SPATIAL_ARCHITECTURE_REVIEW.md` |
| **Purpose** | Prevents dashboards, orphan surfaces, non-spatial workflows |
| **Maturity** | Canonical |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** SEARCH_INDEX.md, GOOSEBUMP_MOMENTS.md  
**Future Questions:** Glossary versioning when terms alias (e.g. Creative Direction Studio naming)?

```

## Collaboration Intelligence Capsule — `COLLABORATION_INTELLIGENCE_INDEX.md` (added)

```markdown
# Collaboration Intelligence Index

Category map for the Collaboration Intelligence Capsule™ v1.0.0.

| # | Document | Answers | Maturity |
|---|----------|---------|----------|
| 1 | COLLABORATION_GLOSSARY.md | What does the Founder mean by X? | Working–Canonical |
| 2 | DECISION_HISTORY.md | What was decided, rejected, approved? | Approved–Canonical |
| 3 | EVOLUTION_TIMELINE.md | How did ideas evolve? | Historical–Working |
| 4 | FOUNDER_PREFERENCES.md | How does the Founder want to work? | Approved |
| 5 | AI_LESSONS.md | What mistakes must never repeat? | Canonical |
| 6 | GOOSEBUMP_MOMENTS.md | What breakthroughs mattered? | Canonical |
| 7 | HISTORICAL_CONTEXT.md | Why were solutions chosen? | Historical–Approved |
| 8 | RELATIONSHIP_MEMORY.md | Shared language and expectations | Working |
| 9 | IMPORTANT_CONVERSATIONS.md | Structured summaries (not transcripts) | Historical–Approved |
| 10 | COLLABORATION_PATTERNS.md | How sprints and reviews flow | Approved |
| 11 | MEMORY_MATURITY.md | Entry lifecycle taxonomy | Canonical |
| 12 | SEARCH_INDEX.md | Semantic lookup | Working |

## Quick lookup

- **Compiler / Experience Lab:** Black Box, World Compiler, Experience Lab, B1/B2, ephemeral auth
- **Economy / civilization:** Marketplace, Studio Workers, Knowledge Capture, Goosebump
- **Memory systems:** Motherboard, Collaboration Intelligence, capsules
- **Process:** Composer Sprint, Terra, one deploy per task

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** MANIFEST.md, SEARCH_INDEX.md  
**Future Questions:** Auto-generate index from collaboration-intelligence.json searchTerms?

```

## Collaboration Intelligence Capsule — `COLLABORATION_PATTERNS.md` (added)

```markdown
# Collaboration Patterns

How Founder and AI typically move from exploration to shipped canon.

---

## Standard arc

```
Founder explores widely (vision, critique, "what if")
    ↓
AI narrows (options, risks, codebase truth)
    ↓
Visualize first (diagrams, placement, spatial review if Studio OS product)
    ↓
Prototype mentally (read code paths, trace requests)
    ↓
Architecture (Terra / Spatial Review when required)
    ↓
Composer Sprint (single comprehensive spec)
    ↓
Implementation (surgical diff, conventions matched)
    ↓
Verification (build, test, forensic evidence for compilers)
    ↓
Documentation (deliverables list, no scope creep)
    ↓
Capsule / Motherboard update (MEMORY append, one deploy)
    ↓
Founder verification (browser, production)
```

---

## Sprint types

| Type | Pattern |
|------|---------|
| **Composer Sprint** | One approved spec → one implementation → one deploy |
| **Forensic / repair** | Trace request chain; root cause; minimal fix; evidence checklist |
| **Onboarding** | Read all manifest files → one report → stop for approval |
| **Capsule** | Author docs → validate → package ZIP → update onboarding pack |

---

## Founder exploration mode

- Wide strategic questions are **not** implementation requests.
- AI should answer with canon + codebase truth, not jump to code.
- When Founder shifts to "APPROVED" / "IMPLEMENT" — switch to sprint mode.

---

## AI narrowing mode

- Offer 2–3 bounded options with tradeoffs.
- Cite files and lines.
- Flag when request would violate canon (dashboard, bypass auth, redesign protected admin).

---

## Verification norms

| Domain | Evidence expected |
|--------|-------------------|
| Compiler | Layer forensic, auth reaches FAL, no AUTH_REQUIRED |
| Deploy | One push; build pass |
| Auth | Server hash + client path documented |
| UI repair | Named page/section only (Frontal Slayer admin) |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, AI_LESSONS.md  
**Future Questions:** Pattern tags in collaboration-intelligence.json?

```

## Collaboration Intelligence Capsule — `FOUNDER_PREFERENCES.md` (added)

```markdown
# Founder Preferences (Collaboration)

Preferences discovered through long-term Founder ↔ AI work. Complements Founder Intelligence `FOUNDER_PREFERENCES.md` with **operational sprint habits**.

| Preference | Detail | Maturity |
|------------|--------|----------|
| **Composer prompts in code blocks** | Full sprint specs delivered inside fenced code blocks — copy-paste ready | Canonical |
| **One comprehensive sprint** | Never fragment a production task across multiple thin prompts | Canonical |
| **Do not summarize prompts** | Founder writes complete specs; AI must not shorten or "helpfully" condense | Approved |
| **Architecture before code** | Spatial Architecture Review / governance before implementation (Studio OS product work) | Canonical |
| **Visualize before implementing** | Mental model, diagrams, placement review before edits | Approved |
| **Generate master prompts** | AI may help structure sprints; output must remain founder-grade complete | Working |
| **Prefer reusable systems** | Extend canon systems; no one-off bypasses | Approved |
| **Explain reasoning** | High-quality prose in responses; not telegraphic shorthand | Approved |
| **Professional email formatting** | Transactional and marketing emails use institutional layout standards | Approved |
| **Surgical admin changes** | Frontal Slayer admin: named page + named sections only | Canonical |
| **No unsolicited redesign** | Protected pages stay untouched unless explicitly named | Canonical |
| **Evidence before "fixed"** | Compiler/repair sprints require forensic evidence, not assumptions | Approved |
| **Incognito vs normal tab** | Stale localStorage/sessionStorage causes normal-tab failures — boot hygiene + recovery route | Working |
| **Stop after onboarding report** | New AI reads capsules, reports, waits for approval — no implementation | Canonical |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** COLLABORATION_PATTERNS.md, AI_LESSONS.md  
**Future Questions:** Preference violations lint in agent rules?

```

## Collaboration Intelligence Capsule — `README.md` (added)

```markdown
# Collaboration Intelligence Capsule™

Institutional memory of **Founder ↔ AI collaboration** for Studio OS.

## Scope

This capsule captures nuance that develops over months of paired work:

- Shared shorthand (`Black Box`, `The Mansion`, `Motherboard`, `Composer Sprint`)
- Decisions, rejections, and approved policies
- Evolution of major concepts (Marketplace, Studio World, World Compiler)
- Collaboration patterns (visualize → architecture → sprint → verify)
- Goosebump moments — strategic breakthroughs the Founder marks as civilization-scale

## Distribution

| Channel | URL |
|---------|-----|
| Standalone latest | `/collaboration-intelligence/latest` |
| Unified onboarding | `/onboarding/latest` (phase 4 when DNA included, after Founder Intelligence) |

## Authority hierarchy

1. **CURRENT_HANDOFF.md** (AI Context) — operational truth
2. **Founder Intelligence** — strategic WHY
3. **Studio DNA** — taste and HOW
4. **This capsule** — collaboration context and shorthand
5. **Repository code** — what is actually implemented

When this capsule conflicts with code, **code wins** unless the Founder explicitly reopens the decision.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** README_FIRST.md, MANIFEST.md  
**Future Questions:** Quarterly glossary review cadence?

```

## Collaboration Intelligence Capsule — `RELATIONSHIP_MEMORY.md` (added)

```markdown
# Relationship Memory

Shared terminology, humor, working language, and expectations between Founder and AI.

---

## Shared terminology

- **"The Mansion"** — Studio World spatial UI; not a literal building metaphor only — implies permanence and hospitality.
- **"Black Box"** — Investigation recorder; implies forensic seriousness, not secrecy from Founder.
- **"Motherboard"** — Living repo memory; agents must not claim it doesn't exist.
- **"Goosebump"** — Breakthrough quality bar — pause and recognize strategic weight.
- **"Composer Sprint"** — Production-grade single prompt; respect the fence.

---

## Working language

- Founder writes **complete specifications** — titles, sections, DO NOT lists, verify checklists.
- AI responds with **structured deliverables** — root cause, files changed, evidence, blockers.
- **"Repair only"** / **"No architecture changes"** — literal constraints, not suggestions.
- **"Verified complete"** vs **"shipped"** — Founder distinguishes browser verification from code merge.

---

## Communication style

- High-quality prose; complete sentences; minimal decorative bolding.
- Code citations use `startLine:endLine:filepath` for navigation.
- Markdown links for URLs and paths.
- Do not engagement-bait at end of responses.

---

## Founder expectations of AI

- Read motherboard before implementing.
- Run builds/tests when changing code.
- One commit + one push per task.
- State Spatial Architecture Review skip reason when applicable.
- Investigate before claiming billing/browser/root cause.

---

## AI expectations of Founder

- Explicit page/section names for admin alignment.
- Approval gates after onboarding reports.
- Composer sprints delivered as single code blocks.
- Clear priority: CRITICAL / APPROVED / DO NOT sections are binding.

---

## Recurring humor / tone

- Playful institution names (Studio Institute, Expert Capture) — still governed systems.
- "Civilization" language is sincere strategic framing, not parody.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, COLLABORATION_PATTERNS.md  
**Future Questions:** Relationship memory sensitivity classification?

```

## Collaboration Intelligence Capsule — `RELATIONSHIP_TO_CONTEXT_CAPSULE.md` (added)

```markdown
# Relationship to AI Context Capsule

The **AI Context Capsule™** answers *what is true operationally right now*.

The **Collaboration Intelligence Capsule™** answers *why shorthand, decisions, and references exist*.

## Division of labor

| Topic | AI Context owns | Collaboration Intelligence owns |
|-------|-----------------|--------------------------------|
| Current blockers | `KNOWN_BLOCKERS.md` | Historical investigation context (e.g. B1 AUTH_REQUIRED saga) |
| Handoff | `CURRENT_HANDOFF.md` | How handoff culture developed (Composer Sprint, one deploy) |
| Glossary | `AI_GLOSSARY.md` (technical) | `COLLABORATION_GLOSSARY.md` (Founder shorthand) |
| Prompts | `PROMPT_LIBRARY.md` | Founder preference for code-block sprints |

## Read order inside unified pack

1. AI Context (phase 1) — facts first  
2. Founder Intelligence (phase 2) — strategy  
3. Studio DNA (phase 3, if included) — taste  
4. **Collaboration Intelligence (phase 4)** — shared history  
5. Return to `CURRENT_HANDOFF.md` before acting

## Conflict resolution

If Collaboration Intelligence describes intent not yet in code, defer to **CURRENT_HANDOFF.md** and **KNOWN_BLOCKERS.md**.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md, README_FIRST.md  
**Future Questions:** Cross-link AI_GLOSSARY entries to CIC glossary IDs?

```

## Collaboration Intelligence Capsule — `SEARCH_INDEX.md` (added)

```markdown
# Search Index

Semantic lookup for Collaboration Intelligence. Use keyword → document → section.

---

## Compiler & Experience Lab

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Black Box | COLLABORATION_GLOSSARY.md | World Compiler Investigation Recorder |
| World Compiler | GOOSEBUMP_MOMENTS.md, HISTORICAL_CONTEXT.md | Runtime decoupling |
| Experience Lab | HISTORICAL_CONTEXT.md, IMPORTANT_CONVERSATIONS.md | B1/B2 repairs |
| AUTH_REQUIRED | DECISION_HISTORY.md, HISTORICAL_CONTEXT.md | Ephemeral auth |
| B1 / B2 | COLLABORATION_GLOSSARY.md | Authorization vs browser |
| Layer 1 / Signature Landmark | HISTORICAL_CONTEXT.md | No canvas fallback |
| ephemeral auth | DECISION_HISTORY.md | Server-issued compile scope |
| compilerDiag | HISTORICAL_CONTEXT.md | Forensic mode |

---

## Economy & civilization

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Marketplace | EVOLUTION_TIMELINE.md, GOOSEBUMP_MOMENTS.md | Civilization economy |
| Studio Workers | GOOSEBUMP_MOMENTS.md, DECISION_HISTORY.md | Digital Payroll |
| Knowledge Capture | GOOSEBUMP_MOMENTS.md | Expert institutional learning |
| Goosebump | GOOSEBUMP_MOMENTS.md, COLLABORATION_GLOSSARY.md | Breakthrough moments |
| Interview Engine | GOOSEBUMP_MOMENTS.md | Private expert interviews |
| Knowledge Vault | GOOSEBUMP_MOMENTS.md | Long-term storage |
| Living Knowledge Mirror | COLLABORATION_GLOSSARY.md | Pre-vault reflection |

---

## Memory & onboarding

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Motherboard | COLLABORATION_GLOSSARY.md | motherboard/ folder |
| Collaboration Intelligence | README_FIRST.md | This capsule |
| Onboarding pack | EVOLUTION_TIMELINE.md | Fourth capsule |
| AI Context | RELATIONSHIP_TO_CONTEXT_CAPSULE.md | WHAT |
| Founder Intelligence | RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md | WHY |
| Studio DNA | RELATIONSHIP_TO_DNA_CAPSULE.md | HOW taste |
| CURRENT_HANDOFF | RELATIONSHIP_TO_CONTEXT_CAPSULE.md | Operational truth |

---

## Process & governance

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Composer Sprint | COLLABORATION_GLOSSARY.md, FOUNDER_PREFERENCES.md | One spec block |
| Terra | COLLABORATION_GLOSSARY.md | Governance reviewer |
| one deploy | DECISION_HISTORY.md | Single push rule |
| Spatial Architecture Review | COLLABORATION_GLOSSARY.md | Pre-implementation gate |
| Place over menu | DECISION_HISTORY.md | Spatial IA |
| Admin Alignment | DECISION_HISTORY.md | Protected admin pages |

---

## Institute & experts

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Studio Institute | GOOSEBUMP_MOMENTS.md | Expert capture institution |
| Invite Manager | IMPORTANT_CONVERSATIONS.md | Owner password |
| owner password | HISTORICAL_CONTEXT.md | Stale local hash bug |
| Expert Trust | GOOSEBUMP_MOMENTS.md | Governance framework |

---

## Machine-readable terms

See `collaboration-intelligence.json` → `searchTerms[]` for programmatic lookup.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** COLLABORATION_INTELLIGENCE_INDEX.md, COLLABORATION_GLOSSARY.md  
**Future Questions:** Embeddings index for cross-capsule search?

```
