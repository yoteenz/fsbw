# UPDATED COLLABORATION MEMORY

Collaboration Intelligence deltas — shorthand, patterns, lessons, goosebump moments.

## AI Context Capsule — `CURRENT_HANDOFF.md` (modified)

```markdown
# Current Handoff — Active Sprint State

**Capsule:** StudioOS_ContextCapsule_v0.1  
**Last updated:** 2026-07-11  
**Git reference:** (pending restoration commit)

---

## Current sprint

**P0 Forensic — Shared Generation Pipeline Regression (Creative Studio restoration)**

Surgical root-cause isolation and Creative Studio governed-generation restoration on the shared `studio-builder-generate` path. Experience Engine Layer 1 remains a **separate** tracked blocker until founder verifies production traces.

**Previous:** Invite Manager sharing migration + password recovery (`3051691d2`, `bab32950c`).

---

## Current blocker

See `KNOWN_BLOCKERS.md` for full detail.

| ID | Blocker | Owner | Unblock |
|----|---------|-------|---------|
| **B1-restored** | Creative Studio validation compile — governed shell/layer generation | Founder (device) | Verify `/admin/studio/experience-lab` on normal mobile Safari + Chrome after deploy |
| **B1-ee** | Experience Engine Layer 1 — remaining failure after shared-path fix | Composer (separate sprint) | Production Black Box trace review; do not speculative-repair |

---

## Current debugging status

| System | Status | Notes |
|--------|--------|-------|
| Shared pipeline forensic report | ✅ Shipped | `docs/studio-os/forensics/SHARED_GENERATION_PIPELINE_REGRESSION.md` |
| Validation context gating | ✅ Shipped | `validation-compile-context.ts` + adapter hardening |
| Regression tests | ✅ 17/17 pass | `shared-generation-pipeline-regression.test.ts` |
| Lazy server ephemeral auth | ✅ Retained | `ensureValidationEphemeralAuth` on complete scope only |
| Blocking pre-pipeline auth | ✅ Removed | `ff19d5016` — do not reintroduce |
| Creative Studio production verify | ⏳ Pending | Founder mobile Safari + Chrome |
| Experience Engine Layer 1 | ❌ Isolated | Classify separately post-deploy |

---

## Latest architectural decisions

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-07-11 | Validation mode requires **complete compile scope** | Prevents Experience Lab field leakage into shared gateway |
| 2026-07-11 | Lazy auth on `studio-builder-generate` only | No blocking pre-pipeline serverless call |
| 2026-07-11 | Creative Studio restoration separate from EE repair | Shared root cause proven; EE may have additional failures |

---

## Founder verification checklist

1. Open https://fsbw.vercel.app/admin/studio/experience-lab in **normal** mobile Safari tab (signed in as admin).
2. Repeat in **normal** mobile Chrome tab.
3. Confirm shell reaches **Generate Shell** with `studio-builder` method (not only canvas fallback) when network allows.
4. Confirm Layer 1 attempt shows governed auth in Black Box (not bare `AUTH_REQUIRED` with complete scope).
5. If stale cache: https://fsbw.vercel.app/__studio-os-recovery first.

---

## Immediate next priorities

1. **Founder:** Mobile verification of Creative Studio route (checklist above).
2. **Founder:** Review forensic report; approve separate Experience Engine sprint if Layer 1 still fails.
3. **Composer (future):** Experience Engine-only repair from Black Box traces — no shared-path speculation.

---

## Key forensic references

- `docs/studio-os/forensics/SHARED_GENERATION_PIPELINE_REGRESSION.md`
- Last good: `7f4e73553`
- First bad (shared payload): `2408310f3`
- Pipeline block: `49e48c7e4`
- Lazy auth baseline: `ff19d5016`

```

## AI Context Capsule — `KNOWN_BLOCKERS.md` (modified)

```markdown
# KNOWN BLOCKERS — Do Not Violate

**Last updated:** 2026-07-11  
**Authority:** Overrides feature work, compile repair, and optimistic assumptions

---

## Gate rule

**Creative Studio** governed validation compiles: verify on production mobile **after restoration deploy** before resuming Experience Engine repair.

**Experience Engine Layer 1** remains blocked until Black Box traces confirm whether failure is auth-scope, provider, or compiler-state — **separate sprint**.

---

## B1-Creative-Studio — Shared pipeline regression (P0 — RESTORATION SHIPPED)

| Field | Detail |
|-------|--------|
| **ID** | B1-Creative-Studio |
| **Symptom** | Creative Studio at `/admin/studio/experience-lab` failed shell/layer governed generation after B1 auth commits |
| **Proven root cause** | `2408310f3` leaked `validationMode` + validation fields into shared `studio-builder-generate` without guaranteed server auth; `49e48c7e4` blocked pipeline at Compile Preview Spec when ephemeral auth endpoint failed |
| **Restoration** | Complete-scope gating (`validation-compile-context.ts`); lazy `ensureValidationEphemeralAuth` hardened; adapter execution context propagation |
| **Forensic report** | `docs/studio-os/forensics/SHARED_GENERATION_PIPELINE_REGRESSION.md` |
| **Verify** | Normal mobile Safari + Chrome on https://fsbw.vercel.app/admin/studio/experience-lab |
| **Status** | ⏳ Pending founder production verify |

### Do not

- Reintroduce blocking pre-pipeline `experience-lab-ephemeral-authorization` call before shell pipeline
- Default `validationMode` from global render mode without complete compile scope
- Disable authorization or add canvas fallback for Layer 1 to mask auth failure

---

## B1-Experience-Engine — Layer 1 remaining failure (P0 — ISOLATED)

| Field | Detail |
|-------|--------|
| **ID** | B1-Experience-Engine |
| **Symptom** | Experience Engine Layer 1 (`signature-landmark`) may still fail after shared-path restoration |
| **Distinction** | **Not** the same as Creative Studio shell regression; triage with Black Box after Creative Studio verified |
| **Classification candidates** | A authorization issuance · C scope mismatch · G provider · I UI/compiler desync |
| **Owner** | Composer (separate approved sprint) |
| **Unblock** | Founder approves EE repair after Creative Studio mobile verify + trace review |
| **Status** | ❌ Not repaired in this sprint |

### Verify compile diagnostic

```
https://fsbw.vercel.app/__world-compiler-investigation
```

Optional query: `?compilerDiag=1` on Experience Lab route.

---

## B2 — Diagnostic normal-tab verification

| Field | Detail |
|-------|--------|
| **ID** | B2 |
| **Recovery URL** | https://fsbw.vercel.app/__studio-os-recovery |
| **Status** | ⏳ Pending founder device verification |

---

## Historical reference (superseded for Creative Studio path)

Pre-2026-07-11 B1 entry documented Layer 1 `AUTH_REQUIRED` with shell canvas fallback masking. Shared-path restoration addresses **governed validation** auth issuance; Experience Engine Layer 1 may still need separate work.

```

## AI Context Capsule — `PROJECT_CHANGELOG.md` (modified)

```markdown
# Project Changelog™ — Architectural Decision History

**Capsule:** StudioOS_ContextCapsule_v0.1 · v0.3.0  
**Format:** Append-only. Newest entries at bottom.  
**Each entry:** Date · Decision · Reason · Impact · Files/docs · Supersedes · Dependencies

---

## 2026-07-08 — Multi-Company Route Architecture

**Decision:** Company-scoped routes use `/admin/studio/companies/{companySlug}/...`; global routes stay at command-center, atlas, etc.

**Reason:** Studio World is multi-company native; hardcoded `frontal-slayer` paths do not scale.

**Impact:** All new company-scoped UI must use `useCompanyRoute()`.

**Files:** `src/studio-os-core/company-routes/`, `motherboard/CORE.md`

**Supersedes:** Implicit single-company admin paths

**Dependencies:** CompanyRouteProvider on admin studio routes

---

## 2026-07-08 — Production Completion System (ARTICLE-K24)

**Decision:** Production Package auto-includes Production Completion Checklist + Quality Gates in Production Orchestrator.

**Reason:** Definition of Done for Studio World production packages.

**Impact:** COMPLETION tab on Production Board; scope inference skips irrelevant checkpoints.

**Files:** `src/studio-os-core/production-completion-system/`

---

## 2026-07-09 — studio-world-atlas Department Package Registration

**Decision:** Bundled canonical `studio-world-atlas` package in `DepartmentPackageRegistry` with boot-time validation.

**Reason:** Experience Lab referenced `studio-world-atlas` but static registry had only 3 entries — pipeline failed before Layer 1.

**Impact:** Package lookup resolves; Black Box registry events; dist verification script.

**Files:** `src/studio-os-core/department-package/`, commit `03726eaf9`

**Dependencies:** Scene stack render bindings, Experience Lab atlas department

---

## 2026-07-10 — Layer 1 Forensic Pass (No Repair)

**Decision:** Forensic sprint only for Layer 1 failure — freeze `FAILED_AT_LAYER_1`, fix misleading shell retry UI, do not repair generation.

**Reason:** UI concealed Landmark failure as shell failure; root cause needed before fix.

**Impact:** `?compilerDiag=1`, `layer1-forensic.ts`, LANDMARK GENERATION FAILED UI.

**Proven root cause:** `AUTH_REQUIRED` on governed generation — shell uses canvas fallback, Landmark does not.

**Files:** `useSceneStack.ts`, `SceneStackViewport.tsx`, `layer1-forensic.ts`, commit `506d77169`

**Supersedes:** Treating Layer 1 failure as shell invalidation

**Dependencies:** Future auth repair sprint before Experience Lab resume

---

## 2026-07-10 — Diagnostic Route Isolation

**Decision:** `/__studio-os-*` routes load via isolated `diagnostic-main.tsx`; pre-main probe before React; recovery page at `/__studio-os-recovery`.

**Reason:** Normal tabs failed (stale cache + global-boot before route split); private tabs worked.

**Impact:** Split entry architecture; scoped quarantine; export diagnostics; chunk reload disabled on diagnostic paths.

**Files:** `public/pre-main-probe.js`, `src/entry-dispatch.ts`, `src/diagnostic-entry/*`, commit `ef969cb7d`

**Supersedes:** Single `main.tsx` always importing `global-boot` before route detection

**Dependencies:** Normal-tab device verification

---

## 2026-07-10 — ChatGPT Operating Manual Package

**Decision:** Permanent external-AI onboarding at `docs/ai-collaboration/` separate from motherboard and product bibles.

**Reason:** Brand-new ChatGPT conversations need near-perfect continuity in minutes.

**Impact:** Eight core docs + export specification; maintenance strategy; NEW_CHAT_CHECKLIST.

**Files:** `docs/ai-collaboration/*`

**Dependencies:** Founder updates `CURRENT_HANDOFF.md` each sprint; future AI Context Capsule automation

---

*Append new decisions below this line.*

## 2026-07-10 — ChatGPT Operating Manual Package (delivered)

**Decision:** Permanent external-AI onboarding at `docs/ai-collaboration/` with eight core docs, export spec, and CLI stub `npm run export:ai-context-capsule`.

**Reason:** Brand-new ChatGPT conversations need near-perfect continuity in minutes; separate from motherboard (Cursor) and product bibles.

**Impact:** NEW_CHAT_CHECKLIST onboarding path; CURRENT_HANDOFF as living sprint snapshot; PROMPT_TEMPLATES for Composer/Terra; no Studio OS app features changed.

**Files:** `docs/ai-collaboration/*`, `scripts/export-ai-context-capsule.mjs`, `package.json` script

**Supersedes:** Ad-hoc ChatGPT context pastes without structure

**Dependencies:** Founder maintains CURRENT_HANDOFF; Phase 2 automates capsule on release

---

## 2026-07-10 — AI Context Capsule™ v2 canonical architecture (docs only)

**Decision:** Single portable `.studiocapsule` ZIP replaces dozens of loose Markdown exports as the canonical AI continuity layer.

**Reason:** Founder should upload one file; any AI (ChatGPT, Claude, Gemini, Cursor) onboarded in minutes without manual re-explaining Studio OS.

**Impact:** `AI_CONTEXT_CAPSULE_SPECIFICATION.md` v2.0.0 — package layout, manifest v2 schema, versioning, compression, import/export workflows, smart export types, HQ Archive path, automation roadmap. Source docs: `FOUNDER_PROFILE.md`, `PROJECT_DNA.md`, `AI_MEMORY_SNAPSHOT.md`. `EXPORT_SPECIFICATION.md` demoted to v1 appendix.

**Files:** `docs/ai-collaboration/AI_CONTEXT_CAPSULE_SPECIFICATION.md`, `schemas/manifest.v2.schema.json`, supporting sources, README/NEW_CHAT_CHECKLIST updates.

**Supersedes:** Flat md+json as primary deliverable (CLI remains Phase 1 interim)

**Dependencies:** Phase 2 CLI `.studiocapsule` builder; Phase 4 HQ Archive UI

---

## 2026-07-10 — AI Context Protocol™ v1.0 (institutional memory — docs only)

**Decision:** AI Context Protocol™ becomes the canonical onboarding standard; AI Context Capsule™ is one implementation. Goal shifts from exporting documentation to transferring institutional memory.

**Reason:** Receiving AI should behave as though it participated for months — knowing why, how decisions were made, and how collaboration works. North star: "Git clones code; AI Context Protocol clones organizational understanding."

**Impact:** `AI_CONTEXT_PROTOCOL_SPECIFICATION.md` v1.0.0 + fifteen module specs under `protocol/` (bootstrap, health, memory graph, decision memory, collaboration memory, Founder DNA, Project DNA, canon engine, timeline, onboarding report, knowledge diff, AI Passport, Institutional Memory Engine, compatibility matrix, evolution roadmap). `schemas/manifest.v3.schema.json` adds protocol module paths. Capsule target layout v3 documented; no CLI/HQ code.

**Files:** `docs/ai-collaboration/AI_CONTEXT_PROTOCOL_SPECIFICATION.md`, `docs/ai-collaboration/protocol/*`, `schemas/manifest.v3.schema.json`, README/CURRENT_HANDOFF updates.

**Supersedes:** Treating capsule as documentation zip only (capsule now implements protocol)

**Dependencies:** Phase 2 capsule builder v3; Phase 3 HQ Archive; B1/B2 unchanged

---

## 2026-07-10 — Studio AI™ v1.0 (persistent intelligence layer — docs only)

**Decision:** Studio AI is the permanent intelligence layer of Studio OS — not an LLM. Foundation models are interchangeable reasoning engines; Studio AI owns identity, roles, persona, and institutional memory continuity.

**Reason:** Models evolve; founder relationships, projects, culture, and memory must persist across upgrades. North star: founders ask "What version of Studio AI?" not "What model are you?"

**Impact:** `docs/studio-os/studio-ai/` — Vision Bible + Persistent Intelligence Architecture, REA, AI Succession System, Institutional Memory Architecture, Executive Role Model, Persona Continuity, Model Compatibility Layer, Upgrade Workflow, Long-Term Roadmap. Succession ceremony treats model upgrades as executive succession. Roles (Creative Director, Professors) survive engine changes.

**Files:** `docs/studio-os/studio-ai/*`, CURRENT_HANDOFF, README cross-links.

**Supersedes:** Identifying platform AI with vendor model names

**Dependencies:** AI Context Protocol + IME (memory transfer); Genesis Core (visual layer); native runtime Phase 2+

---

## 2026-07-10 — AI Context Capsule v0.1 manual prototype

**Decision:** First complete manually generated capsule folder (`StudioOS_ContextCapsule_v0.1/`) for protocol validation — no export automation.

**Reason:** Validate AI Context Protocol by onboarding brand-new ChatGPT without founder re-explaining Studio OS.

**Impact:** 14 markdown files including README_FIRST (mandatory onboarding protocol), MANIFEST, KNOWN_BLOCKERS, OPEN_QUESTIONS, full collaboration package. Flat layout pre-ZIP.

**Files:** `StudioOS_ContextCapsule_v0.1/*`

**Supersedes:** Ad-hoc partial pastes as onboarding path for external AI test

**Dependencies:** Founder onboarding report review; future CLI automation Phase 2

---

## 2026-07-10 — AI Context Capsule v0.2 — Onboarding & Validation

**Decision:** Standardize onboarding via `ONBOARDING_REPORT.md` template, expand `FOUNDER_PROFILE.md`, add `context-capsule.json` metadata, and block ZIP export when required onboarding docs are missing.

**Reason:** v0.1 validation showed strong project transfer but inferred onboarding reports and partial founder workflow reconstruction.

**Impact:** External AI completes fixed report (Founder Preference Verification, Canon Verification, Confidence Assessment) and waits for approval; prebuild validates 15 markdown files + metadata.

**Files:** `StudioOS_ContextCapsule_v0.1/*`, export pipeline, `docs/ai-collaboration/protocol/ONBOARDING_REPORT.md`

**Supersedes:** v0.1 "generate an onboarding report" (invented format)

**Dependencies:** `npm run package:ai-context-capsule-zip` in prebuild

---

## 2026-07-10 — AI Context Capsule v0.3 — Deterministic verification onboarding

**Decision:** Upgrade onboarding from summary-style to **verification-style** — compliance checklist, operational source-of-truth hierarchy, documented-vs-inferred labels, documentation review with certainty tags, auto-generated `CAPSULE_VALIDATION.md`.

**Reason:** v0.2 still allowed false confidence (recovery-style summaries, generic "capsule is truth"); ChatGPT sessions needed stricter evidence-first protocol.

**Impact:** ONBOARDING_REPORT restructured; export validation checks version sync + v0.3 sections; generator 0.3.0; versioned ZIP `StudioOS_ContextCapsule_v0.3.0.zip`.

**Files:** `StudioOS_ContextCapsule_v0.1/README_FIRST.md`, `ONBOARDING_REPORT.md`, `MANIFEST.md`, `CAPSULE_VALIDATION.md`, `scripts/package-ai-context-capsule-zip.mjs`, `context-capsule-export/constants.ts`

**Supersedes:** v0.2 onboarding template sections (Founder Preference Verification → Founder Understanding; added Compliance Checklist, Operational Source of Truth, Documentation Review)

**Dependencies:** `npm run package:ai-context-capsule-zip` in prebuild

---

## 2026-07-11 — Shared Generation Pipeline Regression (Creative Studio restoration)

**Decision:** Gate Experience Lab `validationMode` on complete compile scope (compileRunId, previewSessionId, organizationId, departmentId, stationId, projectId). Retain lazy `ensureValidationEphemeralAuth` on `studio-builder-generate`; do not restore blocking pre-pipeline ephemeral auth call.

**Reason:** B1 commits `2408310f3`–`ff19d5016` leaked validation fields into shared governed generation, causing `AUTH_REQUIRED` on Creative Studio and blocking Compile Preview Spec when the ephemeral auth endpoint failed on Vercel.

**Impact:** Creative Studio validation compiles receive server-issued ephemeral authorization when scope is complete; incomplete scope no longer poisons shared requests. Experience Engine Layer 1 remains a separate blocker.

**Files:** `docs/studio-os/forensics/SHARED_GENERATION_PIPELINE_REGRESSION.md`, `src/studio-os-core/creative-production/validation-compile-context.ts`, `api/_lib/creativeProduction/legacy-adapters.ts`, `src/hooks/useSceneStack.ts`, `shared-generation-pipeline-regression.test.ts`

**Supersedes:** Unscoped global `isExperienceLabValidationRender()` default for generation payloads

**Dependencies:** Founder mobile verify o

... [truncated in delta summary — see changes/ for full file]
```
