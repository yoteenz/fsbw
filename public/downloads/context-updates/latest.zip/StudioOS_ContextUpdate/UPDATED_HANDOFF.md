# UPDATED HANDOFF

Operational handoff and blocker updates.

## Collaboration Intelligence Capsule — `AI_LESSONS.md` (added)

```markdown
# AI Lessons

Mistakes that must **never repeat**. Maturity: **Canonical**.

---

## Planning vs implementation

| Lesson | Detail |
|--------|--------|
| **Do not assume planned = implemented** | Roadmap, Genesis, and MEMORY describe intent; verify in code before claiming shipped |
| **Do not confuse capsule with codebase** | Onboarding docs may ahead of or behind production |

---

## Prompt and sprint discipline

| Lesson | Detail |
|--------|--------|
| **Do not split Composer sprints** | One user request → one complete implementation pass |
| **Do not forget code blocks** | Founder Composer specs belong in fenced blocks |
| **Do not summarize founder prompts** | Read full sprint text; every section may be binding |

---

## Architecture and canon

| Lesson | Detail |
|--------|--------|
| **Do not replace architecture** | Repair blockers surgically; no redesign during forensic sprints |
| **Do not remove approved terminology** | Goosebump terms, Studio OS naming, trademark forms are intentional |
| **Do not create dashboards casually** | Spatial review question 8: "Does this create another dashboard?" |
| **Do not bypass governance** | No `CREATIVE_PRODUCTION_ALLOW_LEGACY_COMPAT` as default production fix |

---

## Memory and context

| Lesson | Detail |
|--------|--------|
| **Do not lose long-term context** | Read motherboard at chat start; append MEMORY after tasks |
| **Do not treat motherboard as missing** | It is `motherboard/` folder, not `MOTHERBOARD.md` at root |
| **Do not double-deploy** | One push per task; no amend+force-push repair loops |

---

## Authorization and security

| Lesson | Detail |
|--------|--------|
| **Do not hardcode production auth IDs** | Server-issued ephemeral auth for validation only |
| **Do not put FAL keys in browser** | Governed generation stays server-side |
| **Do not block pipeline on broken new endpoints** | Prefer lazy issuance on proven paths when standalone API fails |

---

## Collaboration UX

| Lesson | Detail |
|--------|--------|
| **Do not trust local-only password hash** | Invite Manager must verify server when local cache stale |
| **Do not declare B1 fixed without Layer 1 evidence** | AUTH_REQUIRED vs FAL vs browser require distinct proof |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, DECISION_HISTORY.md  
**Future Questions:** AI_LESSONS linked to incident IDs in MEMORY?

```

## Collaboration Intelligence Capsule — `COLLABORATION_GLOSSARY.md` (added)

```markdown
# Collaboration Glossary

Founder ↔ AI shorthand. **Not** a technical API glossary — see AI Context `AI_GLOSSARY.md` for implementation terms.

Each entry: **Meaning · Origin · Purpose · Maturity**

---

## Black Box

| Field | Value |
|-------|-------|
| **Meaning** | World Compiler Investigation Recorder — forensic lifecycle logging for Experience Lab compiles |
| **Origin** | Experience Lab compiler diagnostics (`?compilerDiag=1`, Layer 1 freeze, stall evidence) |
| **Purpose** | Records compiler lifecycle, browser differences, pipeline failures, async boundaries |
| **Maturity** | Approved |

---

## The Mansion

| Field | Value |
|-------|-------|
| **Meaning** | Immersive Studio World interface — spatial HQ, departments, stations |
| **Origin** | Studio World / spatial computing philosophy |
| **Purpose** | Distinguishes founder-facing world navigation from flat admin dashboards |
| **Maturity** | Canonical |

---

## Motherboard

| Field | Value |
|-------|-------|
| **Meaning** | Repository institutional memory folder (`motherboard/`) — CORE, CODEBASE, MEMORY |
| **Origin** | Build-a-Wig agent continuity system |
| **Purpose** | Cross-chat memory; auto-append after tasks; not a single file at repo root |
| **Maturity** | Canonical |

---

## Goosebump Moment

| Field | Value |
|-------|-------|
| **Meaning** | Strategic breakthrough where Founder believes Studio OS evolved beyond conventional software |
| **Origin** | Founder language during civilization / marketplace / knowledge capture arcs |
| **Purpose** | Marks concepts worth canonizing — see `GOOSEBUMP_MOMENTS.md` |
| **Maturity** | Approved |

---

## Composer Sprint

| Field | Value |
|-------|-------|
| **Meaning** | One comprehensive, production-ready implementation specification — never fragmented |
| **Origin** | Founder prompt protocol for Cursor Composer agents |
| **Purpose** | Full context in one code block; complete deliverable per sprint |
| **Maturity** | Canonical |

---

## Terra

| Field | Value |
|-------|-------|
| **Meaning** | Governance reviewer (GPT-5.6 Terra) — constitutional architecture, not implementation |
| **Origin** | Constitution First Principle™; Spatial Architecture Review |
| **Purpose** | Reviews ownership, gates dashboards, approves world placement before code |
| **Maturity** | Canonical |

---

## B1 / B2 (Experience Lab)

| Field | Value |
|-------|-------|
| **Meaning** | B1 = compiler authorization blocker (governed FAL); B2 = normal-tab load verification |
| **Origin** | Experience Lab repair sprints 2026-07 |
| **Purpose** | Sequenced repair gates — do not declare complete until both verified |
| **Maturity** | Working |

---

## Ephemeral productionAuthorizationId

| Field | Value |
|-------|-------|
| **Meaning** | Server-issued, compile-scoped auth for Experience Lab validation — not production canon |
| **Origin** | B1 repair; founder-approved policy |
| **Purpose** | Allows governed FAL without permanent elevation or Asset Registry promotion |
| **Maturity** | Approved |

---

## One deploy per task

| Field | Value |
|-------|-------|
| **Meaning** | Each completed agent task = one commit + one push to `master` (incl. MEMORY.md) |
| **Origin** | Vercel production deploy cost / stability |
| **Purpose** | Prevents double deploys, amend+force-push loops, Motherboard follow-up commits |
| **Maturity** | Canonical |

---

## Place over menu

| Field | Value |
|-------|-------|
| **Meaning** | Spatial placement principle — features belong in world departments, not floating menus |
| **Origin** | Studio OS spatial architecture canon |
| **Purpose** | Reject orphan pages, generic dashboards, settings dumping grounds |
| **Maturity** | Canonical |

---

## Studio Workers

| Field | Value |
|-------|-------|
| **Meaning** | AI profession brains employed via Digital Payroll — not generic chatbots |
| **Origin** | Marketplace + civilization economy arc |
| **Purpose** | Expert knowledge → trainable workers → marketplace assets |
| **Maturity** | Approved |

---

## Living Knowledge Mirror

| Field | Value |
|-------|-------|
| **Meaning** | Expert knowledge reflected back for validation before vault promotion |
| **Origin** | Knowledge Capture / Expert Capture system |
| **Purpose** | Human-in-the-loop before canon |
| **Maturity** | Approved |

---

## Spatial Architecture Review

| Field | Value |
|-------|-------|
| **Meaning** | Mandatory 10-question gate before Studio OS product implementation |
| **Origin** | `STUDIO_OS_BIBLE/SPATIAL_ARCHITECTURE_REVIEW.md` |
| **Purpose** | Prevents dashboards, orphan surfaces, non-spatial workflows |
| **Maturity** | Canonical |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** SEARCH_INDEX.md, GOOSEBUMP_MOMENTS.md  
**Future Questions:** Glossary versioning when terms alias (e.g. Creative Direction Studio naming)?

```

## Collaboration Intelligence Capsule — `COLLABORATION_INTELLIGENCE_INDEX.md` (added)

```markdown
# Collaboration Intelligence Index

Category map for the Collaboration Intelligence Capsule™ v1.0.0.

| # | Document | Answers | Maturity |
|---|----------|---------|----------|
| 1 | COLLABORATION_GLOSSARY.md | What does the Founder mean by X? | Working–Canonical |
| 2 | DECISION_HISTORY.md | What was decided, rejected, approved? | Approved–Canonical |
| 3 | EVOLUTION_TIMELINE.md | How did ideas evolve? | Historical–Working |
| 4 | FOUNDER_PREFERENCES.md | How does the Founder want to work? | Approved |
| 5 | AI_LESSONS.md | What mistakes must never repeat? | Canonical |
| 6 | GOOSEBUMP_MOMENTS.md | What breakthroughs mattered? | Canonical |
| 7 | HISTORICAL_CONTEXT.md | Why were solutions chosen? | Historical–Approved |
| 8 | RELATIONSHIP_MEMORY.md | Shared language and expectations | Working |
| 9 | IMPORTANT_CONVERSATIONS.md | Structured summaries (not transcripts) | Historical–Approved |
| 10 | COLLABORATION_PATTERNS.md | How sprints and reviews flow | Approved |
| 11 | MEMORY_MATURITY.md | Entry lifecycle taxonomy | Canonical |
| 12 | SEARCH_INDEX.md | Semantic lookup | Working |

## Quick lookup

- **Compiler / Experience Lab:** Black Box, World Compiler, Experience Lab, B1/B2, ephemeral auth
- **Economy / civilization:** Marketplace, Studio Workers, Knowledge Capture, Goosebump
- **Memory systems:** Motherboard, Collaboration Intelligence, capsules
- **Process:** Composer Sprint, Terra, one deploy per task

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** MANIFEST.md, SEARCH_INDEX.md  
**Future Questions:** Auto-generate index from collaboration-intelligence.json searchTerms?

```

## Collaboration Intelligence Capsule — `COLLABORATION_PATTERNS.md` (added)

```markdown
# Collaboration Patterns

How Founder and AI typically move from exploration to shipped canon.

---

## Standard arc

```
Founder explores widely (vision, critique, "what if")
    ↓
AI narrows (options, risks, codebase truth)
    ↓
Visualize first (diagrams, placement, spatial review if Studio OS product)
    ↓
Prototype mentally (read code paths, trace requests)
    ↓
Architecture (Terra / Spatial Review when required)
    ↓
Composer Sprint (single comprehensive spec)
    ↓
Implementation (surgical diff, conventions matched)
    ↓
Verification (build, test, forensic evidence for compilers)
    ↓
Documentation (deliverables list, no scope creep)
    ↓
Capsule / Motherboard update (MEMORY append, one deploy)
    ↓
Founder verification (browser, production)
```

---

## Sprint types

| Type | Pattern |
|------|---------|
| **Composer Sprint** | One approved spec → one implementation → one deploy |
| **Forensic / repair** | Trace request chain; root cause; minimal fix; evidence checklist |
| **Onboarding** | Read all manifest files → one report → stop for approval |
| **Capsule** | Author docs → validate → package ZIP → update onboarding pack |

---

## Founder exploration mode

- Wide strategic questions are **not** implementation requests.
- AI should answer with canon + codebase truth, not jump to code.
- When Founder shifts to "APPROVED" / "IMPLEMENT" — switch to sprint mode.

---

## AI narrowing mode

- Offer 2–3 bounded options with tradeoffs.
- Cite files and lines.
- Flag when request would violate canon (dashboard, bypass auth, redesign protected admin).

---

## Verification norms

| Domain | Evidence expected |
|--------|-------------------|
| Compiler | Layer forensic, auth reaches FAL, no AUTH_REQUIRED |
| Deploy | One push; build pass |
| Auth | Server hash + client path documented |
| UI repair | Named page/section only (Frontal Slayer admin) |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, AI_LESSONS.md  
**Future Questions:** Pattern tags in collaboration-intelligence.json?

```

## Collaboration Intelligence Capsule — `DECISION_HISTORY.md` (added)

```markdown
# Decision History

Structured institutional decisions from Founder ↔ AI collaboration. **Not** exhaustive — highest-signal gates only.

Format: Decision · Reason · Alternatives · Rejected · Approval · Date · Related

---

## Ephemeral productionAuthorizationId (Experience Lab)

| Field | Value |
|-------|-------|
| **Decision** | Server-issued, compile-scoped `productionAuthorizationId` for validation compiles only |
| **Reason** | Production governed generation requires auth; validation must not promote to canon |
| **Alternatives** | Hardcoded client ID; `CREATIVE_PRODUCTION_ALLOW_LEGACY_COMPAT=1` on Vercel |
| **Rejected** | Global legacy compat; permanent elevation; canvas/placeholder landmarks |
| **Final approval** | Founder B1 repair sprint |
| **Date** | 2026-07-11 |
| **Related** | `ephemeral-validation-auth.ts`, Experience Lab runtime, B1/B2 |
| **Maturity** | Approved |

---

## One deployment per task

| Field | Value |
|-------|-------|
| **Decision** | Each agent task = one `git commit` + one `git push` to `master` including `MEMORY.md` |
| **Reason** | Each push triggers Vercel production deploy |
| **Alternatives** | Separate Motherboard commits; amend+force-push to fix messages |
| **Rejected** | Multi-push repair loops; `cursor/*` side branches as default |
| **Final approval** | Founder + `.cursor/rules/one-deploy-per-task.mdc` |
| **Date** | 2026-07 (ongoing) |
| **Related** | `scripts/agent-commit.sh`, motherboard auto-add |
| **Maturity** | Canonical |

---

## Work on master only

| Field | Value |
|-------|-------|
| **Decision** | No `cursor/*` or `feature/*` branches for cloud agents — commit to `master` |
| **Reason** | Single production line; avoids PR branch drift |
| **Alternatives** | Feature branches per task |
| **Rejected** | Default Cursor cloud `cursor/<name>` branch policy |
| **Final approval** | `motherboard/CORE.md` branch policy |
| **Date** | 2026-07 |
| **Related** | git-branch-policy.mdc |
| **Maturity** | Canonical |

---

## Place over menu (spatial IA)

| Field | Value |
|-------|-------|
| **Decision** | Features live in Studio World departments; no floating utility dashboards |
| **Reason** | Spatial computing philosophy; avoid dashboard sprawl |
| **Alternatives** | Generic admin dashboards; feature-first nav |
| **Rejected** | Orphan pages; duplicate departments |
| **Final approval** | Spatial Architecture Review canon |
| **Date** | 2026 (Studio OS Bible) |
| **Related** | M83 Executive IA, Spatial Architecture Review |
| **Maturity** | Canonical |

---

## Marketplace philosophy

| Field | Value |
|-------|-------|
| **Decision** | Marketplace evolves toward civilization economy — knowledge, workers, licensing |
| **Reason** | Studio OS is operating system for creative civilization, not a storefront skin |
| **Alternatives** | Pure digital product storefront |
| **Rejected** | Treating marketplace as WooCommerce clone |
| **Final approval** | Founder Intelligence `MARKETPLACE.md` |
| **Date** | 2026 |
| **Related** | `EVOLUTION_TIMELINE.md`, Studio Workers |
| **Maturity** | Approved |

---

## Studio Workers / Digital Payroll

| Field | Value |
|-------|-------|
| **Decision** | Expert knowledge trains profession brains; workers are marketplace assets with payroll metaphor |
| **Reason** | Institutional learning compounds; experts are supply side |
| **Alternatives** | One-off expert consultations only |
| **Rejected** | Generic AI assistants without profession identity |
| **Final approval** | Goosebump-tier concept |
| **Date** | 2026 |
| **Related** | Knowledge Capture, Interview Engine |
| **Maturity** | Approved |

---

## Knowledge Capture (private invites)

| Field | Value |
|-------|-------|
| **Decision** | Private expert invites via Studio Institute; owner password auth; no public signup |
| **Reason** | Trust, governance, founder-controlled access |
| **Alternatives** | `STUDIO_INSTITUTE_OWNER_KEY` env only |
| **Rejected** | Open expert registration |
| **Final approval** | Expert Capture Phase 1 |
| **Date** | 2026-07-11 |
| **Related** | `/studio-institute/invites`, Expert Trust Framework |
| **Maturity** | Approved |

---

## Frontal Slayer Admin Alignment Protocol

| Field | Value |
|-------|-------|
| **Decision** | Admin dashboard pages protected by default — explicit page + section authorization only |
| **Reason** | Founder loves specific pages; coherence not uniformity |
| **Alternatives** | Global admin redesign / standardization |
| **Rejected** | Unrequested modernization of finalized admin pages |
| **Final approval** | `ADMIN_ALIGNMENT_PROTOCOL.md` |
| **Date** | 2026 |
| **Related** | frontal-slayer-admin-alignment.mdc |
| **Maturity** | Canonical |

---

## Capsule distribution (static ZIP)

| Field | Value |
|-------|-------|
| **Decision** | Onboarding capsules as static ZIP + release.json — no serverless download bundling |
| **Reason** | Vercel ~1GB deploy failure from dynamic fs bundling |
| **Alternatives** | `api/capsules/*` serverless handlers |
| **Rejected** | Re-introducing capsule API routes |
| **Final approval** | Capsule packaging sprint |
| **Date** | 2026-07-11 |
| **Related** | `sync-capsule-latest-vercel-routes.mjs` |
| **Maturity** | Approved |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** EVOLUTION_TIMELINE.md, IMPORTANT_CONVERSATIONS.md  
**Future Questions:** Decision registry machine IDs for cross-capsule linking?

```

## Collaboration Intelligence Capsule — `EVOLUTION_TIMELINE.md` (added)

```markdown
# Evolution Timeline

How major concepts evolved through collaboration. **Original → evolution → current canon → future direction.**

---

## Marketplace

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Digital storefront for products | Historical |
| **Later** | Knowledge marketplace — experts, courses, assets | Working |
| **Current** | Civilization economy — workers, licensing, commissions, institutional learning | Approved |
| **Future** | Full Studio Team / Studio HR lifecycle; retirement and training pipelines | Experimental |

---

## Studio World / The Mansion

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Admin dashboard + pages | Historical |
| **Later** | Spatial departments, stations, Scene Stack | Working |
| **Current** | Studio OS Headquarters — immersive world navigation | Canonical |
| **Future** | Deeper Genesis integration; fewer orphan admin surfaces | Working |

---

## Experience Engine / Experience Lab

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Preview render hook in World Compiler UI | Historical |
| **Later** | Experience Lab runtime decoupling — runtime owns execution | Approved |
| **Current** | Validation compile with ephemeral shell + governed layers; B1 auth repair | Working |
| **Future** | Full multi-brand validation matrix; stable Layer 1 FAL path | Experimental |

---

## World Compiler

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Scene stack compile stages in UI hook | Historical |
| **Later** | Forensic investigation (Black Box), Layer 1 freeze | Approved |
| **Current** | Read-only World Compiler UI; Experience Lab runtime owns pipeline | Canonical |
| **Future** | Reduced stall classes; shell recovery state machine hardening | Working |

---

## Build-a-Wig / FSBW

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Wig commerce site | Historical |
| **Later** | Studio OS shell on same deployment (`fsbw.vercel.app`) | Working |
| **Current** | Dual mandate: commerce + Studio OS R&D platform | Approved |
| **Future** | Clearer route isolation; boot hygiene for stale storage | Working |

---

## AI Onboarding

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | AI Context Capsule only | Historical |
| **Later** | + Founder Intelligence + Studio DNA | Approved |
| **Current** | + Collaboration Intelligence (fourth capsule) | Approved |
| **Future** | Semantic search across capsules; maturity-tagged auto-updates | Experimental |

---

## Motherboard

| Stage | Description | Maturity |
|-------|-------------|----------|
| **Originally** | Manual "add to motherboard" | Historical |
| **Later** | Auto-append MEMORY per task; one-deploy rule | Canonical |
| **Current** | CORE + CODEBASE + MEMORY required at chat start | Canonical |
| **Future** | Selective MEMORY compaction (never delete history) | Experimental |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** HISTORICAL_CONTEXT.md, GOOSEBUMP_MOMENTS.md  
**Future Questions:** Timeline entries linked to git commits automatically?

```

## Collaboration Intelligence Capsule — `GOOSEBUMP_MOMENTS.md` (added)

```markdown
# Goosebump Moments

Major conceptual breakthroughs the Founder marked as civilization-scale. These are **not** minor features.

| Moment | Why it mattered | Maturity |
|--------|-----------------|----------|
| **Studio Marketplace** | Commerce becomes civilization economy — not a skin on a store | Canonical |
| **Studio Workers** | Experts train profession brains; Digital Payroll metaphor | Canonical |
| **Knowledge Capture** | Institutional learning from real experts | Approved |
| **Civilization Layer** | Studio OS as operating system for creative civilization | Canonical |
| **Legacy Network** | Long-horizon expert and knowledge graph | Approved |
| **Living Knowledge Mirror** | Expert sees their knowledge reflected before vault | Approved |
| **Expert Trust Framework** | Governance for private expert participation | Approved |
| **Digital Payroll** | Workers as employed assets, not disposable bots | Approved |
| **Profession Brains** | Domain-specific trained workers vs generic AI | Approved |
| **Interview Engine** | Private structured expert interviews | Approved |
| **World Compiler** | Experience compiles through layered scene assembly | Approved |
| **Studio Institute** | Private expert capture institution inside Studio OS | Approved |
| **Knowledge Vault** | Long-term governed expert knowledge storage | Approved |
| **Experience Lab runtime decoupling** | Runtime owns execution; compiler UI subscribes | Approved |
| **Unified Onboarding Pack** | One handoff URL for complete AI context | Approved |
| **Collaboration Intelligence Capsule** | Preserves *how* we built it — fourth onboarding pillar | Approved |

**Usage:** When Founder says "Goosebump" or references this list, treat the concept as **strategic canon** — document impact, do not trivialize as a small UI tweak.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** EVOLUTION_TIMELINE.md, COLLABORATION_GLOSSARY.md  
**Future Questions:** Founder-signed Goosebump registry with dates?

```

## Collaboration Intelligence Capsule — `HISTORICAL_CONTEXT.md` (added)

```markdown
# Historical Context

Problems solved, false starts, and major investigations. **Why** solutions were chosen.

---

## Experience Lab / World Compiler (2026-07)

**Problem:** Validation compile failed at Signature Landmark™ (`AUTH_REQUIRED`, `GENERATION_FAILED`).  
**False starts:** Hardcoded ephemeral auth ID; blocking pre-pipeline auth API that crashed on Vercel (`FUNCTION_INVOCATION_FAILED`).  
**Solution path:** Server-issued lazy ephemeral auth on `studio-builder-generate`; runtime no longer blocks on separate auth endpoint.  
**Lesson:** Layer 0 shell has canvas fallback; Layer 1+ does not — auth must reach governed FAL.  
**Maturity:** Approved

---

## Normal tab vs incognito (2026-07)

**Problem:** Routes work in private tabs but fail in normal tabs after deploys.  
**Cause:** Stale `localStorage` / `sessionStorage`, stuck `data-loading-screen`, bisection flags.  
**Solution:** `runBootHygiene()` on every boot; `/__studio-os-recovery` route; post-load-render-guard on all routes.  
**Maturity:** Approved

---

## Vercel capsule deploy failure (~1GB)

**Problem:** Serverless capsule download routes bundled entire `public/`.  
**Solution:** Static ZIP + `sync-capsule-latest-vercel-routes.mjs`; deleted `api/capsules/*`.  
**Maturity:** Approved

---

## Invite Manager owner password (2026-07)

**Problem:** Phone could not unlock dashboard without Vercel env key.  
**Solution:** Founder password → SHA-256 → `app_config` + localStorage; server verification on new devices.  
**Follow-up bug:** Stale local hash blocked server verify — fixed unlock order.  
**Maturity:** Approved

---

## Build-a-Wig evolution

**Problem:** Single wig commerce site needed Studio OS R&D without forked deployment.  
**Solution:** Same repo, same Vercel project (`fsbw.vercel.app`); Studio routes under `/admin/studio/*`, institute under `/studio-institute/*`.  
**Maturity:** Working

---

## Marketplace evolution

**Problem:** Risk of "digital storefront" thinking flattening civilization vision.  
**Solution:** Document evolution in Founder Intelligence + this timeline; commission, licensing, workers as first-class.  
**Maturity:** Approved

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** IMPORTANT_CONVERSATIONS.md, EVOLUTION_TIMELINE.md  
**Future Questions:** Link investigations to Black Box compile run IDs?

```

## Collaboration Intelligence Capsule — `IMPORTANT_CONVERSATIONS.md` (added)

```markdown
# Important Conversations

Structured summaries — **not transcripts**. Each entry: Title · Importance · Outcome · Canon impact · Related systems.

---

## Experience Lab B1 — Ephemeral Authorization

| Field | Value |
|-------|-------|
| **Title** | B1 Repair: server-issued ephemeral productionAuthorizationId |
| **Importance** | Critical — blocked all Layer 1+ validation compiles in production |
| **Outcome** | Lazy server issuance on studio-builder-generate; removed blocking pre-pipeline API |
| **Canon impact** | Validation auth policy approved; exploratory_draft output class |
| **Related** | Experience Lab runtime, creative-production gateway, FAL |
| **Maturity** | Approved |

---

## Experience Lab B2 — Normal Tab Verification

| Field | Value |
|-------|-------|
| **Title** | Normal browser tab load after site data clear |
| **Importance** | High — distinguished browser state from compiler bugs |
| **Outcome** | B2 verified; B1 remained compiler/auth focus |
| **Canon impact** | Boot hygiene + recovery route reinforced |
| **Related** | boot-hygiene.ts, `__studio-os-recovery` |
| **Maturity** | Approved |

---

## Unified Onboarding Pack + Capsule static routing

| Field | Value |
|-------|-------|
| **Title** | Capsule deploy size / static latest URLs |
| **Importance** | Critical — production deploys failing |
| **Outcome** | Static ZIP rewrites; four-capsule onboarding direction |
| **Canon impact** | `/onboarding/latest` as preferred handoff |
| **Related** | vercel.json, prebuild scripts |
| **Maturity** | Approved |

---

## Studio Institute owner password

| Field | Value |
|-------|-------|
| **Title** | Replace Vercel owner key with founder password |
| **Importance** | High — mobile founder access |
| **Outcome** | Password hash in app_config; unlock flow; stale local fix |
| **Canon impact** | Expert Capture owner auth pattern |
| **Related** | `/studio-institute/invites` |
| **Maturity** | Approved |

---

## Collaboration Intelligence Capsule approval

| Field | Value |
|-------|-------|
| **Title** | Fourth onboarding capsule for institutional collaboration memory |
| **Importance** | Critical — months of shorthand otherwise lost to new agents |
| **Outcome** | CIC v1.0 spec approved; this capsule |
| **Canon impact** | Onboarding order: Context → FIC → DNA → CIC → Handoff |
| **Related** | All onboarding capsules |
| **Maturity** | Approved |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** HISTORICAL_CONTEXT.md, DECISION_HISTORY.md  
**Future Questions:** Conversation entry template in onboarding report?

```

## Collaboration Intelligence Capsule — `MEMORY_MATURITY.md` (added)

```markdown
# Memory Maturity

Taxonomy for Collaboration Intelligence entries. Every glossary term, decision, and conversation summary should declare maturity where practical.

---

## Levels

| Level | Definition | Agent behavior |
|-------|------------|----------------|
| **Experimental** | Explored in conversation; not approved for build | Do not implement without founder approval |
| **Historical** | Accurate for a past phase; may be outdated | Use for context only; verify against handoff |
| **Working** | Current operating assumption | Follow unless contradicted by handoff/code |
| **Approved** | Founder-approved policy or pattern | Follow unless explicit override |
| **Canonical** | Binds architecture, naming, or process | Do not contradict without constitutional review |
| **Deprecated** | Replaced; kept for lookup | Do not apply to new work |

---

## Promotion path

```
Experimental → Working → Approved → Canonical
                    ↘ Historical → Deprecated
```

Promotion requires **founder explicit approval** or documented decision in `DECISION_HISTORY.md`.

---

## Demotion

When code or handoff supersedes an entry:

1. Mark original **Deprecated** or **Historical**
2. Add successor entry with **Working** or **Approved**
3. Append MEMORY.md with conversation summary

---

## Cross-capsule maturity

| Capsule | Primary maturity domain |
|---------|-------------------------|
| AI Context | Operational truth (always current) |
| Founder Intelligence | Strategic Approved / Canonical |
| Studio DNA | Taste Canonical |
| Collaboration Intelligence | Process + shorthand Working–Canonical |

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** MANIFEST.md, COLLABORATION_GLOSSARY.md  
**Future Questions:** JSON schema field `maturity` per glossary entry?

```

## Collaboration Intelligence Capsule — `README_FIRST.md` (added)

```markdown
# README FIRST — Collaboration Intelligence Capsule 1.0.0

> **Unified Onboarding Pack notice:** If this capsule is inside **StudioOS_OnboardingPack/**, follow **START_HERE.md** and **MASTER_MANIFEST.md**. Do not onboard from this capsule alone when the unified pack is present.

**You are opening:** `collaboration-intelligence/` (Collaboration Intelligence Capsule™)  
**Purpose:** Preserve **how the Founder and AI built Studio OS together** — shared vocabulary, decision history, abandoned ideas, collaboration patterns, and institutional stories that no single codebase or transcript can reconstruct.  
**Capsule version:** 1.0.0

## What this capsule answers

| Question | Where |
|----------|-------|
| Why does the Founder say that? | `COLLABORATION_GLOSSARY.md`, `RELATIONSHIP_MEMORY.md` |
| What historical context is missing? | `HISTORICAL_CONTEXT.md`, `IMPORTANT_CONVERSATIONS.md` |
| What conversation created this term? | `COLLABORATION_GLOSSARY.md`, `SEARCH_INDEX.md` |
| What decisions led here? | `DECISION_HISTORY.md` |
| What has already been debated? | `DECISION_HISTORY.md`, `AI_LESSONS.md` |
| What ideas were rejected? | `DECISION_HISTORY.md`, `EVOLUTION_TIMELINE.md` |
| What hidden assumptions exist? | `COLLABORATION_PATTERNS.md`, `FOUNDER_PREFERENCES.md` |

## What this is — and what it is not

| Is | Is not |
|----|--------|
| Curated institutional collaboration memory | Chat history or transcript dump |
| Shared vocabulary and shorthand | Implementation documentation |
| Decision and evolution record | Replacement for AI Context operational truth |
| Founder ↔ AI working language | Replacement for Founder Intelligence strategy canon |
| Pattern library for future agents | Replacement for Studio DNA taste and quality bar |

## Onboarding stack (when all capsules are included)

```
New AI session
    ↓
AI Context Capsule          →  WHAT (facts, blockers, handoff)
    ↓
Founder Intelligence        →  WHY (vision, business, strategy)
    ↓
Studio DNA Capsule          →  HOW decisions should feel (when included)
    ↓
Collaboration Intelligence  →  HOW we built it together (this capsule)
    ↓
CURRENT_HANDOFF.md          →  operational truth (Context capsule)
    ↓
Founder approval            →  then contribute
```

**Preferred handoff:** `https://fsbw.vercel.app/onboarding/latest`

Individual capsule: `https://fsbw.vercel.app/collaboration-intelligence/latest`

---

## Mandatory reading protocol

1. Read **MANIFEST.md** reading order in sequence.
2. Read **COLLABORATION_INTELLIGENCE_INDEX.md** for category map.
3. Use **SEARCH_INDEX.md** for semantic lookup (`Black Box`, `Goosebump`, `Marketplace`, etc.).
4. Cross-reference **AI Context** for `CURRENT_HANDOFF.md` and `KNOWN_BLOCKERS.md`.
5. Cross-reference **Founder Intelligence** for strategy canon — do not contradict without explicit founder override.

---

*End README_FIRST — proceed to MANIFEST.md.*

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** MANIFEST.md, COLLABORATION_INTELLIGENCE_INDEX.md  
**Future Questions:** Which new shorthand terms need glossary entries after each major sprint?

```

## Collaboration Intelligence Capsule — `README.md` (added)

```markdown
# Collaboration Intelligence Capsule™

Institutional memory of **Founder ↔ AI collaboration** for Studio OS.

## Scope

This capsule captures nuance that develops over months of paired work:

- Shared shorthand (`Black Box`, `The Mansion`, `Motherboard`, `Composer Sprint`)
- Decisions, rejections, and approved policies
- Evolution of major concepts (Marketplace, Studio World, World Compiler)
- Collaboration patterns (visualize → architecture → sprint → verify)
- Goosebump moments — strategic breakthroughs the Founder marks as civilization-scale

## Distribution

| Channel | URL |
|---------|-----|
| Standalone latest | `/collaboration-intelligence/latest` |
| Unified onboarding | `/onboarding/latest` (phase 4 when DNA included, after Founder Intelligence) |

## Authority hierarchy

1. **CURRENT_HANDOFF.md** (AI Context) — operational truth
2. **Founder Intelligence** — strategic WHY
3. **Studio DNA** — taste and HOW
4. **This capsule** — collaboration context and shorthand
5. **Repository code** — what is actually implemented

When this capsule conflicts with code, **code wins** unless the Founder explicitly reopens the decision.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** README_FIRST.md, MANIFEST.md  
**Future Questions:** Quarterly glossary review cadence?

```

## Collaboration Intelligence Capsule — `RELATIONSHIP_MEMORY.md` (added)

```markdown
# Relationship Memory

Shared terminology, humor, working language, and expectations between Founder and AI.

---

## Shared terminology

- **"The Mansion"** — Studio World spatial UI; not a literal building metaphor only — implies permanence and hospitality.
- **"Black Box"** — Investigation recorder; implies forensic seriousness, not secrecy from Founder.
- **"Motherboard"** — Living repo memory; agents must not claim it doesn't exist.
- **"Goosebump"** — Breakthrough quality bar — pause and recognize strategic weight.
- **"Composer Sprint"** — Production-grade single prompt; respect the fence.

---

## Working language

- Founder writes **complete specifications** — titles, sections, DO NOT lists, verify checklists.
- AI responds with **structured deliverables** — root cause, files changed, evidence, blockers.
- **"Repair only"** / **"No architecture changes"** — literal constraints, not suggestions.
- **"Verified complete"** vs **"shipped"** — Founder distinguishes browser verification from code merge.

---

## Communication style

- High-quality prose; complete sentences; minimal decorative bolding.
- Code citations use `startLine:endLine:filepath` for navigation.
- Markdown links for URLs and paths.
- Do not engagement-bait at end of responses.

---

## Founder expectations of AI

- Read motherboard before implementing.
- Run builds/tests when changing code.
- One commit + one push per task.
- State Spatial Architecture Review skip reason when applicable.
- Investigate before claiming billing/browser/root cause.

---

## AI expectations of Founder

- Explicit page/section names for admin alignment.
- Approval gates after onboarding reports.
- Composer sprints delivered as single code blocks.
- Clear priority: CRITICAL / APPROVED / DO NOT sections are binding.

---

## Recurring humor / tone

- Playful institution names (Studio Institute, Expert Capture) — still governed systems.
- "Civilization" language is sincere strategic framing, not parody.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** FOUNDER_PREFERENCES.md, COLLABORATION_PATTERNS.md  
**Future Questions:** Relationship memory sensitivity classification?

```

## Collaboration Intelligence Capsule — `RELATIONSHIP_TO_CONTEXT_CAPSULE.md` (added)

```markdown
# Relationship to AI Context Capsule

The **AI Context Capsule™** answers *what is true operationally right now*.

The **Collaboration Intelligence Capsule™** answers *why shorthand, decisions, and references exist*.

## Division of labor

| Topic | AI Context owns | Collaboration Intelligence owns |
|-------|-----------------|--------------------------------|
| Current blockers | `KNOWN_BLOCKERS.md` | Historical investigation context (e.g. B1 AUTH_REQUIRED saga) |
| Handoff | `CURRENT_HANDOFF.md` | How handoff culture developed (Composer Sprint, one deploy) |
| Glossary | `AI_GLOSSARY.md` (technical) | `COLLABORATION_GLOSSARY.md` (Founder shorthand) |
| Prompts | `PROMPT_LIBRARY.md` | Founder preference for code-block sprints |

## Read order inside unified pack

1. AI Context (phase 1) — facts first  
2. Founder Intelligence (phase 2) — strategy  
3. Studio DNA (phase 3, if included) — taste  
4. **Collaboration Intelligence (phase 4)** — shared history  
5. Return to `CURRENT_HANDOFF.md` before acting

## Conflict resolution

If Collaboration Intelligence describes intent not yet in code, defer to **CURRENT_HANDOFF.md** and **KNOWN_BLOCKERS.md**.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md, README_FIRST.md  
**Future Questions:** Cross-link AI_GLOSSARY entries to CIC glossary IDs?

```

## Collaboration Intelligence Capsule — `SEARCH_INDEX.md` (added)

```markdown
# Search Index

Semantic lookup for Collaboration Intelligence. Use keyword → document → section.

---

## Compiler & Experience Lab

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Black Box | COLLABORATION_GLOSSARY.md | World Compiler Investigation Recorder |
| World Compiler | GOOSEBUMP_MOMENTS.md, HISTORICAL_CONTEXT.md | Runtime decoupling |
| Experience Lab | HISTORICAL_CONTEXT.md, IMPORTANT_CONVERSATIONS.md | B1/B2 repairs |
| AUTH_REQUIRED | DECISION_HISTORY.md, HISTORICAL_CONTEXT.md | Ephemeral auth |
| B1 / B2 | COLLABORATION_GLOSSARY.md | Authorization vs browser |
| Layer 1 / Signature Landmark | HISTORICAL_CONTEXT.md | No canvas fallback |
| ephemeral auth | DECISION_HISTORY.md | Server-issued compile scope |
| compilerDiag | HISTORICAL_CONTEXT.md | Forensic mode |

---

## Economy & civilization

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Marketplace | EVOLUTION_TIMELINE.md, GOOSEBUMP_MOMENTS.md | Civilization economy |
| Studio Workers | GOOSEBUMP_MOMENTS.md, DECISION_HISTORY.md | Digital Payroll |
| Knowledge Capture | GOOSEBUMP_MOMENTS.md | Expert institutional learning |
| Goosebump | GOOSEBUMP_MOMENTS.md, COLLABORATION_GLOSSARY.md | Breakthrough moments |
| Interview Engine | GOOSEBUMP_MOMENTS.md | Private expert interviews |
| Knowledge Vault | GOOSEBUMP_MOMENTS.md | Long-term storage |
| Living Knowledge Mirror | COLLABORATION_GLOSSARY.md | Pre-vault reflection |

---

## Memory & onboarding

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Motherboard | COLLABORATION_GLOSSARY.md | motherboard/ folder |
| Collaboration Intelligence | README_FIRST.md | This capsule |
| Onboarding pack | EVOLUTION_TIMELINE.md | Fourth capsule |
| AI Context | RELATIONSHIP_TO_CONTEXT_CAPSULE.md | WHAT |
| Founder Intelligence | RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md | WHY |
| Studio DNA | RELATIONSHIP_TO_DNA_CAPSULE.md | HOW taste |
| CURRENT_HANDOFF | RELATIONSHIP_TO_CONTEXT_CAPSULE.md | Operational truth |

---

## Process & governance

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Composer Sprint | COLLABORATION_GLOSSARY.md, FOUNDER_PREFERENCES.md | One spec block |
| Terra | COLLABORATION_GLOSSARY.md | Governance reviewer |
| one deploy | DECISION_HISTORY.md | Single push rule |
| Spatial Architecture Review | COLLABORATION_GLOSSARY.md | Pre-implementation gate |
| Place over menu | DECISION_HISTORY.md | Spatial IA |
| Admin Alignment | DECISION_HISTORY.md | Protected admin pages |

---

## Institute & experts

| Query | Primary doc | Notes |
|-------|-------------|-------|
| Studio Institute | GOOSEBUMP_MOMENTS.md | Expert capture institution |
| Invite Manager | IMPORTANT_CONVERSATIONS.md | Owner password |
| owner password | HISTORICAL_CONTEXT.md | Stale local hash bug |
| Expert Trust | GOOSEBUMP_MOMENTS.md | Governance framework |

---

## Machine-readable terms

See `collaboration-intelligence.json` → `searchTerms[]` for programmatic lookup.

---
**Last Updated:** 2026-07-11  
**Confidence Level:** High  
**Source:** Collaboration Intelligence Capsule sprint v1.0  
**Status:** Approved  
**Version:** 1.0.0  
**Related Documents:** COLLABORATION_INTELLIGENCE_INDEX.md, COLLABORATION_GLOSSARY.md  
**Future Questions:** Embeddings index for cross-capsule search?

```
