# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| removed | AI Context Capsule | `CAPSULE_VALIDATION.md` | Documentation |
| removed | AI Context Capsule | `context-capsule.json` | Documentation |
| added | Collaboration Intelligence Capsule | `AI_LESSONS.md` | Architecture, Canon, Implementation Status, Founder Preference, Collaboration Memory, Blockers, Documentation, Genesis, Studio Institute, Experience Lab |
| added | Collaboration Intelligence Capsule | `COLLABORATION_GLOSSARY.md` | Collaboration Memory, Architecture, Canon, Blockers, Founder Preference, Studio Workers, Studio World, Genesis, World Compiler, Marketplace, Knowledge Capture, Documentation, Implementation Status, Experience Lab |
| added | Collaboration Intelligence Capsule | `COLLABORATION_INTELLIGENCE_INDEX.md` | Canon, Collaboration Memory, Blockers, Experience Lab, World Compiler, Architecture, Founder Preference, Marketplace, Knowledge Capture, Studio Workers, Documentation, Implementation Status, Genesis |
| added | Collaboration Intelligence Capsule | `COLLABORATION_PATTERNS.md` | Architecture, Canon, Implementation Status, Founder Preference, Collaboration Memory, Documentation, Genesis |
| added | Collaboration Intelligence Capsule | `DECISION_HISTORY.md` | Canon, Architecture, Collaboration Memory, Marketplace, Knowledge Capture, Studio Workers, Blockers, Studio Institute, Experience Lab, Documentation, Implementation Status, Studio World |
| added | Collaboration Intelligence Capsule | `EVOLUTION_TIMELINE.md` | Architecture, Canon, Studio World, Collaboration Memory, Marketplace, Studio HR, Experience Lab, World Compiler, Documentation, Implementation Status, Blockers, Revenue Model, Genesis |
| added | Collaboration Intelligence Capsule | `FOUNDER_PREFERENCES.md` | Founder Preference, Canon, Architecture, Collaboration Memory, Revenue Model |
| added | Collaboration Intelligence Capsule | `GOOSEBUMP_MOMENTS.md` | Knowledge Capture, Canon, Collaboration Memory, Architecture, Studio Workers, Studio Institute, Marketplace, Implementation Status, Experience Lab, World Compiler |
| added | Collaboration Intelligence Capsule | `HISTORICAL_CONTEXT.md` | Architecture, Experience Lab, World Compiler, Marketplace, Canon, Collaboration Memory, Documentation, Implementation Status, Revenue Model, Studio Institute |
| added | Collaboration Intelligence Capsule | `IMPORTANT_CONVERSATIONS.md` | Architecture, Canon, Studio Institute, Experience Lab, Collaboration Memory, Implementation Status, Blockers, Documentation |
| added | Collaboration Intelligence Capsule | `MANIFEST.md` | Canon, Collaboration Memory, Documentation |
| added | Collaboration Intelligence Capsule | `MEMORY_MATURITY.md` | Canon, Collaboration Memory, Architecture, Documentation, Implementation Status, Genesis |
| added | Collaboration Intelligence Capsule | `README_FIRST.md` | Collaboration Memory, Documentation, Canon, Blockers, Marketplace, Implementation Status, World Compiler |
| added | Collaboration Intelligence Capsule | `README.md` | Collaboration Memory, Architecture, Documentation, Implementation Status, Studio World, World Compiler, Founder Preference, Marketplace, Canon |
| added | Collaboration Intelligence Capsule | `RELATIONSHIP_MEMORY.md` | Founder Preference, Collaboration Memory, Architecture, Studio World, Studio Institute, Canon, Implementation Status, Blockers, World Compiler |
| added | Collaboration Intelligence Capsule | `RELATIONSHIP_TO_CONTEXT_CAPSULE.md` | Founder Preference, Collaboration Memory, Blockers, Implementation Status, Documentation, Canon |
| added | Collaboration Intelligence Capsule | `RELATIONSHIP_TO_DNA_CAPSULE.md` | Canon, Collaboration Memory, Documentation |
| added | Collaboration Intelligence Capsule | `RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md` | Collaboration Memory, Studio Workers, Canon, Business Model, Marketplace |
| added | Collaboration Intelligence Capsule | `SEARCH_INDEX.md` | Architecture, Knowledge Capture, Collaboration Memory, Studio Institute, World Compiler, Studio Workers, Implementation Status, Blockers, Experience Lab, Founder Preference, Marketplace, Documentation, Canon, Genesis |
| removed | Founder Intelligence Capsule | `FOUNDER_VALIDATION.md` | Documentation |
| removed | Founder Intelligence Capsule | `founder-intelligence.json` | Documentation |
| removed | Studio DNA Capsule | `DNA_VALIDATION.md` | Documentation |
| removed | Studio DNA Capsule | `studio-dna-capsule.json` | Documentation |

Full content for added/modified files is in the `changes/` directory.
