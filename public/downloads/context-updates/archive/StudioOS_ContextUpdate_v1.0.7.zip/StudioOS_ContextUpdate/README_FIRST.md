# README FIRST — Studio OS Delta Context Capsule

**You have already completed the Unified Onboarding Pack.** This package contains **only changes** since your last synchronization.

| Field | Value |
|-------|-------|
| **Delta version** | 1.0.7 |
| **Generated (UTC)** | 2026-07-12T22:31:13.211Z |
| **Base onboarding required** | 1.2.2 |
| **Current onboarding pack** | 1.2.2 |
| **Repository commit** | d586c44a5f5a05f570aa4d416f82c8ac9eda249a |
| **Compatibility** | compatible |
| **Change count** | 1 |

---

## Rules

1. **Do not** repeat full onboarding — merge this delta into existing understanding.
2. Read **UPDATE_SUMMARY.md** first, then **CHANGELOG.md**, then specialized update files.
3. Read files under **`changes/`** for full modified content.
4. Preserve prior onboarding knowledge — **supplement**, do not replace.
5. Update Founder preferences, Collaboration Memory, Canon, and Current Handoff in your working model.
6. Produce a brief synchronization acknowledgment, then **stop** — wait for founder instructions.

---

## Reading order

1. `UPDATE_SUMMARY.md`
2. `CHANGELOG.md`
3. `CHANGED_FILES.md`
4. `UPDATED_DECISIONS.md`
5. `UPDATED_GLOSSARY.md`
6. `UPDATED_COLLABORATION_MEMORY.md`
7. `UPDATED_FOUNDER_PREFERENCES.md`
8. `UPDATED_CANON.md`
9. `UPDATED_HANDOFF.md`
10. `changes/` (as needed)
11. `VALIDATION.md`

**Preferred download URL:** `https://fsbw.vercel.app/context-updates/latest`
