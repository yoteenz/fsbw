# CHANGELOG — Delta Context Update

## 1.0.7 (2026-07-12)

**Commit:** `d586c44a5f5a`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Implementation Status, Founder Preference, Documentation, Experience Lab)_
