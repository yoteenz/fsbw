# UPDATED CANON

Tracks maturity promotions, deprecations, and supersessions detected in this delta.

## Promoted to Canon / Approved

- AI Context Capsule / KNOWN_BLOCKERS.md (modified)

## Still Working

- None

## Still Experimental

- None

## Deprecated / Superseded

- None

## Changed files with canon relevance

- modified: `KNOWN_BLOCKERS.md`
