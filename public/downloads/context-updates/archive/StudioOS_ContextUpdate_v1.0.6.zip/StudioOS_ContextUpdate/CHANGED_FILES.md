# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| modified | AI Context Capsule | `KNOWN_BLOCKERS.md` | Blockers, Architecture, Implementation Status, Documentation, Experience Lab |

Full content for added/modified files is in the `changes/` directory.
