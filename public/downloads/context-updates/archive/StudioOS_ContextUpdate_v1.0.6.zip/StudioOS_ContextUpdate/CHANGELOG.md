# CHANGELOG — Delta Context Update

## 1.0.6 (2026-07-12)

**Commit:** `e612bc4ab438`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Implementation Status, Documentation, Experience Lab)_
