# UPDATED DECISIONS

Decision history additions and modifications from capsule sources.

_No changes in this delta._
