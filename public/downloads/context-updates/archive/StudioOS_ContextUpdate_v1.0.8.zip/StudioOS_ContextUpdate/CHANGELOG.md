# CHANGELOG — Delta Context Update

## 1.0.8 (2026-07-12)

**Commit:** `0d374488c77a`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Implementation Status, Founder Preference, Documentation, Experience Lab)_
