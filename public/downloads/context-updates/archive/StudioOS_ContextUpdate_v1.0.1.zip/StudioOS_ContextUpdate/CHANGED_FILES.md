# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| modified | AI Context Capsule | `CAPSULE_VALIDATION.md` | Documentation, Blockers, Founder Preference, Collaboration Memory, Canon, Implementation Status, Current Handoff |

Full content for added/modified files is in the `changes/` directory.
