# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| modified | AI Context Capsule | `CURRENT_HANDOFF.md` | Current Handoff, Implementation Status, Blockers, Documentation, Studio World, Experience Lab |

Full content for added/modified files is in the `changes/` directory.
