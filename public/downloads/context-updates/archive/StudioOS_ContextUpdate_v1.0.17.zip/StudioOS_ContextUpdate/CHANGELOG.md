# CHANGELOG — Delta Context Update

## 1.0.17 (2026-07-13)

**Commit:** `193f0f24f246`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `CURRENT_HANDOFF.md` _(Current Handoff, Implementation Status, Blockers, Architecture, Experience Lab)_
- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Implementation Status, Documentation, Experience Lab, World Compiler)_
