# UPDATED COLLABORATION MEMORY

Collaboration Intelligence deltas — shorthand, patterns, lessons, goosebump moments.

## AI Context Capsule — `CURRENT_HANDOFF.md` (modified)

```markdown
# Current Handoff — Active Sprint State

**Capsule:** StudioOS_ContextCapsule_v0.1  
**Last updated:** 2026-07-13  
**Git reference:** pending post-deploy SHA

---

## Current sprint

**P0 — FS vs Studio OS Generation Parity Forensics + Surgical Repair**

**Status: Repair shipped — Founder Verification Pending**

Proven first causal divergence: Frontal Slayer accepts FAL output without verified-asset pipeline; Studio OS rejected salvageable opaque studio plates before background removal. Repair: salvageable-opaque deferral + artifact-intent routing + parity forensic panel (`?compilerDiag=1`).

**Previous:** P1 Founder Review Experience™ (`ce6afb293`); stale governed job expiry (`e1c422eec`).

---

## Current blocker

| ID | Blocker | Status |
|----|---------|--------|
| **B1-Parity** | Salvageable opaque layer extraction on real device | **Verify Pending** — repair shipped |
| **B1-Layer1** | Layer 1 mobile Safari/Chrome with `?compilerDiag=1` | **Verify Pending** |
| **B1-E2E-Completion** | Top bar vs viewport consistency | **Verify Pending** |
| **B1-Isolated** | Brand marble + material fidelity on device | **In Progress** |

---

## Founder workflow

1. Open Experience Lab validation render on mobile with `?compilerDiag=1`.
2. Generate shell, then signature-landmark or furniture-objects.
3. Confirm opaque NB2 output reaches **BACKGROUND_REMOVING** (not immediate `QUALITY_REGENERATE_REQUIRED`).
4. Export Generation Parity JSON from diagnostic panel.

**References:**

- `docs/studio-os/investigations/FS_VS_STUDIO_OS_GENERATION_PARITY.md`
- `docs/studio-os/investigations/fs-studio-os-generation-parity.json`
- `docs/studio-os/scene-stack/VALIDATION_ORDER.md`

```

## AI Context Capsule — `KNOWN_BLOCKERS.md` (modified)

```markdown
# KNOWN BLOCKERS — Do Not Violate

**Last updated:** 2026-07-13  
**Authority:** Overrides feature work, compile repair, and optimistic assumptions

---

## Gate rule

**Do not** describe Creative Direction Studio or Experience Lab validation runtime as restored until:

1. **B1-Layer1** — Founder completes authenticated real-device Layer 1 verification on Mobile Safari and Mobile Chrome with `?compilerDiag=1`, **and**  
2. **B1-E2E-Completion** — Founder confirms top bar and viewport never contradict (no 100% with N/8 generating) on authenticated device.

---

## B0-PreHandler — Dispatch Office serverless bundle (CLEARED)

| Field | Detail |
|-------|--------|
| **ID** | B0-PreHandler |
| **Symptom** | Four governed routes returned HTTP 500 plain-text `FUNCTION_INVOCATION_FAILED` |
| **Repair** | Pre-bundle `studio-os-server.bundle.js` (`4ec75321f`) |
| **Verify** | `POST /api/admin/experience-lab-ephemeral-authorization` and `studio-builder-generate` return JSON |
| **Status** | **Production** — unauthenticated probe 2026-07-12: JSON 401; `studio-builder-generate` issues `traceId` |

### Documented Fact

- Pre-handler module evaluation failure was real; bundle repair addresses import trace.
- Handler and `traceId` execute on probed routes post-deploy.

---

---

## B1-Parity — FS vs Studio OS generation divergence (REPAIR SHIPPED — VERIFY PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-Parity |
| **Symptom** | `LANDMARK_VALIDATION_FAILED` / `QUALITY_REGENERATE_REQUIRED` on opaque NB2 plates; FS color/styling completes |
| **Root cause** | Studio OS `runVerifiedAssetProductionPipeline` rejects salvageable opaque studio output before governed background removal |
| **Repair** | `salvageable-opaque.ts` + structural/quality deferral + artifact-intent routing + `FULL_SCENE_RERENDER` architecture signals |
| **Forensics** | `docs/studio-os/investigations/FS_VS_STUDIO_OS_GENERATION_PARITY.md` |
| **Mobile diag** | `?compilerDiag=1` → Generation Parity panel in Shell Foundation Black Box |
| **Verify** | Isolated layer advances to BACKGROUND_REMOVING on founder device |
| **Status** | **Verify Pending** |

### Documented Fact

- Frontal Slayer path: `POST /api/wig-preview/live-noir-color` → sync FAL → no Quality Guard.
- Studio OS path: `studio-builder-generate` → async jobs → verified-asset pipeline (divergence boundary).
- Supabase schema audit 2026-07-13: critical tables present; no migration required.

---

## B1-Isolated — Brand-grounded NB2 + verified mount (SHIPPED — VERIFY PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-Isolated |
| **Symptom** | Generic marble substitution; NBP isolated aesthetic insufficient |
| **Founder decision** | NB2 default for isolated assets; exact org marble required |
| **Repair** | Model Registry v2 + Brand Asset Grounding + material fidelity validation |
| **Isolated model** | `fal-ai/nano-banana-2` / `fal-ai/nano-banana-2/edit` (brand refs) |
| **Shell model** | `fal-ai/nano-banana-pro/edit` (unchanged) |
| **Verify** | Experience Lab evidence panel shows brand marble + material pass on mobile |
| **Status** | **In Progress** — code shipped; founder production proof pending |

### Do not

- Rebuild shell on layer-quality failure
- Accept full-scene rerenders to advance pipeline
- Show "Retry Shell Layer" for landmark quality failures

---

## B1-Layer1 — Governed generation Layer 1 (ASYNC REPAIR SHIPPED — VERIFY PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-Layer1 |
| **Symptom** | Layer 1 / shell generation — `TypeError: Load failed` after ~95.5s synchronous pending |
| **Proven boundary** | Synchronous HTTP transport waiting for full FAL `fal.subscribe` completion |
| **Repair** | ASYNC_GOVERNED_GENERATION_V1 — `fal.queue.submit` + persisted job + 202 submit + status poll/resume |
| **Files** | `async-governed-generation.ts`, `studio-builder-generate.ts`, `studioBuilder/api.ts`, migration `studio_governed_generation_jobs` |
| **Forensic** | `ASYNC_GOVERNED_GENERATION.md` |
| **Verify** | Mobile — submit <2s, leave page, return, asset mounts without resubmit |
| **Status** | **In Progress** — code shipped; founder production proof pending |
| **Rollback** | `ASYNC_GOVERNED_GENERATION_V1=0` restores synchronous path |

### Documented Fact

- Package resolution, authorization, and `requestStudioBuilderGenerate` entry succeeded before transport failure
- IFR proved execution through IFR-15/16 window; failure was long-lived fetch not returning JSON

### Do not

- Declare Creative Studio or Experience Lab restored until founder device proof
- Remove synchronous path until async verified in production

---

## B1-Shell — Shell foundation (ASYNC TRANSPORT REPAIR — VERIFY PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-Shell |
| **Symptom** | Building Shell stall when sync fetch dropped at ~95s |
| **Repair** | Same async work-order path via `requestStudioBuilderGenerate` 202 handling |
| **Status** | **In Progress** — awaits founder compile with async submit |

---

## B1-Immune — Schema drift self-healing (SHIPPED — PRODUCTION ENV PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-Immune |
| **Symptom** | Missing `studio_governed_generation_jobs` caused schema-cache insert failure; hours of misdirected investigation |
| **Repair** | Studio OS Immune System™ — drift detector + Class A migration apply + contract verify + single retry |
| **Reference migration** | `20260712180000_studio_governed_generation_jobs` |
| **Files** | `src/studio-os-core/immune-system/`, `api/_lib/immuneSystem/`, `async-governed-generation.ts` |
| **Env** | `IMMUNE_SYSTEM_AUTO_REPAIR=1` + `SUPABASE_DB_URL` or `DATABASE_URL` (preferred) or Management API token |
| **CD Studio auth** | Separate fix — `POST /api/admin/creative-studio-stack-authorization` before stack build (not Immune System) |
| **CD Studio async** | `ASYNC_GOVERNED_GENERATION_CREATIVE_STUDIO=1` + `ASYNC_GOVERNED_GENERATION_V1=1` for 202 transport |
| **Verify** | Isolated reference-recovery test passes; production proof requires env + missing-table scenario (do not drop prod table) |
| **Status** | **In Progress** — code shipped; Vercel env + live auto-repair proof pending |
| **Rollback** | `IMMUNE_SYSTEM_AUTO_REPAIR=0` — detection/escalation only, no DDL apply |

### Documented Fact

- Missing table was deterministic root cause; adding table restored governed generation workflow
- FAL was not the active failure during the reference incident

### Do not

- Drop production table to test auto-repair
- Enable arbitrary SQL endpoints or client-controlled migration IDs
- Treat immune repair as permission for destructive schema changes

---

## B1-E2E-Completion — Premature terminal completion (REPAIR SHIPPED — VERIFY PENDING)

| Field | Detail |
|-------|--------|
| **ID** | B1-E2E-Completion |
| **Symptom** | Top bar **Render complete / 100%** while viewport overlay shows **Generating … N/8** or **0/8** |
| **Proven boundary** | `computeRenderPipelineProgress` — `isComplete = Boolean(compileSuccess)` |
| **Repair** | `evaluateRenderTerminalComplete` gate; runtime defers `RenderCompleted` until invariants pass; `notifySnapshot` promotes on late layer finish |
| **Files** | `render-pipeline-progress.ts`, `experience-lab-render-runtime.ts` |
| **Tests** | `render-pipeline-progress.invariants.test.ts` (14) |
| **Forensic** | `END_TO_END_PIPELINE_RECONCILIATION.md` §13 |
| **Status** | **In Progress** — code shipped; founder authenticated verification pending |

### Documented Fact

- Repair changes completion **authority** only — no Scene Stack, World Compiler, or provider changes.
- `compileReport.success` = blueprint ready; terminal complete = Final Inspection passed.

### Do not

- Treat repair shipped as incident resolved without authenticated device proof
- Revert to compile-only completion authority

---


Experience Lab validation runtime shares `useSceneStack` driver and `studio-builder-generate` with CDS. See **B1-Layer1** and **B1-E2E-Completion**.

---

## B2 — Diagnostic normal-tab verification

| Field | Detail |
|-------|--------|
| **ID** | B2 |
| **Recovery URL** | https://fsbw.vercel.app/__studio-os-recovery |
| **Status** | **In Progress** — pending founder device verification |

---

## Creative Services roadmap

**Planned / Conceptual only** — see `docs/studio-os/creative-services/CREATIVE_SERVICES_ROADMAP.md`. Not implemented.

```
