# UPDATED CANON

Tracks maturity promotions, deprecations, and supersessions detected in this delta.

## Promoted to Canon / Approved

- None

## Still Working

- None

## Still Experimental

- None

## Deprecated / Superseded

- AI Context Capsule / CURRENT_HANDOFF.md

## Changed files with canon relevance

- None
