# CHANGELOG — Delta Context Update

## 1.0.21 (2026-07-13)

**Commit:** `2e0a1ff7be4f`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `CURRENT_HANDOFF.md` _(Current Handoff, Architecture, Canon, Implementation Status, Marketplace, Blockers, Studio World, Experience Lab)_
- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Canon, Implementation Status, Documentation, Experience Lab, World Compiler)_
