# UPDATED GLOSSARY

New or updated shorthand, terminology, and glossary entries.

_No changes in this delta._
