# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| modified | Founder Intelligence Capsule | `PRODUCT_PHILOSOPHY.md` | Architecture, Marketplace, Canon, Studio World, Genesis, Studio Institute, Business Model, Implementation Status, World Compiler |

Full content for added/modified files is in the `changes/` directory.
