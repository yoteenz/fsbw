# UPDATED FOUNDER PREFERENCES

Founder preference changes discovered through collaboration.

_No changes in this delta._
