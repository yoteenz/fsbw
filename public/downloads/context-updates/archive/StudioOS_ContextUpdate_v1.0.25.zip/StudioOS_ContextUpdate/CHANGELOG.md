# CHANGELOG — Delta Context Update

## 1.0.25 (2026-07-14)

**Commit:** `e7345db79b97`
**Since baseline:** onboarding 1.2.2 → current 1.2.2

- **[MODIFIED]** AI Context Capsule — `CURRENT_HANDOFF.md` _(Current Handoff, Implementation Status, Canon, Blockers, Architecture, Experience Lab)_
- **[MODIFIED]** AI Context Capsule — `KNOWN_BLOCKERS.md` _(Blockers, Architecture, Canon, Implementation Status, Documentation, Experience Lab, World Compiler)_
