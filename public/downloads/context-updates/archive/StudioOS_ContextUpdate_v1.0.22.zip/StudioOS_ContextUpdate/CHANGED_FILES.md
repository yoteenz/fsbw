# CHANGED FILES

| Type | Capsule | Path | Categories |
|------|---------|------|------------|
| modified | AI Context Capsule | `CURRENT_HANDOFF.md` | Current Handoff, Architecture, Canon, Implementation Status, Blockers, Studio World, Founder Preference, Marketplace, Experience Lab |

Full content for added/modified files is in the `changes/` directory.
