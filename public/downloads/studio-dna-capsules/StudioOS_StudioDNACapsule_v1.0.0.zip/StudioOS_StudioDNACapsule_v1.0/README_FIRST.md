# README FIRST — Studio DNA Capsule 1.0.0

> **Unified Onboarding Pack notice:** If this capsule is inside **StudioOS_OnboardingPack/**, follow the pack-level **START_HERE.md** and **MASTER_MANIFEST.md**. Do not begin or complete a separate onboarding process from this capsule alone.

**You are opening:** `StudioOS_StudioDNACapsule_v1.0`  
**Purpose:** Transfer **how Studio OS thinks** — founder philosophy, creative instincts, architectural judgment, quality standards, and design principles that **cannot be reconstructed from source code alone**.  
**Capsule version:** 1.0.0  
**Companion artifacts:** `StudioOS_ContextCapsule_v0.3.1` (WHAT) · `founder-intelligence/` v1.0.0 (WHY) · optional Studio DNA when included in Unified Onboarding Pack

If this capsule is **not** in the Unified Onboarding Pack, it remains optional — absence does not block onboarding unless MASTER_MANIFEST lists DNA as required.

## What this is — and what it is not

| Artifact | Preserves |
|----------|-----------|
| **AI Context Capsule™** | WHAT Studio OS knows — architecture, handoff, blockers, glossary, operational truth |
| **Studio DNA Capsule™** | HOW Studio OS thinks — philosophy, instincts, decision patterns, quality bar, canon rules |
| **Founder Intelligence Capsule™** | WHY Studio OS exists — strategy, business model, vision, decision history |

This folder is **not** implementation documentation. It is **institutional judgment** encoded for future AI collaborators and human partners.

---

## Mandatory reading protocol

1. Read **MANIFEST.md** reading order in sequence.
2. Read **CANON_PRESERVATION_POLICY.md** before treating any concept as established direction.
3. Cross-reference **CANON_REGISTRY.md** for maturity status (Concept → Implemented).
4. Do **not** confuse brainstorming, vision bibles, or unapproved specs with canon.

---

## How to use alongside the Context Capsule

```
New AI session
    ↓
Context Capsule  →  reconstruct facts, stage, blockers, structure
    ↓
Studio DNA Capsule  →  align taste, judgment, communication, quality bar
    ↓
Founder approval  →  then contribute
```

---

## Evolution

The Studio DNA Capsule is a **living document**. When recurring founder preferences emerge in conversation, they should be **appended** (see `EVOLUTION.md`) and the capsule **re-versioned** — not silently overwritten.

**Goal:** Future collaborators think *with* the Studio OS design philosophy — by understanding documented principles, not by imitation or guesswork.

---

*End README_FIRST — proceed to MANIFEST.md.*
