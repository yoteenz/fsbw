# START HERE — Studio OS Unified Onboarding Pack

**This is the only authoritative entry point** when multiple capsules are distributed together.

**Pack version:** 1.0.0  
**Included capsules:** AI Context Capsule, Founder Intelligence Capsule, Studio DNA Capsule

---

## Rules (read before anything else)

1. This package may contain **multiple capsules**.
2. **MASTER_MANIFEST.md** defines the **complete required reading order** — follow it exactly.
3. Individual capsule README and MANIFEST files are **subordinate** inside this pack.
4. **Do not** stop after inspecting archive contents or listing files.
5. **Do not** produce intermediate summaries between phases.
6. **Read every required file completely** before writing your report.
7. Use **ONBOARDING_REPORT_TEMPLATE.md** as the **required report structure**.
8. **Populate each section with your own findings** — do **not** copy blank instructional text as answers.
9. Generate **one** final onboarding report for the **entire pack** — not one per capsule.
10. **Stop and wait for founder approval** after completing the report.

> Use ONBOARDING_REPORT_TEMPLATE.md as the required structure. Populate each section with your own findings based on the documents you read. Do not copy the blank instructional text as the answer.

If a capsule is **not present** in this package, do not treat it as a missing requirement unless **MASTER_MANIFEST.md** explicitly lists it as required.

---

## Included capsules

- **AI Context Capsule** — WHAT the project knows *(required)*
- **Founder Intelligence Capsule** — WHY the project exists *(required)*
- **Studio DNA Capsule** — HOW Studio OS thinks *(included)*

---

## Where to go next

1. **MASTER_MANIFEST.md** — full reading order  
2. **ONBOARDING_GUIDE.md** — how to classify facts, sources, and implementation state  
3. Read every manifest entry in order  
4. **ONBOARDING_REPORT_TEMPLATE.md** — complete your single final report  
5. **Stop** — wait for founder approval

---

## Unified pack vs standalone capsules

If you received a **single capsule ZIP** without this START_HERE file, that capsule's own README_FIRST and MANIFEST are authoritative.

Inside **StudioOS_OnboardingPack/**, this file and MASTER_MANIFEST always win.

**Preferred complete handoff URL:** `https://fsbw.vercel.app/onboarding/latest`
