# START HERE — Studio OS Unified Onboarding Pack

**This is the only authoritative entry point** when multiple capsules are distributed together.

**Pack version:** 1.2.2  
**Included capsules:** AI Context Capsule, Founder Intelligence Capsule, Studio DNA Capsule, Collaboration Intelligence Capsule

---

## Rules (read before anything else)

1. This package may contain **multiple capsules**.
2. **MASTER_MANIFEST.md** defines the **complete required reading order** — follow it exactly.
3. Individual capsule README and MANIFEST files are **subordinate** inside this pack.
4. **Do not** stop after inspecting archive contents or listing files.
5. **Do not** produce intermediate summaries between phases.
6. **Read every required file completely** before writing your report.
7. Use **ONBOARDING_REPORT_TEMPLATE.md** as the **required report structure**.
8. **Populate each section with your own findings** — do **not** copy blank instructional text as answers.
9. Generate **one** final onboarding report for the **entire pack** — not one per capsule.
10. **Stop and wait for founder approval** after completing the report.
11. After all capsules, read **CURRENT_HANDOFF.md** (AI Context) before any implementation.

> Use ONBOARDING_REPORT_TEMPLATE.md as the required structure. Populate each section with your own findings based on the documents you read. Do not copy the blank instructional text as the answer.

If a capsule is **not present** in this package, do not treat it as a missing requirement unless **MASTER_MANIFEST.md** explicitly lists it as required.

---

## Included capsules (reading order)

1. **AI Context Capsule** — WHAT the project knows *(required)*
2. **Founder Intelligence Capsule** — WHY the project exists *(required)*
3. **Studio DNA Capsule** — HOW decisions should feel *(optional when included)*
4. **Collaboration Intelligence Capsule** — HOW Founder and AI built it together *(required)*
5. **CURRENT_HANDOFF.md** — operational truth *(AI Context — read before acting)*

- **Studio DNA Capsule** — HOW Studio OS thinks *(included)*

---

## Machine-readable index (verify before reading)

Before reading capsule documents, inspect these generated JSON files to verify pack structure and coverage:

- **onboarding-state.json** — pack state, capsule inventory, validation status
- **onboarding-index.json** — per-document metadata and report-section mapping
- **coverage-map.json** — topic coverage status
- **cross-capsule-map.json** — concept ownership across capsules
- **topic-index.json** — reverse topic → document index
- **source-of-truth-map.json** — operational authority hierarchy

These files do **not** replace reading the documents — they make coverage verifiable.

---

## Where to go next

1. **onboarding-state.json** — validate pack structure  
2. **MASTER_MANIFEST.md** — full reading order  
3. **ONBOARDING_GUIDE.md** — how to classify facts, sources, and implementation state  
4. Read every manifest entry in order  
5. **ONBOARDING_REPORT_TEMPLATE.md** — complete your single final report  
6. **Stop** — wait for founder approval

---

## Unified pack vs standalone capsules

If you received a **single capsule ZIP** without this START_HERE file, that capsule's own README_FIRST and MANIFEST are authoritative.

Inside **StudioOS_OnboardingPack/**, this file and MASTER_MANIFEST always win.

**Preferred complete handoff URL:** `https://fsbw.vercel.app/onboarding/latest`

---

## Live Repository Cross-Context After Onboarding

This pack is **not** a permanent replacement for live repository state.

After onboarding approval, if you have **repository access**, also consult (paths at repo root — not inside this ZIP):

- `StudioOS_ContextCapsule_v0.1/CURRENT_HANDOFF.md`
- `StudioOS_ContextCapsule_v0.1/KNOWN_BLOCKERS.md`
- `motherboard/CORE.md` — persistent implementation rules
- `motherboard/CODEBASE.md` — live codebase map
- `motherboard/MEMORY.md` — append-only history (latest applicable entries; does not override handoff/blockers)
- Founder's latest verified production evidence

**Cursor** uses Motherboard as implementation memory. **External AI** uses this pack for deterministic onboarding. Neither replaces the other.

See **ONBOARDING_GUIDE.md** § Live Repository Cross-Context After Onboarding.
