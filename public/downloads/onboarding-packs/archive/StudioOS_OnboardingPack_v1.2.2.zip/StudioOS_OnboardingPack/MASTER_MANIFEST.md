# MASTER MANIFEST — Unified Onboarding Pack

| Field | Value |
|-------|-------|
| **Pack version** | 1.2.2 |
| **Generated (UTC)** | 2026-08-15T21:24:24.958Z |
| **Repository commit** | 60763c540b4595ea6435a99ce2a16c23637dc8c4 |
| **Required file count** | 94 |
| **Optional file count** | 3 |
| **Total archive file count** | 97 |
| **Manifest checksum** | 583871bd24229d7f7081790ac6b7ac15c9b66d14bcdee5db4adff24640fcd971 |

## Machine-readable index (phase 0)

| File | Purpose |
|------|---------|
| `onboarding-state.json` | Pack state, validation, capsule inventory |
| `onboarding-index.json` | Per-document metadata and report mapping |
| `coverage-map.json` | Topic coverage verification |
| `cross-capsule-map.json` | Concept ownership across capsules |
| `topic-index.json` | Topic → document reverse index |
| `source-of-truth-map.json` | Operational authority hierarchy |

## Per-capsule counts

- **AI Context:** 16 required + 1 optional = 17 total
- **Founder Intelligence:** 30 required + 1 optional = 31 total
- **Studio DNA:** 16 required + 0 optional = 16 total
- **Collaboration Intelligence:** 20 required + 1 optional = 21 total
- **Machine-Readable Index:** 6 required + 0 optional = 6 total
- **Unified Pack Root:** 6 required + 0 optional = 6 total

## Optional archive files (not in reading order)

- `AI_Context_Capsule/ONBOARDING_REPORT.md` — Standalone Context Capsule onboarding report template (backward compatibility)
- `Founder_Intelligence_Capsule/README.md` — Capsule overview and unified-pack pointer for standalone distribution
- `Collaboration_Intelligence_Capsule/README.md` — Capsule scope and authority overview for standalone distribution

## Expected report sections (19)

- 1. Onboarding Compliance
- 2. Read Confirmation
- 3. Project Understanding
- 4. Founder Understanding
- 5. Studio World Understanding
- 6. Marketplace and Revenue Understanding
- 7. Studio Workers and Studio HR Understanding
- 8. Studio Institute and Knowledge Capture Understanding
- 9. Knowledge Vault and Expert Trust Framework Understanding
- 10. Current Implementation State
- 11. Operational Source-of-Truth Hierarchy
- 12. Current Blockers
- 13. Canon Verification
- 14. Studio DNA Assessment
- 15. Documented Fact / Inference / Unknown Assessment
- 16. Documentation Review
- 17. Confidence Assessment
- 18. Readiness Assessment
- 19. Approval Boundary

## Complete reading order

| # | Phase | Path |
|---|-------|------|
| 1 | 0 | `START_HERE.md` |
| 2 | 0 | `MASTER_MANIFEST.md` |
| 3 | 0 | `ONBOARDING_GUIDE.md` |
| 4 | 0 | `onboarding-state.json` |
| 5 | 0 | `onboarding-index.json` |
| 6 | 0 | `coverage-map.json` |
| 7 | 0 | `cross-capsule-map.json` |
| 8 | 0 | `topic-index.json` |
| 9 | 0 | `source-of-truth-map.json` |
| 10 | 1 | `AI_Context_Capsule/README_FIRST.md` |
| 11 | 1 | `AI_Context_Capsule/MANIFEST.md` |
| 12 | 1 | `AI_Context_Capsule/KNOWN_BLOCKERS.md` |
| 13 | 1 | `AI_Context_Capsule/CURRENT_HANDOFF.md` |
| 14 | 1 | `AI_Context_Capsule/FOUNDER_PROFILE.md` |
| 15 | 1 | `AI_Context_Capsule/PROJECT_DNA.md` |
| 16 | 1 | `AI_Context_Capsule/AI_CONTEXT.md` |
| 17 | 1 | `AI_Context_Capsule/AI_GLOSSARY.md` |
| 18 | 1 | `AI_Context_Capsule/CHATGPT_OPERATING_MANUAL.md` |
| 19 | 1 | `AI_Context_Capsule/AI_STYLE_GUIDE.md` |
| 20 | 1 | `AI_Context_Capsule/PROJECT_CHANGELOG.md` |
| 21 | 1 | `AI_Context_Capsule/ROADMAP.md` |
| 22 | 1 | `AI_Context_Capsule/OPEN_QUESTIONS.md` |
| 23 | 1 | `AI_Context_Capsule/PROMPT_LIBRARY.md` |
| 24 | 1 | `AI_Context_Capsule/context-capsule.json` |
| 25 | 1 | `AI_Context_Capsule/CAPSULE_VALIDATION.md` |
| 26 | 2 | `Founder_Intelligence_Capsule/README_FIRST.md` |
| 27 | 2 | `Founder_Intelligence_Capsule/MANIFEST.md` |
| 28 | 2 | `Founder_Intelligence_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 29 | 2 | `Founder_Intelligence_Capsule/RELATIONSHIP_TO_DNA_CAPSULE.md` |
| 30 | 2 | `Founder_Intelligence_Capsule/FOUNDER_INTELLIGENCE_INDEX.md` |
| 31 | 2 | `Founder_Intelligence_Capsule/FOUNDER_PROFILE.md` |
| 32 | 2 | `Founder_Intelligence_Capsule/VISION.md` |
| 33 | 2 | `Founder_Intelligence_Capsule/PRODUCT_PHILOSOPHY.md` |
| 34 | 2 | `Founder_Intelligence_Capsule/DESIGN_LANGUAGE.md` |
| 35 | 2 | `Founder_Intelligence_Capsule/CREATIVE_DIRECTION.md` |
| 36 | 2 | `Founder_Intelligence_Capsule/STUDIO_WORLD.md` |
| 37 | 2 | `Founder_Intelligence_Capsule/EDUCATIONAL_PHILOSOPHY.md` |
| 38 | 2 | `Founder_Intelligence_Capsule/CIVILIZATION.md` |
| 39 | 2 | `Founder_Intelligence_Capsule/COMPANIES.md` |
| 40 | 2 | `Founder_Intelligence_Capsule/BUSINESS_MODEL.md` |
| 41 | 2 | `Founder_Intelligence_Capsule/REVENUE_MODEL.md` |
| 42 | 2 | `Founder_Intelligence_Capsule/MONETIZATION.md` |
| 43 | 2 | `Founder_Intelligence_Capsule/MARKETPLACE.md` |
| 44 | 2 | `Founder_Intelligence_Capsule/STUDIO_WORKERS.md` |
| 45 | 2 | `Founder_Intelligence_Capsule/KNOWLEDGE_CAPTURE.md` |
| 46 | 2 | `Founder_Intelligence_Capsule/INTERVIEW_ENGINE.md` |
| 47 | 2 | `Founder_Intelligence_Capsule/EXPERT_TRUST_AND_GOVERNANCE.md` |
| 48 | 2 | `Founder_Intelligence_Capsule/DECISION_HISTORY.md` |
| 49 | 2 | `Founder_Intelligence_Capsule/COMMUNICATION_STYLE.md` |
| 50 | 2 | `Founder_Intelligence_Capsule/FOUNDER_PREFERENCES.md` |
| 51 | 2 | `Founder_Intelligence_Capsule/AI_COLLABORATION.md` |
| 52 | 2 | `Founder_Intelligence_Capsule/FUTURE_IDEAS.md` |
| 53 | 2 | `Founder_Intelligence_Capsule/LONG_TERM_ROADMAP.md` |
| 54 | 2 | `Founder_Intelligence_Capsule/FOUNDER_VALIDATION.md` |
| 55 | 2 | `Founder_Intelligence_Capsule/founder-intelligence.json` |
| 56 | 3 | `Studio_DNA_Capsule/README_FIRST.md` |
| 57 | 3 | `Studio_DNA_Capsule/MANIFEST.md` |
| 58 | 3 | `Studio_DNA_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 59 | 3 | `Studio_DNA_Capsule/CANON_PRESERVATION_POLICY.md` |
| 60 | 3 | `Studio_DNA_Capsule/FOUNDER_DESIGN_PHILOSOPHY.md` |
| 61 | 3 | `Studio_DNA_Capsule/ARCHITECTURE_DNA.md` |
| 62 | 3 | `Studio_DNA_Capsule/CREATIVE_DIRECTION_DNA.md` |
| 63 | 3 | `Studio_DNA_Capsule/FOUNDER_DECISION_PATTERNS.md` |
| 64 | 3 | `Studio_DNA_Capsule/COMMUNICATION_DNA.md` |
| 65 | 3 | `Studio_DNA_Capsule/QUALITY_STANDARDS.md` |
| 66 | 3 | `Studio_DNA_Capsule/INSTITUTIONAL_VALUES.md` |
| 67 | 3 | `Studio_DNA_Capsule/AI_COLLABORATION_DNA.md` |
| 68 | 3 | `Studio_DNA_Capsule/CANON_REGISTRY.md` |
| 69 | 3 | `Studio_DNA_Capsule/EVOLUTION.md` |
| 70 | 3 | `Studio_DNA_Capsule/DNA_VALIDATION.md` |
| 71 | 3 | `Studio_DNA_Capsule/studio-dna-capsule.json` |
| 72 | 4 | `Collaboration_Intelligence_Capsule/README_FIRST.md` |
| 73 | 4 | `Collaboration_Intelligence_Capsule/MANIFEST.md` |
| 74 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 75 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md` |
| 76 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_DNA_CAPSULE.md` |
| 77 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_INTELLIGENCE_INDEX.md` |
| 78 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_GLOSSARY.md` |
| 79 | 4 | `Collaboration_Intelligence_Capsule/DECISION_HISTORY.md` |
| 80 | 4 | `Collaboration_Intelligence_Capsule/EVOLUTION_TIMELINE.md` |
| 81 | 4 | `Collaboration_Intelligence_Capsule/FOUNDER_PREFERENCES.md` |
| 82 | 4 | `Collaboration_Intelligence_Capsule/AI_LESSONS.md` |
| 83 | 4 | `Collaboration_Intelligence_Capsule/GOOSEBUMP_MOMENTS.md` |
| 84 | 4 | `Collaboration_Intelligence_Capsule/HISTORICAL_CONTEXT.md` |
| 85 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_MEMORY.md` |
| 86 | 4 | `Collaboration_Intelligence_Capsule/IMPORTANT_CONVERSATIONS.md` |
| 87 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_PATTERNS.md` |
| 88 | 4 | `Collaboration_Intelligence_Capsule/MEMORY_MATURITY.md` |
| 89 | 4 | `Collaboration_Intelligence_Capsule/SEARCH_INDEX.md` |
| 90 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_VALIDATION.md` |
| 91 | 4 | `Collaboration_Intelligence_Capsule/collaboration-intelligence.json` |
| 92 | 5 | `ONBOARDING_REPORT_TEMPLATE.md` |
| 93 | 5 | `ONBOARDING_PACK_VALIDATION.md` |
| 94 | 5 | `onboarding-pack.json` |

## Final steps

1. Complete **ONBOARDING_REPORT_TEMPLATE.md** (populated, original wording)
2. Read **ONBOARDING_PACK_VALIDATION.md** for package metadata
3. **Stop** — wait for founder approval
