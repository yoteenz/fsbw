# MASTER MANIFEST — Unified Onboarding Pack

| Field | Value |
|-------|-------|
| **Pack version** | 1.1.0 |
| **Generated (UTC)** | 2026-07-11T15:34:27.245Z |
| **Repository commit** | 46f260c85730cf95aabac81eea3b78e95f55784d |
| **Required file count** | 87 |
| **Manifest checksum** | 330ab45be76aa40d1c1ea1c00002e0835e9873c77569e0d550ccd94f4a9c318f |

## Per-capsule counts

- **AI Context:** 16 files
- **Founder Intelligence:** 29 files
- **Collaboration Intelligence:** 20 files
- **Studio DNA:** 16 files

## Complete reading order

| # | Phase | Path |
|---|-------|------|
| 1 | 0 | `START_HERE.md` |
| 2 | 0 | `MASTER_MANIFEST.md` |
| 3 | 0 | `ONBOARDING_GUIDE.md` |
| 4 | 1 | `AI_Context_Capsule/README_FIRST.md` |
| 5 | 1 | `AI_Context_Capsule/MANIFEST.md` |
| 6 | 1 | `AI_Context_Capsule/KNOWN_BLOCKERS.md` |
| 7 | 1 | `AI_Context_Capsule/CURRENT_HANDOFF.md` |
| 8 | 1 | `AI_Context_Capsule/FOUNDER_PROFILE.md` |
| 9 | 1 | `AI_Context_Capsule/PROJECT_DNA.md` |
| 10 | 1 | `AI_Context_Capsule/AI_CONTEXT.md` |
| 11 | 1 | `AI_Context_Capsule/AI_GLOSSARY.md` |
| 12 | 1 | `AI_Context_Capsule/CHATGPT_OPERATING_MANUAL.md` |
| 13 | 1 | `AI_Context_Capsule/AI_STYLE_GUIDE.md` |
| 14 | 1 | `AI_Context_Capsule/PROJECT_CHANGELOG.md` |
| 15 | 1 | `AI_Context_Capsule/ROADMAP.md` |
| 16 | 1 | `AI_Context_Capsule/OPEN_QUESTIONS.md` |
| 17 | 1 | `AI_Context_Capsule/PROMPT_LIBRARY.md` |
| 18 | 1 | `AI_Context_Capsule/context-capsule.json` |
| 19 | 1 | `AI_Context_Capsule/CAPSULE_VALIDATION.md` |
| 20 | 2 | `Founder_Intelligence_Capsule/README_FIRST.md` |
| 21 | 2 | `Founder_Intelligence_Capsule/MANIFEST.md` |
| 22 | 2 | `Founder_Intelligence_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 23 | 2 | `Founder_Intelligence_Capsule/RELATIONSHIP_TO_DNA_CAPSULE.md` |
| 24 | 2 | `Founder_Intelligence_Capsule/FOUNDER_INTELLIGENCE_INDEX.md` |
| 25 | 2 | `Founder_Intelligence_Capsule/FOUNDER_PROFILE.md` |
| 26 | 2 | `Founder_Intelligence_Capsule/VISION.md` |
| 27 | 2 | `Founder_Intelligence_Capsule/PRODUCT_PHILOSOPHY.md` |
| 28 | 2 | `Founder_Intelligence_Capsule/DESIGN_LANGUAGE.md` |
| 29 | 2 | `Founder_Intelligence_Capsule/CREATIVE_DIRECTION.md` |
| 30 | 2 | `Founder_Intelligence_Capsule/STUDIO_WORLD.md` |
| 31 | 2 | `Founder_Intelligence_Capsule/CIVILIZATION.md` |
| 32 | 2 | `Founder_Intelligence_Capsule/COMPANIES.md` |
| 33 | 2 | `Founder_Intelligence_Capsule/BUSINESS_MODEL.md` |
| 34 | 2 | `Founder_Intelligence_Capsule/REVENUE_MODEL.md` |
| 35 | 2 | `Founder_Intelligence_Capsule/MONETIZATION.md` |
| 36 | 2 | `Founder_Intelligence_Capsule/MARKETPLACE.md` |
| 37 | 2 | `Founder_Intelligence_Capsule/STUDIO_WORKERS.md` |
| 38 | 2 | `Founder_Intelligence_Capsule/KNOWLEDGE_CAPTURE.md` |
| 39 | 2 | `Founder_Intelligence_Capsule/INTERVIEW_ENGINE.md` |
| 40 | 2 | `Founder_Intelligence_Capsule/EXPERT_TRUST_AND_GOVERNANCE.md` |
| 41 | 2 | `Founder_Intelligence_Capsule/DECISION_HISTORY.md` |
| 42 | 2 | `Founder_Intelligence_Capsule/COMMUNICATION_STYLE.md` |
| 43 | 2 | `Founder_Intelligence_Capsule/FOUNDER_PREFERENCES.md` |
| 44 | 2 | `Founder_Intelligence_Capsule/AI_COLLABORATION.md` |
| 45 | 2 | `Founder_Intelligence_Capsule/FUTURE_IDEAS.md` |
| 46 | 2 | `Founder_Intelligence_Capsule/LONG_TERM_ROADMAP.md` |
| 47 | 2 | `Founder_Intelligence_Capsule/FOUNDER_VALIDATION.md` |
| 48 | 2 | `Founder_Intelligence_Capsule/founder-intelligence.json` |
| 49 | 3 | `Studio_DNA_Capsule/README_FIRST.md` |
| 50 | 3 | `Studio_DNA_Capsule/MANIFEST.md` |
| 51 | 3 | `Studio_DNA_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 52 | 3 | `Studio_DNA_Capsule/CANON_PRESERVATION_POLICY.md` |
| 53 | 3 | `Studio_DNA_Capsule/FOUNDER_DESIGN_PHILOSOPHY.md` |
| 54 | 3 | `Studio_DNA_Capsule/ARCHITECTURE_DNA.md` |
| 55 | 3 | `Studio_DNA_Capsule/CREATIVE_DIRECTION_DNA.md` |
| 56 | 3 | `Studio_DNA_Capsule/FOUNDER_DECISION_PATTERNS.md` |
| 57 | 3 | `Studio_DNA_Capsule/COMMUNICATION_DNA.md` |
| 58 | 3 | `Studio_DNA_Capsule/QUALITY_STANDARDS.md` |
| 59 | 3 | `Studio_DNA_Capsule/INSTITUTIONAL_VALUES.md` |
| 60 | 3 | `Studio_DNA_Capsule/AI_COLLABORATION_DNA.md` |
| 61 | 3 | `Studio_DNA_Capsule/CANON_REGISTRY.md` |
| 62 | 3 | `Studio_DNA_Capsule/EVOLUTION.md` |
| 63 | 3 | `Studio_DNA_Capsule/DNA_VALIDATION.md` |
| 64 | 3 | `Studio_DNA_Capsule/studio-dna-capsule.json` |
| 65 | 4 | `Collaboration_Intelligence_Capsule/README_FIRST.md` |
| 66 | 4 | `Collaboration_Intelligence_Capsule/MANIFEST.md` |
| 67 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_CONTEXT_CAPSULE.md` |
| 68 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_FOUNDER_INTELLIGENCE_CAPSULE.md` |
| 69 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_TO_DNA_CAPSULE.md` |
| 70 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_INTELLIGENCE_INDEX.md` |
| 71 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_GLOSSARY.md` |
| 72 | 4 | `Collaboration_Intelligence_Capsule/DECISION_HISTORY.md` |
| 73 | 4 | `Collaboration_Intelligence_Capsule/EVOLUTION_TIMELINE.md` |
| 74 | 4 | `Collaboration_Intelligence_Capsule/FOUNDER_PREFERENCES.md` |
| 75 | 4 | `Collaboration_Intelligence_Capsule/AI_LESSONS.md` |
| 76 | 4 | `Collaboration_Intelligence_Capsule/GOOSEBUMP_MOMENTS.md` |
| 77 | 4 | `Collaboration_Intelligence_Capsule/HISTORICAL_CONTEXT.md` |
| 78 | 4 | `Collaboration_Intelligence_Capsule/RELATIONSHIP_MEMORY.md` |
| 79 | 4 | `Collaboration_Intelligence_Capsule/IMPORTANT_CONVERSATIONS.md` |
| 80 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_PATTERNS.md` |
| 81 | 4 | `Collaboration_Intelligence_Capsule/MEMORY_MATURITY.md` |
| 82 | 4 | `Collaboration_Intelligence_Capsule/SEARCH_INDEX.md` |
| 83 | 4 | `Collaboration_Intelligence_Capsule/COLLABORATION_VALIDATION.md` |
| 84 | 4 | `Collaboration_Intelligence_Capsule/collaboration-intelligence.json` |
| 85 | 5 | `ONBOARDING_REPORT_TEMPLATE.md` |
| 86 | 5 | `ONBOARDING_PACK_VALIDATION.md` |
| 87 | 5 | `onboarding-pack.json` |

## Final steps

1. Complete **ONBOARDING_REPORT_TEMPLATE.md** (populated, original wording)
2. Read **ONBOARDING_PACK_VALIDATION.md** for package metadata
3. **Stop** — wait for founder approval
